import os, json, secrets, getpass, webbrowser, threading
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SETTINGS=ROOT/'local_settings.json'
if not SETTINGS.exists():
    print("주소록 시험판 최초 설정 (가상 데이터만 사용)")
    while True:
        p=getpass.getpass("관리자 로그인 비밀번호 (12자 이상): ")
        if len(p)<12:
            print("12자 이상 입력해 주세요.")
            continue
        p2=getpass.getpass("비밀번호 다시 입력: ")
        if p!=p2:
            print("비밀번호가 일치하지 않습니다.")
            continue
        break
    settings={'secret_key':secrets.token_hex(32),'initial_password':p}
    SETTINGS.write_text(json.dumps(settings,ensure_ascii=False),encoding='utf-8')
    print("설정이 생성됐습니다. local_settings.json 파일을 공유하지 마세요.")
else:
    settings=json.loads(SETTINGS.read_text(encoding='utf-8'))
os.environ['SECRET_KEY']=settings['secret_key']
os.environ['ADMIN_PASSWORD']=settings['initial_password']
os.environ['LOCAL_HTTP']='1'
from server import app
print("주소록 접속: http://127.0.0.1:8000")
print("이 창을 닫으면 서버가 종료됩니다.")
threading.Timer(1.2, lambda:webbrowser.open('http://127.0.0.1:8000')).start()
app.run(host='127.0.0.1',port=8000,debug=False,use_reloader=False)
