import os, sqlite3, hmac, hashlib, secrets, time
from pathlib import Path
from flask import Flask, request, session, redirect, render_template, jsonify, abort
from werkzeug.security import generate_password_hash, check_password_hash

ROOT=Path(__file__).parent
DB=Path(os.environ.get('DB_PATH',str(ROOT/'addressbook.sqlite3')))
app=Flask(__name__,template_folder='templates',static_folder='static')
app.secret_key=os.environ.get('SECRET_KEY','')
if len(app.secret_key)<32: raise RuntimeError('SECRET_KEY 환경변수를 32자 이상으로 설정하세요')
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SECURE=os.environ.get('LOCAL_HTTP')!='1',SESSION_COOKIE_SAMESITE='Strict',MAX_CONTENT_LENGTH=8*1024*1024,PERMANENT_SESSION_LIFETIME=3600)
ADMIN=os.environ.get('ADMIN_PASSWORD','')
if len(ADMIN)<12: raise RuntimeError('ADMIN_PASSWORD 환경변수를 12자 이상으로 설정하세요')
# password verifier created once; changing ADMIN_PASSWORD after initial setup does not change it
DB.parent.mkdir(parents=True,exist_ok=True)
with sqlite3.connect(DB) as c:
 c.execute('CREATE TABLE IF NOT EXISTS config (k TEXT PRIMARY KEY,v TEXT NOT NULL)')
 c.execute('CREATE TABLE IF NOT EXISTS data (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL, updated INTEGER NOT NULL)')
 if not c.execute("SELECT v FROM config WHERE k='password_hash'").fetchone():
  c.execute('INSERT INTO config VALUES (?,?)',('password_hash',generate_password_hash(ADMIN)))

def auth(): return bool(session.get('authenticated'))
def csrf(): return session.get('csrf') and hmac.compare_digest(request.headers.get('X-CSRF-Token',''),session['csrf'])
@app.after_request
def headers(resp):
 resp.headers['X-Content-Type-Options']='nosniff';resp.headers['X-Frame-Options']='DENY';resp.headers['Referrer-Policy']='no-referrer';resp.headers['Cache-Control']='no-store'
 resp.headers['Content-Security-Policy']="default-src 'self'; script-src 'self' 'unsafe-inline' https://t1.daumcdn.net https://postcode.map.daum.net; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self' https://postcode.map.daum.net; frame-src https://postcode.map.daum.net https://postcode.map.kakao.com; object-src 'none'; base-uri 'self'; form-action 'self'"
 return resp
@app.route('/login',methods=['GET','POST'])
def login():
 if request.method=='POST':
  with sqlite3.connect(DB) as c: verifier=c.execute("SELECT v FROM config WHERE k='password_hash'").fetchone()[0]
  if check_password_hash(verifier,request.form.get('password','')):
   session.clear();session['authenticated']=True;session['csrf']=secrets.token_urlsafe(32);session.permanent=True;return redirect('/')
  time.sleep(0.5)
  return render_template('login.html',error='비밀번호를 확인하세요'),401
 return render_template('login.html',error=None)
@app.route('/logout',methods=['POST'])
def logout():
 if not auth() or not (csrf() or hmac.compare_digest(request.form.get('csrf',''),session.get('csrf',''))):abort(403)
 session.clear();return redirect('/login')
@app.route('/')
def home():
 if not auth():return redirect('/login')
 return render_template('app.html',csrf=session['csrf'])
@app.route('/api/data',methods=['GET','PUT'])
def data():
 if not auth():abort(401)
 if request.method=='GET':
  with sqlite3.connect(DB) as c: row=c.execute('SELECT payload,updated FROM data WHERE id=1').fetchone()
  return jsonify({'payload':row[0] if row else None,'updated':row[1] if row else None})
 if not csrf():abort(403)
 j=request.get_json(silent=True)
 if not isinstance(j,dict) or not isinstance(j.get('payload'),str) or len(j['payload'])>6_000_000:abort(400)
 with sqlite3.connect(DB) as c:
  c.execute('INSERT INTO data (id,payload,updated) VALUES (1,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,updated=excluded.updated',(j['payload'],int(time.time())))
 return jsonify({'ok':True})
@app.route('/health')
def health():return jsonify({'ok':True})
if __name__=='__main__':app.run(host='127.0.0.1',port=8000)
