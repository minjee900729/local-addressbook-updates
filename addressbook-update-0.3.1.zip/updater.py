"""Optional, hash-checked updates from an explicitly configured HTTPS manifest.
Never downloads address-book data; never writes credentials to remote services.
"""
import hashlib, json, os, shutil, sys, tempfile, urllib.request, zipfile
from pathlib import Path, PurePosixPath

ROOT=Path(__file__).resolve().parent
VERSION=ROOT/'version.json'
ALLOWED={'server.py','local_start.py','updater.py','requirements.txt','version.json','주소록 시작.bat','README.md'}
MAX_ZIP=15*1024*1024

def version_tuple(v):
    parts=v.split('.')
    if len(parts)!=3 or not all(x.isdigit() for x in parts): raise ValueError('버전 형식 오류')
    return tuple(map(int,parts))

def permitted(name):
    p=PurePosixPath(name)
    if name.startswith('/') or '\\' in name or '..' in p.parts or len(p.parts)>6: return False
    return name in ALLOWED or (len(p.parts)>=2 and p.parts[0] in ('static','templates') and p.suffix in ('.js','.css','.html','.svg','.png','.ico'))

def fetch(url,limit):
    if not url.startswith('https://'): raise ValueError('HTTPS 주소만 허용')
    req=urllib.request.Request(url,headers={'User-Agent':'LocalAddressbookUpdater/1'})
    with urllib.request.urlopen(req,timeout=15) as resp:
        if not resp.url.startswith('https://'): raise ValueError('보안 연결이 아님')
        body=resp.read(limit+1)
    if len(body)>limit: raise ValueError('파일 크기 제한 초과')
    return body

def run():
    cfg=json.loads(VERSION.read_text(encoding='utf-8'))
    url=cfg.get('manifest_url','').strip()
    if not url:
        print('자동 업데이트 배포 주소가 아직 연결되지 않았습니다. 기존 프로그램으로 실행합니다.')
        return
    try:
        manifest=json.loads(fetch(url,16384))
        new=str(manifest['version'])
        if version_tuple(new)<=version_tuple(str(cfg['version'])):
            print('현재 최신 버전입니다.')
            return
        sha=str(manifest['sha256']).lower()
        if len(sha)!=64 or any(c not in '0123456789abcdef' for c in sha): raise ValueError('해시 형식 오류')
        print('새 버전:',new)
        if input('검증된 업데이트를 설치할까요? [y/N]: ').strip().lower()!='y':return
        payload=fetch(str(manifest['zip_url']),MAX_ZIP)
        if hashlib.sha256(payload).hexdigest()!=sha: raise ValueError('업데이트 무결성 검증 실패')
        import io
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            names=[x for x in archive.infolist() if not x.is_dir()]
            if not names or len(names)>100: raise ValueError('업데이트 파일 구성 오류')
            if any(not permitted(x.filename) or x.file_size>5*1024*1024 for x in names):raise ValueError('허용되지 않는 업데이트 파일')
            if sum(x.file_size for x in names)>25*1024*1024:raise ValueError('압축 해제 크기 초과')
            with tempfile.TemporaryDirectory(prefix='addressbook-update-') as tmp:
                staging=Path(tmp)
                for info in names:
                    target=staging.joinpath(*PurePosixPath(info.filename).parts)
                    target.parent.mkdir(parents=True,exist_ok=True)
                    target.write_bytes(archive.read(info))
                remote_cfg=json.loads((staging/'version.json').read_text(encoding='utf-8'))
                if str(remote_cfg['version'])!=new:raise ValueError('버전 정보 불일치')
                # Preserve original update feed; releases cannot redirect this setting.
                remote_cfg['manifest_url']=url
                (staging/'version.json').write_text(json.dumps(remote_cfg,ensure_ascii=False,indent=2),encoding='utf-8')
                backup=ROOT/'.update_rollback'
                if backup.exists():shutil.rmtree(backup)
                backup.mkdir()
                installed=[]
                try:
                    for info in names:
                        relative=Path(*PurePosixPath(info.filename).parts)
                        target=ROOT/relative
                        if target.exists():
                            old=backup/relative;old.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,old)
                        target.parent.mkdir(parents=True,exist_ok=True)
                        shutil.copy2(staging/relative,target)
                        installed.append(relative)
                except Exception:
                    for relative in reversed(installed):
                        old=backup/relative
                        if old.exists():shutil.copy2(old,ROOT/relative)
                        else:(ROOT/relative).unlink(missing_ok=True)
                    raise
                print('업데이트 설치 완료. 기존 데이터와 설정은 유지됩니다.')
    except Exception as e:
        print('업데이트 확인/설치 실패:',str(e))
        print('기존 프로그램으로 실행합니다.')

if __name__=='__main__':run()
