(async function(){
 const KEY='district-addressbook-demo-encrypted-v10';
 const status=()=>document.getElementById('sync-status');
 const originalSet=Storage.prototype.setItem;
 let syncing=false, pending=null;
 async function save(value){
   const response=await fetch('/api/data',{method:'PUT',headers:{'Content-Type':'application/json','X-CSRF-Token':window.APP_CSRF},body:JSON.stringify({payload:value}),credentials:'same-origin'});
   if(!response.ok) throw Error('서버 저장 실패 '+response.status);
 }
 try{
   const r=await fetch('/api/data',{credentials:'same-origin'});if(!r.ok)throw Error('로그인이 만료됐습니다');
   const data=await r.json();
   if(data.payload!==null){syncing=true;originalSet.call(localStorage,KEY,data.payload);syncing=false;}
   // Initial migration: if no server data, copy existing encrypted local storage (same browser only)
   else {const existing=localStorage.getItem(KEY);if(existing)await save(existing);}
   Storage.prototype.setItem=function(k,v){
     originalSet.call(this,k,v);
     if(this===localStorage && k===KEY && !syncing){
       clearTimeout(pending);
       const snapshot=String(v);
       pending=setTimeout(()=>save(snapshot).then(()=>{if(status())status().textContent='서버 저장 완료'}).catch(e=>{if(status())status().textContent='저장 오류: '+e.message}),350);
     }
   };
   const s=document.createElement('script');s.src='/static/app.js';document.body.appendChild(s);
   if(status())status().textContent='서버 연결됨';
 }catch(e){if(status())status().textContent='연결 오류: '+e.message;alert('주소록 서버 연결에 실패했습니다. 데이터를 수정하지 마세요. '+e.message)}
})();
