
(()=>{'use strict';const KEY='district-addressbook-demo-encrypted-v10';const OLD_KEY='district-addressbook-demo-v1';const fields=['name','birth','phone','member','district','committee','postcode','address','detail','group','role','memo','birthplace','occupation','landline','refusal','refusalReason'];const $=id=>document.getElementById(id);let events=[],data=[],editing=null,recs=[],primary=null,affs=[],activeSearch="",activeField="name";const uid=()=>crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random();let vaultKey=null,vaultSalt=null;const te=new TextEncoder(),td=new TextDecoder();const b64=a=>btoa(Array.from(new Uint8Array(a),v=>String.fromCharCode(v)).join(''));const un64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));async function derive(p,s){const k=await crypto.subtle.importKey('raw',te.encode(p),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt:s,iterations:250000,hash:'SHA-256'},k,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])}async function encryptedPayload(){if(!vaultKey)throw Error('먼저 잠금을 해제하세요.');const iv=crypto.getRandomValues(new Uint8Array(12));const ct=await crypto.subtle.encrypt({name:'AES-GCM',iv},vaultKey,te.encode(JSON.stringify({contacts:data,events})));return JSON.stringify({format:'district-addressbook-encrypted-v10',salt:b64(vaultSalt),iv:b64(iv),ciphertext:b64(ct)})}async function decryptPayload(obj,p){if(obj.format!=='district-addressbook-encrypted-v10')throw Error('지원하지 않는 암호화 파일입니다.');const salt=un64(obj.salt),k=await derive(p,salt);const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:un64(obj.iv)},k,un64(obj.ciphertext));const parsed=JSON.parse(td.decode(plain));return {salt,key:k,contacts:normalize(Array.isArray(parsed)?parsed:parsed.contacts),events:Array.isArray(parsed.events)?parsed.events:[]}}async function save(){const payload=await encryptedPayload();localStorage.setItem(KEY,payload)}function lockVault(){events=[];data=[];vaultKey=null;vaultSalt=null;$('vaultContent').classList.add('hidden');$('vault').classList.remove('hidden');$('vaultPassword').value='';$('vaultMessage').textContent='잠겼습니다.'}async function openVault(){try{if(!crypto.subtle)throw Error('브라우저가 Web Crypto를 지원하지 않습니다.');const p=$('vaultPassword').value;if(p.length<8)throw Error('비밀번호는 8자 이상이어야 합니다.');const stored=localStorage.getItem(KEY);if(stored){const o=await decryptPayload(JSON.parse(stored),p);vaultKey=o.key;vaultSalt=o.salt;data=o.contacts;events=o.events||[]}else{vaultSalt=crypto.getRandomValues(new Uint8Array(16));vaultKey=await derive(p,vaultSalt);data=sample();events=[];await save()}$('vaultPassword').value='';$('vault').classList.add('hidden');$('vaultContent').classList.remove('hidden');render()}catch(e){vaultKey=null;vaultSalt=null;$('vaultMessage').textContent='열기 실패: '+e.message}}$('vaultOpen').onclick=openVault;$('vaultLock').onclick=lockVault;
function sample(){return [{id:uid(),name:'김가상',birth:'1975-03-15',phone:'010-0000-0001',member:'DEMO-001',district:'원종동',committee:'부천시(갑)',address:'가상 주소 1',detail:'',group:'통장협의회',role:'회원',memo:'시험용 가상 데이터',recs:[{id:uid(),name:'이가상'},{id:uid(),name:'박가상'}],primary:null},{id:uid(),name:'이가상',birth:'',phone:'010-0000-0002',member:'DEMO-002',district:'고강동',committee:'부천시(갑)',address:'',detail:'',group:'주민자치회',role:'',memo:'',recs:[],primary:null}]}function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}function affiliations(c){return Array.isArray(c.affiliations)?c.affiliations:((c.group||c.role)?[{group:c.group||'',role:c.role||''}]:[])}function affRender(){$('affs').innerHTML=affs.map((a,i)=>`<span class="tag">${esc(a.group||'(단체 미입력)')} / ${esc(a.role||'(직책 미입력)')} <button type="button" data-aff-remove="${i}" aria-label="소속 삭제">×</button></span>`).join('')}function addAff(){let group=$('group').value.trim(),role=$('role').value.trim();if(!group&&!role)return true;if(!group){alert('소속 단체명을 입력해 주세요.');return false}if(affs.some(a=>normText(a.group)===normText(group)&&normText(a.role)===normText(role))){alert('동일한 단체와 직책이 이미 등록되어 있습니다.');return false}affs.push({group,role});$('group').value='';$('role').value='';affRender();return true}let activePhoneTab='mobile';
function render(){
 const q=activeSearch.toLowerCase(),field=activeField;
 let found=data.filter(c=>{
  if(activePhoneTab==='mobile'&&!c.phone)return false;
  if(activePhoneTab==='landline'&&!c.landline)return false;
  if(!q)return true;
  let values=field==='name'?[c.name]:field==='phone'?[c.phone,c.landline]:field==='recommender'?(c.recs||[]).map(r=>r.name):field==='group'?affiliations(c).map(a=>a.group):field==='role'?affiliations(c).map(a=>a.role):field==='occupation'?[c.occupation]:field==='birthplace'?[c.birthplace]:field==='refusal'?[c.refusal]:[...fields.map(k=>c[k]),...affiliations(c).flatMap(a=>[a.group,a.role]),...(c.recs||[]).map(r=>r.name)];
  if(field==='phone'){let digits=q.replace(/\D/g,'');return digits?values.some(v=>String(v||'').replace(/\D/g,'').includes(digits)):false}
  return values.some(v=>String(v||'').toLowerCase().includes(q));
 });
 $('count').textContent=`${found.length}명 / 전체 ${data.length}명`;
 document.querySelectorAll('[data-phone-tab]').forEach(b=>{b.classList.toggle('tab-selected',b.dataset.phoneTab===activePhoneTab);b.classList.toggle('primary',b.dataset.phoneTab===activePhoneTab)});
 $('list').innerHTML=found.map(c=>`<tr><td><strong>${esc(c.name)}</strong></td><td>${esc(c.birth||'')}</td><td>${esc(activePhoneTab==='landline'?c.landline:activePhoneTab==='mobile'?c.phone:[c.phone,c.landline].filter(Boolean).join(' / '))}</td><td>${esc(c.district)}</td><td>${esc(c.occupation||'')}<div class="mini">${esc(c.birthplace||'')}</div></td><td>${esc(affiliations(c).map(a=>[a.group,a.role].filter(Boolean).join(' / ')).join(', '))}</td><td>${(c.recs||[]).map(r=>{let st=recStatus(r);return esc(r.name)+' <small style="color:'+(st.contact?'#166534':'#9a3412')+'">['+(st.contact?'DB 등록':'미등록')+']</small>'}).join(', ')}</td><td class="${c.refusal&&c.refusal!=='none'?'status-no':''}">${esc(refusalLabel(c.refusal))}</td><td>${eventCounts(c)}회 <button data-history="${esc(c.id)}">이력</button></td><td><button data-edit="${esc(c.id)}">수정</button> <button class="danger" data-delete="${esc(c.id)}">삭제</button></td></tr>`).join('')||'<tr><td colspan="10">표시할 연락처가 없습니다.</td></tr>';
}
function refusalLabel(v){return ({none:'정상',sms:'문자 거절',call:'전화 거절',both:'전체 거절'})[v]||'정상'}
$('phoneTabs').onclick=e=>{const b=e.target.closest('[data-phone-tab]');if(b){activePhoneTab=b.dataset.phoneTab;render()}};
function recStatus(r){let linked=r.contactId?data.find(c=>c.id===r.contactId):null;return linked?{kind:'등록',contact:linked}: {kind:'미등록',contact:null}}
function recRender(){$('recs').innerHTML=recs.map(r=>{let st=recStatus(r);return `<span class="tag">${esc(r.name)} <strong style="color:${st.contact?'#166534':'#9a3412'}">[${st.contact?'DB 등록':'미등록'}]</strong> ${st.contact?`<button type="button" data-view-rec="${esc(st.contact.id)}">정보 보기</button>`:''}<button type="button" data-primary="${esc(r.id)}">${primary===r.id?'★ 대표':'☆ 대표 지정'}</button><button type="button" data-remove="${esc(r.id)}" aria-label="추천인 삭제">×</button></span>`}).join('');showRecMatches()}
function showRecMatches(){let v=$('recommender').value.trim();let matches=v?data.filter(c=>c.id!==editing&&normText(c.name).includes(normText(v))).slice(0,12):[];$('recMatches').innerHTML=matches.length?'<div style="margin:8px 0">DB 검색 결과 — 아래에서 해당 인물을 선택하면 등록자로 연결됩니다.</div>'+matches.map(c=>`<button type="button" data-link-rec="${esc(c.id)}" style="margin:2px">${esc(c.name)} (${esc(c.phone||'전화번호 없음')}) · DB 등록</button>`).join(''):v?'<div style="margin:8px 0">일치하는 DB 등록자를 찾지 못했습니다. 이름만 추가하면 미등록으로 표시됩니다.</div>':''}
function addRec(name,contactId=null){if(recs.some(r=>contactId?r.contactId===contactId:!r.contactId&&normText(r.name)===normText(name))){alert('이미 등록된 추천인입니다.');return}recs.push({id:uid(),name,contactId});$('recommender').value='';recRender()}
function open(c){editing=c?.id||null;fields.forEach(k=>$(k).value=c?.[k]||'');if(c?.rrn_demo&&!c?.birth)$('birth').value=c.rrn_demo;affs=affiliations(c||{}).map(a=>({...a}));$('group').value='';$('role').value='';affRender();recs=(c?.recs||[]).map(r=>({...r}));primary=c?.primary||null;$('formtitle').textContent=editing?'연락처 수정':'새 연락처 등록';$('editor').classList.remove('hidden');recRender();$('editor').scrollIntoView({behavior:'smooth'})}function close(){$('editor').classList.add('hidden');editing=null}function normPhone(v){return String(v||'').replace(/[^0-9]/g,'')}function normText(v){return String(v||'').trim().replace(/\s+/g,' ').toLowerCase()}function dateValid(y,m,d){let dt=new Date(Date.UTC(y,m-1,d));return dt.getUTCFullYear()===y&&dt.getUTCMonth()===m-1&&dt.getUTCDate()===d}
function formatBirth(value){let v=String(value||'').trim();if(!v)return '';if(/^DEMO-/i.test(v)){if(!/^DEMO-\d{6}-\d{7}$/i.test(v))throw Error('가상번호는 DEMO-900729-1234567 형식이어야 합니다.');return v.toUpperCase()}
let digits=v.replace(/[-.\/\s]/g,'');if(!/^\d+$/.test(digits))throw Error('생년월일은 숫자 6자리 또는 8자리로 입력해 주세요.');if(digits.length!==6&&digits.length!==8)throw Error(`생년월일 숫자는 6자리 또는 8자리여야 합니다. 현재 ${digits.length}자리입니다.`);
let year,month,day;if(digits.length===6){let yy=Number(digits.slice(0,2)),cutoff=new Date().getFullYear()%100;year=(yy<=cutoff?2000:1900)+yy;month=Number(digits.slice(2,4));day=Number(digits.slice(4,6))}else{year=Number(digits.slice(0,4));month=Number(digits.slice(4,6));day=Number(digits.slice(6,8))}if(!dateValid(year,month,day))throw Error('실제 존재하는 생년월일을 입력해 주세요.');return `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`}
function formatPhone(value){let v=String(value||'').trim();if(!v)return '';if(/[^0-9\s().-]/.test(v))throw Error('전화번호는 숫자와 하이픈(-)만 입력해 주세요.');let d=v.replace(/\D/g,'');if(d.startsWith('010')){if(d.length!==11)throw Error(`010으로 시작하는 전화번호는 010 뒤에 숫자 8자리가 필요합니다. 현재 ${Math.max(0,d.length-3)}자리입니다.`);return `010-${d.slice(3,7)}-${d.slice(7)}`}
if(d.length<9||d.length>11)throw Error(`전화번호 자릿수를 확인해 주세요. 현재 ${d.length}자리입니다.`);if(d.startsWith('02'))return `02-${d.slice(2,-4)}-${d.slice(-4)}`;return `${d.slice(0,3)}-${d.slice(3,-4)}-${d.slice(-4)}`}
function duplicateOf(o,arr,exclude){return arr.find(c=>c.id!==exclude&&((normPhone(o.phone)&&normPhone(o.phone)===normPhone(c.phone))||(normText(o.member)&&normText(o.member)===normText(c.member))||(normText(o.name)&&o.birth&&normText(o.name)===normText(c.name)&&o.birth===c.birth)))}function normalize(v){
 if(!Array.isArray(v)||v.length>20000)throw Error('유효한 주소록 배열이 아닙니다.');
 const used=new Set();let normalized=v.map(c=>{
  if(!c||typeof c!=='object'||typeof c.name!=='string'||!c.name.trim())throw Error('이름이 없는 연락처가 있습니다.');
  let id=typeof c.id==='string'&&c.id&&!used.has(c.id)?c.id:uid();used.add(id);
  let o={id};fields.forEach(k=>o[k]=String(c[k]??(k==='birth'?c.rrn_demo:'')??'').slice(0,k==='memo'?3000:300));
  o.recs=Array.isArray(c.recs)?c.recs.slice(0,100).map(r=>({id:String(r?.id||uid()),name:String(r?.name||'').slice(0,80),contactId:r?.contactId||null})).filter(r=>r.name):[];
  o.primary=o.recs.some(r=>r.id===c.primary)?c.primary:null;
  o.refusalChangedAt=String(c.refusalChangedAt||'');
  o.affiliations=affiliations(c).slice(0,100).map(a=>({group:String(a.group||'').slice(0,100),role:String(a.role||'').slice(0,100)}));return o
 });
 for(let i=0;i<normalized.length;i++){let dup=duplicateOf(normalized[i],normalized.slice(0,i),null);if(dup)throw Error('백업 파일에 중복 연락처가 있습니다: '+normalized[i].name+' / '+dup.name)}
 return normalized
}
function runSearch(){activeField=$('searchField').value;activeSearch=$('search').value.trim();render()}$('searchBtn').addEventListener('click',runSearch);$('search').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();runSearch()}});$('searchClear').addEventListener('click',()=>{$('search').value='';activeSearch='';activeField=$('searchField').value;render()});$('searchField').addEventListener('change',()=>{const names={name:'이름',phone:'전화번호',recommender:'추천인',group:'소속 단체',role:'직책',occupation:'직업',birthplace:'출생지',refusal:'수신거절',all:'전체 항목'};$('search').placeholder=(names[$('searchField').value]||'검색어')+' 입력 후 검색'});$('new').onclick=()=>open(null);$('cancel').onclick=close;$('reset').onclick=()=>{if(confirm('현재 입력을 초기화할까요?'))open(null)};$('addaff').onclick=addAff;$('affs').onclick=e=>{let b=e.target.closest('button');if(b&&b.dataset.affRemove!==undefined){affs.splice(Number(b.dataset.affRemove),1);affRender()}};$('addrec').onclick=()=>{let name=$('recommender').value.trim();if(!name)return;let matches=data.filter(c=>c.id!==editing&&normText(c.name)===normText(name));if(matches.length){alert('DB에 같은 이름이 있습니다. 아래 검색 결과에서 전화번호를 확인해 해당 인물을 선택하거나, 미등록 추천인으로 추가할 수 있습니다.')}addRec(name)};$('recommender').addEventListener('input',showRecMatches);$('recMatches').onclick=e=>{let b=e.target.closest('button[data-link-rec]');if(!b)return;let c=data.find(x=>x.id===b.dataset.linkRec);if(c)addRec(c.name,c.id)};$('recommender').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('addrec').click()}});$('recs').onclick=e=>{let b=e.target.closest('button');if(!b)return;if(b.dataset.remove){recs=recs.filter(r=>r.id!==b.dataset.remove);if(primary===b.dataset.remove)primary=null}else if(b.dataset.primary){primary=primary===b.dataset.primary?null:b.dataset.primary}else if(b.dataset.viewRec){let c=data.find(x=>x.id===b.dataset.viewRec);if(c)alert('DB 등록 추천인\n이름: '+c.name+'\n전화번호: '+(c.phone||'없음')+'\n행정동: '+(c.district||'없음'))}recRender()};$('birth').addEventListener('blur',()=>{let el=$('birth');if(!el.value.trim())return;try{el.value=formatBirth(el.value)}catch(err){el.setCustomValidity(err.message);el.reportValidity();return}el.setCustomValidity('')});$('birth').addEventListener('input',()=> $('birth').setCustomValidity(''));$('phone').addEventListener('blur',()=>{let el=$('phone');if(!el.value.trim())return;try{el.value=formatPhone(el.value)}catch(err){el.setCustomValidity(err.message);el.reportValidity();return}el.setCustomValidity('')});$('phone').addEventListener('input',()=> $('phone').setCustomValidity(''));// 카카오 우편번호 검색은 외부 서비스가 필요하지만 연락처는 로컬에만 저장합니다.
let postcodeLoading=null;
function loadPostcode(){if(window.kakao?.Postcode||window.daum?.Postcode)return Promise.resolve();if(postcodeLoading)return postcodeLoading;postcodeLoading=new Promise((resolve,reject)=>{let script=document.createElement('script');script.src='https://t1.kakaocdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js';script.onload=()=>window.kakao?.Postcode||window.daum?.Postcode?resolve():reject(Error('주소 검색 서비스를 초기화할 수 없습니다.'));script.onerror=()=>reject(Error('인터넷 연결 또는 주소 검색 서비스 접속을 확인하세요.'));document.head.appendChild(script)}).catch(e=>{postcodeLoading=null;throw e});return postcodeLoading}
$('postcodeSearch').onclick=async()=>{let btn=$('postcodeSearch');btn.disabled=true;try{await loadPostcode();let Postcode=window.kakao?.Postcode||window.daum?.Postcode;new Postcode({oncomplete:function(d){$('postcode').value=d.zonecode||'';$('address').value=d.userSelectedType==='J'?(d.jibunAddress||d.address):(d.roadAddress||d.address);const adminDong=String(d.hname||'').trim();$('district').value=adminDong;$('districtHint').textContent=adminDong?'행정동 자동 입력 완료: '+adminDong+' (필요하면 수정 가능)':'검색 결과에 행정동 정보가 없어 직접 입력해 주세요. 법정동과 행정동은 다를 수 있습니다.';$('detail').focus();}}).open()}catch(e){alert(e.message+'\n주소는 직접 입력할 수도 있습니다.')}finally{btn.disabled=false}};
$('postcode').addEventListener('blur',()=>{let v=$('postcode').value.trim();if(v&&!/^\d{5}$/.test(v)){ $('postcode').setCustomValidity('우편번호는 숫자 5자리로 입력하세요.');$('postcode').reportValidity()}else $('postcode').setCustomValidity('')});$('postcode').addEventListener('input',()=> $('postcode').setCustomValidity(''));
$('form').onsubmit=async e=>{e.preventDefault();let o={id:editing||uid()};fields.forEach(k=>o[k]=$(k).value.trim());try{o.birth=formatBirth(o.birth);o.phone=formatPhone(o.phone);o.landline=formatPhone(o.landline);
 const mobile=v=>/^(010|011|016|017|018|019)/.test(v||'');
 if(o.phone&&!mobile(o.phone)){if(!o.landline){o.landline=o.phone;o.phone=''}else throw Error('일반전화 번호가 두 개 입력됐습니다. 한 개만 등록할 수 있습니다.')}
 if(o.landline&&mobile(o.landline)){if(!o.phone){o.phone=o.landline;o.landline=''}else throw Error('휴대전화 번호가 두 개 입력됐습니다. 한 개만 등록할 수 있습니다.')}
 }catch(err){alert(err.message);return}if(($('group').value.trim()||$('role').value.trim())&&!addAff())return;o.affiliations=affs.map(a=>({...a}));o.group=o.affiliations.map(a=>a.group).join('; ');o.role=o.affiliations.map(a=>a.role).join('; ');o.recs=recs.map(r=>({...r}));o.primary=primary;const prev=data.find(c=>c.id===editing);o.refusalChangedAt=prev?.refusalChangedAt||'';if((prev?.refusal||'none')!==(o.refusal||'none'))o.refusalChangedAt=new Date().toISOString();if(!o.name){alert('이름을 입력하세요.');return}let dup=duplicateOf(o,data,editing);if(dup){alert(`중복 등록이 차단되었습니다.\n기존 연락처: ${dup.name}\n전화번호, 당원번호 또는 이름+생년월일이 일치합니다.\n기존 연락처를 수정해 주세요.`);return;}if(editing){let i=data.findIndex(c=>c.id===editing);if(i>=0)data[i]=o;else data.push(o)}else data.push(o);await save();render();close();window.scrollTo({top:0,behavior:'smooth'})};$('list').onclick=async e=>{let b=e.target.closest('button');if(!b)return;if(b.dataset.history){let c=data.find(x=>x.id===b.dataset.history);if(c){let h=events.filter(ev=>ev.attendees?.[c.id]).sort((a,b)=>b.date.localeCompare(a.date));alert(c.name+' 행사 참석 이력 (실제 참석 '+eventCounts(c)+'회)\n'+(h.map(ev=>ev.date+' '+ev.title+' — '+({attended:'실제 참석',planned:'참석 예정',absent:'불참'}[ev.attendees[c.id]]||'')).join('\n')||'등록된 이력 없음'))}}if(b.dataset.edit){let c=data.find(c=>c.id===b.dataset.edit);if(c)open(c)}if(b.dataset.delete){let c=data.find(c=>c.id===b.dataset.delete);if(c&&confirm(`'${c.name}' 연락처를 삭제할까요?`)){data=data.filter(x=>x.id!==c.id);await save();render();if(editing===c.id)close()}}};// Offline XLSX writer: text cells preserve leading zeroes in phone numbers and member IDs.
function xesc(v){return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;').replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g,'')}
function colName(n){let s='';for(n++;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s}
function crc32(u){let c=0xffffffff;for(let b of u){c^=b;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0)}return (c^0xffffffff)>>>0}
function zipStore(files){let enc=new TextEncoder(),chunks=[],central=[],offset=0;const u16=n=>[n&255,(n>>>8)&255],u32=n=>[n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255];for(let [name,content] of files){let nb=enc.encode(name),b=enc.encode(content),crc=crc32(b),local=new Uint8Array([...u32(0x04034b50),...u16(20),...u16(0),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(b.length),...u32(b.length),...u16(nb.length),...u16(0),...nb]);chunks.push(local,b);central.push(new Uint8Array([...u32(0x02014b50),...u16(20),...u16(20),...u16(0),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(b.length),...u32(b.length),...u16(nb.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset),...nb]));offset+=local.length+b.length}let cdsize=central.reduce((n,a)=>n+a.length,0);return new Blob([...chunks,...central,new Uint8Array([...u32(0x06054b50),...u16(0),...u16(0),...u16(files.length),...u16(files.length),...u32(cdsize),...u32(offset),...u16(0)])],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})}
function excelBackup(){let headers=['이름','생년월일 / 가상 주민등록번호','휴대전화','일반전화','직업','출생지','수신거절','수신거절 사유','당원번호','행정동','소속 지역위원회','우편번호','주소','상세주소','소속 단체','직책','추천인','대표 추천인','메모'];let rows=[headers,...data.map(c=>{let a=affiliations(c);let rs=Array.isArray(c.recs)?c.recs:[];let pr=rs.find(r=>r.id===c.primary);return [c.name,c.birth,c.phone,c.landline||'',c.occupation||'',c.birthplace||'',c.refusal||'',c.refusalReason||'',c.member,c.district,c.committee,c.postcode||'',c.address,c.detail,a.map(x=>x.group).join('; '),a.map(x=>x.role).join('; '),rs.map(x=>x.name).join('; '),pr?.name||'',c.memo]})];let xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetData>'+rows.map((r,i)=>'<row r="'+(i+1)+'">'+r.map((v,j)=>'<c r="'+colName(j)+(i+1)+'" t="inlineStr"><is><t xml:space="preserve">'+xesc(v)+'</t></is></c>').join('')+'</row>').join('')+'</sheetData><autoFilter ref="A1:S'+rows.length+'"/></worksheet>';let files=[['[Content_Types].xml','<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'],['_rels/.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],['xl/workbook.xml','<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="주소록" sheetId="1" r:id="rId1"/></sheets></workbook>'],['xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'],['xl/worksheets/sheet1.xml',xml]];let url=URL.createObjectURL(zipStore(files)),a=document.createElement('a');a.href=url;a.download='지역위원회_주소록_백업_'+new Date().toISOString().slice(0,10)+'.xlsx';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000)}
$('excelbackup').onclick=()=>{try{excelBackup()}catch(err){alert('엑셀 백업 실패: '+err.message)}};

// Shared, conservative merge engine. Strong matches: unique party ID or name+birth;
// phone alone is never sufficient for an automatic identity decision.
function identityDecision(incoming,arr){
 const member=normText(incoming.member), name=normText(incoming.name), birth=incoming.birth;
 const strong=arr.filter(c=>(member&&normText(c.member)===member)||(name&&birth&&normText(c.name)===name&&c.birth===birth));
 const phone=normPhone(incoming.phone);
 const phoneMatches=phone?arr.filter(c=>normPhone(c.phone)===phone):[];
 if(strong.length>1)return {type:'review',reason:'복수의 동일인 후보',target:null};
 if(strong.length===1){const target=strong[0];
  if(name&&normText(target.name)!==name)return {type:'review',reason:'당원번호 일치하지만 이름 상이',target};
  if(birth&&target.birth&&birth!==target.birth)return {type:'review',reason:'생년월일 충돌',target};
  if(member&&target.member&&normText(target.member)!==member)return {type:'review',reason:'당원번호 충돌',target};
  if(phoneMatches.some(c=>c.id!==target.id))return {type:'review',reason:'전화번호가 다른 등록자와 일치',target};
  return {type:'merge',reason:'동일인 확인(당원번호 또는 이름+생년월일)',target};
 }
 if(phoneMatches.length)return {type:'review',reason:'전화번호만 일치 — 동일인 수동 확인 필요',target:phoneMatches[0]};
 return {type:'new',reason:'신규',target:null};
}
function mergeExtra(target,incoming){
 const next={...target,affiliations:affiliations(target).map(a=>({...a})),recs:(target.recs||[]).map(r=>({...r}))};
 const changes=[];
 for(const a of affiliations(incoming)){
  if(!a.group)continue;
  if(!next.affiliations.some(x=>normText(x.group)===normText(a.group)&&normText(x.role)===normText(a.role))){next.affiliations.push({group:a.group,role:a.role||''});changes.push('단체·직책: '+a.group+' / '+(a.role||'직책 없음'))}
 }
 for(const r of incoming.recs||[]){if(!r?.name)continue;
  if(!next.recs.some(x=>(r.contactId&&x.contactId===r.contactId)||(!r.contactId&&!x.contactId&&normText(x.name)===normText(r.name)))){
   next.recs.push({id:uid(),name:r.name,contactId:r.contactId||null});changes.push('추천인: '+r.name)
  }
 }
 if(incoming.memo&&normText(incoming.memo)!==normText(next.memo)&&!String(next.memo||'').includes(incoming.memo)){
  next.memo=next.memo?next.memo+'\n[가져온 메모] '+incoming.memo:incoming.memo;changes.push('메모 추가')
 }
 for(const k of ['birthplace','occupation','landline','postcode']){
  if(incoming[k]&&!next[k]){next[k]=incoming[k];changes.push(k+' 추가')}
 }
 // 수신거절은 병합 시 절대 자동 해제하지 않으며, 새 거절 신청만 강화 적용
 const priority={none:0,'':0,sms:1,call:1,both:2};
 if(incoming.refusal&&incoming.refusal!=='none'&&next.refusal!==incoming.refusal){
  if(!next.refusal||next.refusal==='none'||incoming.refusal==='both'){
   next.refusal=incoming.refusal;next.refusalChangedAt=new Date().toISOString();changes.push('수신거절 적용')
  }else if((next.refusal==='sms'&&incoming.refusal==='call')||(next.refusal==='call'&&incoming.refusal==='sms')){
   next.refusal='both';next.refusalChangedAt=new Date().toISOString();changes.push('수신거절 통합')
  }
 }
 // Missing primary fields are intentionally not filled automatically.
 const conflicts=[];
 for(const k of ['phone','address','detail','district','committee','birth','member','occupation','birthplace','landline']){
  if(incoming[k]&&target[k]&&normText(incoming[k])!==normText(target[k]))conflicts.push(k+' 상이');
 }
 return {next,changes,conflicts};
}
async function applyMergedImport(source,sourceName){
 const working=data.map(c=>({...c,affiliations:affiliations(c).map(a=>({...a})),recs:(c.recs||[]).map(r=>({...r}))}));
 const newRows=[],merged=[],review=[],idMap=new Map(),processed=[];
 for(let i=0;i<source.length;i++){
  const entry=source[i],c=entry.o,old=entry.old||c;
  if(!c.name?.trim()){review.push({index:i+1,name:'(이름 없음)',reason:'이름 누락'});continue}
  try{c.birth=formatBirth(c.birth);c.phone=formatPhone(c.phone);c.landline=formatPhone(c.landline||'')}catch(e){review.push({index:i+1,name:c.name,reason:e.message});continue}
  const decision=identityDecision(c,working);
  if(decision.type==='review'){review.push({index:i+1,name:c.name,reason:decision.reason});continue}
  if(decision.type==='new'){
   const added={...c,id:uid(),affiliations:affiliations(c).map(a=>({...a})),recs:(c.recs||[]).map(r=>({...r}))};
   working.push(added);newRows.push({index:i+1,name:c.name,record:added});processed.push({added,old});
   if(old.id)idMap.set(old.id,added.id);
  }else{
   const target=decision.target,change=mergeExtra(target,c);
   const idx=working.findIndex(x=>x.id===target.id);working[idx]=change.next;
   merged.push({index:i+1,name:c.name,changes:change.changes,conflicts:change.conflicts});
   if(old.id)idMap.set(old.id,target.id);
  }
 }
 // Restore known recommender links from v9 IDs without changing original contact IDs.
 for(const {added,old} of processed){
  for(let i=0;i<added.recs.length;i++){
   const raw=old.recs?.[i];if(raw?.contactId&&idMap.has(raw.contactId))added.recs[i].contactId=idMap.get(raw.contactId);
  }
  if(old.primary){const primaryOld=(old.recs||[]).find(r=>r.id===old.primary);if(primaryOld){const found=added.recs.find(r=>normText(r.name)===normText(primaryOld.name));if(found)added.primary=found.id}}
 }
 const details=merged.slice(0,40).map(x=>x.name+': '+(x.changes.join(', ')||'추가할 정보 없음')+(x.conflicts.length?' [검토: '+x.conflicts.join(', ')+']':''));
 const warning=review.slice(0,20).map(x=>x.name+': '+x.reason);
 const summary=`${sourceName} ${source.length}건 검사\n신규 ${newRows.length}명 / 병합 ${merged.length}건 / 확인 필요 ${review.length}건\n\n[병합 예정]\n${details.join('\n')||'없음'}\n\n[수동 확인]\n${warning.join('\n')||'없음'}\n\n기존 주요 정보는 덮어쓰지 않습니다. 진행할까요?`;
 if(!confirm(summary))return;
 const before=await encryptedPayload(),prior=data;
 try{data=working;await save()}catch(e){data=prior;throw e}
 try{localStorage.setItem('district-addressbook-v10-pre-merge-'+Date.now(),before)}catch(e){alert('자동 이전본 저장 실패. 암호화 JSON 백업을 별도로 저장하세요.')}
 render();close();$('importpreview').classList.add('hidden');
 const report=[['순번','이름','결과','내용'],...newRows.map(x=>[x.index,x.name,'신규','등록']),...merged.map(x=>[x.index,x.name,'병합',x.changes.join('; ')+(x.conflicts.length?' / 변경후보: '+x.conflicts.join('; '):'')]),...review.map(x=>[x.index,x.name,'확인 필요',x.reason])];
 downloadCSV(report,'주소록_가져오기_병합결과_'+new Date().toISOString().slice(0,10)+'.csv');
 alert(`가져오기 완료\n신규 ${newRows.length}명 / 병합 ${merged.length}건 / 확인 필요 ${review.length}건\n병합 결과 CSV를 다운로드했습니다.`);
}

$('backup').onclick=async()=>{let blob=new Blob([await encryptedPayload()],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='addressbook-encrypted-backup-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};$('restore').onchange=async e=>{let file=e.target.files[0];if(!file)return;try{if(file.size>5e6)throw Error('5MB 이하의 파일만 복원할 수 있습니다.');let parsed=JSON.parse(await file.text());if(parsed.format==='district-addressbook-demo-v1'){
 if(!Array.isArray(parsed.contacts)||parsed.contacts.length>20000)throw Error('v9 연락처 배열이 올바르지 않습니다.');
 const rows=parsed.contacts.map(c=>{const o={...c,id:uid(),affiliations:affiliations(c).map(a=>({...a})),recs:Array.isArray(c.recs)?c.recs.map(r=>({...r})):[]};return {o,old:c}});
 await applyMergedImport(rows,'v9 백업');
 }else if(parsed.format==='district-addressbook-encrypted-v10'){
 let password=prompt('백업 파일의 비밀번호를 입력하세요.');if(password===null)return;let opened=await decryptPayload(parsed,password);let incoming=opened.contacts;if(!confirm(`현재 ${data.length}명 데이터를 백업 파일의 ${incoming.length}명으로 교체할까요? 먼저 현재 데이터를 백업하는 것을 권장합니다.`))return;let old=data;try{data=incoming;events=opened.events||[];await save()}catch(err){data=old;throw err}render();close();alert('복원이 완료되었습니다.')
 }else throw Error('지원하지 않는 백업 형식입니다. v9 또는 v10 JSON을 선택해 주세요.')
 }catch(err){alert('복원 실패: '+err.message)}finally{e.target.value=''}};
// Excel/CSV import: no external libraries or network requests.
let pending=null;
const headerAliases={name:['이름','성명','성함','name'],birth:['생년월일','생일','출생일','birth'],phone:['전화번호','휴대전화','휴대폰','핸드폰','연락처','휴대전화번호','phone'],member:['당원번호','당원 번호','member'],district:['행정동','동','지역','district'],committee:['지역위원회','소속 지역위원회','위원회'],postcode:['우편번호','우편 번호','postcode','zip'],address:['주소','도로명주소','거주지'],detail:['상세주소','주소상세'],group:['소속단체','소속 단체','단체','소속'],role:['직책','직위'],memo:['메모','비고','참고'],recs:['추천인','추천인명','추천인 이름'],landline:['일반전화','유선전화','집전화','지역번호'],occupation:['직업','업종'],birthplace:['출생지','태어난곳'],refusal:['수신거절','연락거절'],refusalReason:['수신거절 사유','거절사유']};
const cleanHeader=v=>String(v||'').trim().toLowerCase().replace(/[\s_()]/g,'');
function parseCSV(t){t=t.replace(/^\ufeff/,'');let rows=[],row=[],cell='',quoted=false;for(let i=0;i<t.length;i++){let c=t[i];if(quoted){if(c==='"'&&t[i+1]==='"'){cell+='"';i++}else if(c==='"')quoted=false;else cell+=c}else if(c==='"')quoted=true;else if(c===','){row.push(cell);cell=''}else if(c==='\n'||c==='\r'){if(c==='\r'&&t[i+1]==='\n')i++;row.push(cell);if(row.some(x=>x.trim()))rows.push(row);row=[];cell=''}else cell+=c}if(quoted)throw Error('CSV 따옴표가 닫히지 않았습니다.');row.push(cell);if(row.some(x=>x.trim()))rows.push(row);return rows}
function csvEscape(v){let t=String(v??'');if(/^[=+@\-\t\r]/.test(t))t="'"+t;return '"'+t.replace(/"/g,'""')+'"'}
function downloadCSV(rows,name){let csv='\ufeff'+rows.map(r=>r.map(csvEscape).join(',')).join('\r\n');let url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));let a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500)}
$('template').onclick=()=>downloadCSV([['이름','생년월일','휴대전화','일반전화','당원번호','행정동','지역위원회','우편번호','주소','상세주소','출생지','직업','소속 단체','직책','추천인','수신거절','수신거절 사유','메모'],['홍길동','1990-01-01','010-0000-0000','032-000-0000','DEMO-001','원종동','부천시(갑)','00000','가상 주소','101호','서울특별시','자영업','주민자치회','위원','이가상','sms','시험용','가상 데이터']], '주소록_CSV_가져오기_양식.csv');
const utf8=b=>new TextDecoder('utf-8').decode(b);
async function unzipXlsx(buf){let v=new DataView(buf),u=new Uint8Array(buf),end=-1;for(let i=u.length-22;i>=Math.max(0,u.length-65557);i--)if(v.getUint32(i,true)===0x06054b50){end=i;break}if(end<0)throw Error('올바른 XLSX 파일이 아닙니다.');let count=v.getUint16(end+10,true),pos=v.getUint32(end+16,true),out={};for(let i=0;i<count;i++){if(v.getUint32(pos,true)!==0x02014b50)throw Error('ZIP 목록 오류');let method=v.getUint16(pos+10,true),size=v.getUint32(pos+20,true),n=v.getUint16(pos+28,true),extra=v.getUint16(pos+30,true),comment=v.getUint16(pos+32,true),off=v.getUint32(pos+42,true),name=utf8(u.slice(pos+46,pos+46+n));pos+=46+n+extra+comment;if(!/^(xl\/(worksheets\/sheet\d+\.xml|sharedStrings\.xml|styles\.xml|workbook\.xml|_rels\/workbook\.xml\.rels))$/.test(name))continue;if(size>30e6)throw Error('시트 크기가 너무 큽니다.');let start=off+30+v.getUint16(off+26,true)+v.getUint16(off+28,true);let compressed=u.slice(start,start+size);if(method===0)out[name]=utf8(compressed);else if(method===8){if(typeof DecompressionStream==='undefined')throw Error('이 브라우저에서는 XLSX 압축 해제가 지원되지 않습니다. CSV로 저장 후 업로드해 주세요.');let stream=new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate-raw'));out[name]=utf8(new Uint8Array(await new Response(stream).arrayBuffer()))}else throw Error('지원되지 않는 XLSX 압축 방식입니다.')}return out}
function excelDate(n){let d=new Date(Date.UTC(1899,11,30)+Number(n)*86400000);return Number.isFinite(d.getTime())?d.toISOString().slice(0,10):String(n)}
async function parseXlsx(file){let z=await unzipXlsx(await file.arrayBuffer()),parser=new DOMParser(),parse=t=>parser.parseFromString(t,'application/xml');let strings=[];if(z['xl/sharedStrings.xml']){let doc=parse(z['xl/sharedStrings.xml']);strings=[...doc.getElementsByTagName('si')].map(si=>[...si.getElementsByTagName('t')].map(x=>x.textContent).join(''))}let path=Object.keys(z).filter(x=>/^xl\/worksheets\/sheet\d+\.xml$/.test(x)).sort((a,b)=>Number(a.match(/\d+/g).at(-1))-Number(b.match(/\d+/g).at(-1)))[0];if(!path)throw Error('엑셀 시트를 찾지 못했습니다.');let doc=parse(z[path]);if(doc.getElementsByTagName('parsererror').length)throw Error('엑셀 XML 읽기 오류');let rows=[];for(let r of doc.getElementsByTagName('row')){let arr=[];for(let c of r.getElementsByTagName('c')){let ref=c.getAttribute('r')||'',letters=(ref.match(/^[A-Z]+/)||['A'])[0],idx=0;for(let ch of letters)idx=idx*26+ch.charCodeAt(0)-64;idx--;let type=c.getAttribute('t'),node=c.getElementsByTagName('v')[0],raw=node?.textContent||'';if(type==='inlineStr')raw=[...c.getElementsByTagName('t')].map(t=>t.textContent).join('');else if(type==='s')raw=strings[Number(raw)]||'';arr[idx]=raw}rows.push(arr.map(x=>x??''));if(rows.length>25000)throw Error('최대 25,000행까지 지원합니다.')}return rows}
function toContacts(rows){if(rows.length<2)throw Error('제목 행과 데이터 행이 필요합니다.');let headers=rows[0].map(x=>String(x||'').trim()),mapping={};for(let [field,aliases] of Object.entries(headerAliases)){let idx=headers.findIndex(h=>aliases.some(a=>cleanHeader(a)===cleanHeader(h)));if(idx>=0)mapping[field]=idx}if(mapping.name===undefined)throw Error('첫 번째 행에 이름 또는 성명 열이 필요합니다.');let results=[];for(let i=1;i<rows.length;i++){let row=rows[i];if(!row.some(x=>String(x||'').trim()))continue;let o={id:uid()};fields.forEach(k=>o[k]=mapping[k]===undefined?'':String(row[mapping[k]]??'').trim());if(o.birth){if(/^\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2}/.test(o.birth)){let m=o.birth.match(/^(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})/);o.birth=`${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`}else if(/^\d{5}(\.\d+)?$/.test(o.birth))o.birth=excelDate(o.birth)}let rs=mapping.recs===undefined?'':String(row[mapping.recs]||'');let gs=o.group.split(/[;、\n]/).map(x=>x.trim()),roles=o.role.split(/[;、\n]/).map(x=>x.trim());o.affiliations=gs.map((group,i)=>({group,role:roles[i]||''})).filter(a=>a.group);o.recs=rs.split(/[,;、\n]/).map(x=>x.trim()).filter(Boolean).map(name=>({id:uid(),name}));o.primary=null;results.push({o,row,rowNumber:i+1});}return {headers,results}}
function previewImport(rows){let {headers,results}=toContacts(rows);if(results.length>20000)throw Error('20,000명 이하로 업로드해 주세요.');
 pending={headers,results};$('importpreview').classList.remove('hidden');
 $('importsummary').textContent=`${results.length}건 검사 준비 · 확인 버튼을 누르면 신규/병합/검토 내역을 먼저 보여줍니다.`;
 $('importconfirm').disabled=!results.length;$('duplicatesdownload').disabled=true;
 $('importrows').innerHTML=results.slice(0,80).map(x=>`<tr><td>${x.rowNumber}</td><td>${esc(x.o.name)}</td><td>검사 대기</td><td>확인 후 처리</td></tr>`).join('');$('importpreview').scrollIntoView({behavior:'smooth'})}
$('importfile').onchange=async e=>{let file=e.target.files[0];if(!file)return;try{if(file.size>15e6)throw Error('15MB 이하 파일만 지원합니다.');let rows=/\.xlsx$/i.test(file.name)?await parseXlsx(file):/\.csv$/i.test(file.name)?parseCSV(await file.text()):null;if(!rows)throw Error('xlsx 또는 csv 파일만 업로드할 수 있습니다.');previewImport(rows)}catch(err){alert('업로드 검사 실패: '+err.message)}finally{e.target.value=''}};
$('importcancel').onclick=()=>{pending=null;$('importpreview').classList.add('hidden')};
$('duplicatesdownload').onclick=()=>alert('가져오기 승인 후 결과 CSV가 자동 다운로드됩니다.');
$('importconfirm').onclick=async()=>{if(!pending)return;try{await applyMergedImport(pending.results.map(x=>({o:x.o,old:x.o})),'엑셀/CSV');pending=null}catch(err){alert('가져오기 실패: '+err.message)}};

// v11 행사 달력과 참석자 관리. 모든 행사 데이터는 주소록과 함께 암호화 저장됨.
let calendarYear=new Date().getFullYear(),calendarMonth=new Date().getMonth(),selectedEvent=null,editingEvent=null;
const safeDate=s=>/^\d{4}-\d{2}-\d{2}$/.test(s||'');
function eventCounts(c){return events.reduce((n,e)=>n+Object.entries(e.attendees||{}).filter(([id,status])=>id===c.id&&status==='attended').length,0)}
function drawCalendar(){const first=new Date(calendarYear,calendarMonth,1).getDay(),days=new Date(calendarYear,calendarMonth+1,0).getDate();$('eventMonth').textContent=`${calendarYear}년 ${calendarMonth+1}월`;let html=['일','월','화','수','목','금','토'].map(x=>`<div class="event-week">${x}</div>`).join('');for(let i=0;i<first;i++)html+='<div></div>';for(let d=1;d<=days;d++){let date=`${calendarYear}-${String(calendarMonth+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,items=events.filter(e=>e.date===date);html+=`<button type="button" class="event-day" data-day="${date}"><b>${d}</b>${items.slice(0,2).map(e=>`<small>${esc(e.title)}</small>`).join('')}${items.length>2?`<small>+${items.length-2}개</small>`:''}</button>`}$('eventCalendar').innerHTML=html;drawEventList()}
function drawEventList(){let prefix=`${calendarYear}-${String(calendarMonth+1).padStart(2,'0')}`,list=events.filter(e=>e.date.startsWith(prefix)).sort((a,b)=>a.date.localeCompare(b.date));$('eventDetails').innerHTML='<h3>이번 달 행사</h3>'+(list.length?list.map(e=>{let statuses=Object.values(e.attendees||{});return `<div class="event-row"><b>${esc(e.date)} · ${esc(e.title)}</b> <span class="muted">${esc(e.place||'')}</span><p class="muted">실제 참석 ${statuses.filter(x=>x==='attended').length}명 / 예정 ${statuses.filter(x=>x==='planned').length}명 / 불참 ${statuses.filter(x=>x==='absent').length}명</p><div class="actions"><button data-event-att="${esc(e.id)}">참석자 관리</button><button data-event-edit="${esc(e.id)}">행사 수정</button><button data-event-delete="${esc(e.id)}" class="danger">삭제</button></div></div>`}).join(''):'<p class="muted">등록된 행사가 없습니다.</p>')}
function editEvent(e,date){editingEvent=e?.id||null;$('eventTitle').value=e?.title||'';$('eventDate').value=e?.date||date||new Date().toISOString().slice(0,10);$('eventPlace').value=e?.place||'';$('eventEditorTitle').textContent=e?'행사 수정':'새 행사 등록';$('eventEditor').classList.remove('hidden');$('eventEditor').scrollIntoView({behavior:'smooth',block:'nearest'})}
$('eventPrev').onclick=()=>{calendarMonth--;if(calendarMonth<0){calendarMonth=11;calendarYear--}drawCalendar()};$('eventNext').onclick=()=>{calendarMonth++;if(calendarMonth>11){calendarMonth=0;calendarYear++}drawCalendar()};$('eventNew').onclick=()=>editEvent(null);$('eventCancel').onclick=()=>$('eventEditor').classList.add('hidden');$('eventCalendar').onclick=e=>{let b=e.target.closest('[data-day]');if(b)editEvent(null,b.dataset.day)};
$('eventSave').onclick=async()=>{let title=$('eventTitle').value.trim(),date=$('eventDate').value,place=$('eventPlace').value.trim();if(!title||!safeDate(date)){alert('행사명과 날짜를 입력하세요.');return}let old=events.map(x=>({...x}));if(editingEvent){let e=events.find(x=>x.id===editingEvent);if(e)Object.assign(e,{title,date,place})}else events.push({id:uid(),title,date,place,attendees:{}});try{await save();$('eventEditor').classList.add('hidden');calendarYear=+date.slice(0,4);calendarMonth=+date.slice(5,7)-1;drawCalendar()}catch(err){events=old;alert('행사 저장 실패: '+err.message)}};
$('eventDetails').onclick=async e=>{let b=e.target.closest('button');if(!b)return;let id=b.dataset.eventAtt||b.dataset.eventEdit||b.dataset.eventDelete,ev=events.find(x=>x.id===id);if(!ev)return;if(b.dataset.eventAtt)openAttendance(ev);if(b.dataset.eventEdit)editEvent(ev);if(b.dataset.eventDelete&&confirm('행사를 삭제하면 해당 행사 참석 이력도 삭제됩니다. 삭제할까요?')){events=events.filter(x=>x.id!==id);await save();drawCalendar()}};
function openAttendance(ev){selectedEvent=ev.id;$('attendanceTitle').textContent=`${ev.title} · 참석자 관리`;$('attendanceSearch').value='';$('attendanceEditor').classList.remove('hidden');drawAttendance();$('attendanceEditor').scrollIntoView({behavior:'smooth',block:'nearest'})}
function drawAttendance(){let ev=events.find(x=>x.id===selectedEvent);if(!ev)return;let q=$('attendanceSearch').value.trim().toLowerCase(),filtered=data.filter(c=>[c.name,c.phone,c.landline,c.district].some(v=>String(v||'').toLowerCase().includes(q)));$('attendancePeople').innerHTML=filtered.length?filtered.map(c=>`<div class="attendee"><div><b>${esc(c.name)}</b><div class="muted">${esc(c.district||'')} · ${esc(c.phone||c.landline||'번호 없음')} · 누적 ${eventCounts(c)}회</div></div><select data-person="${esc(c.id)}"><option value="">미등록</option><option value="planned" ${ev.attendees?.[c.id]==='planned'?'selected':''}>참석 예정</option><option value="attended" ${ev.attendees?.[c.id]==='attended'?'selected':''}>실제 참석</option><option value="absent" ${ev.attendees?.[c.id]==='absent'?'selected':''}>불참</option></select></div>`).join(''):'<p>검색 결과가 없습니다.</p>'}
$('attendanceSearch').oninput=drawAttendance;$('attendanceClose').onclick=()=>$('attendanceEditor').classList.add('hidden');$('attendanceSave').onclick=async()=>{let ev=events.find(x=>x.id===selectedEvent);if(!ev)return;ev.attendees=ev.attendees||{};for(let sel of $('attendancePeople').querySelectorAll('[data-person]')){if(sel.value)ev.attendees[sel.dataset.person]=sel.value;else delete ev.attendees[sel.dataset.person]}try{await save();drawCalendar();drawAttendance();alert('참석 상태를 저장했습니다.')}catch(err){alert('저장 실패: '+err.message)}};
$('attendanceExport').onclick=()=>{let ev=events.find(x=>x.id===selectedEvent);if(!ev)return;let rows=[['행사명','날짜','이름','휴대전화','일반전화','행정동','참석 상태']];for(let [id,status] of Object.entries(ev.attendees||{})){let c=data.find(x=>x.id===id);if(c)rows.push([ev.title,ev.date,c.name,c.phone,c.landline||'',c.district,status==='attended'?'실제 참석':status==='planned'?'참석 예정':'불참'])}downloadCSV(rows,'행사_참석자_'+ev.date+'.csv')};
// 주소록 갱신 및 잠금 해제 시 행사 달력도 갱신

$('attendanceImport').onchange=async e=>{
 const file=e.target.files[0];if(!file)return;
 try{
  if(file.size>15e6)throw Error('15MB 이하 파일만 지원합니다.');
  const rows=/\.xlsx$/i.test(file.name)?await parseXlsx(file):/\.csv$/i.test(file.name)?parseCSV(await file.text()):null;
  if(!rows||rows.length<2)throw Error('이름/당원번호 열이 포함된 CSV 또는 XLSX 파일이 필요합니다.');
  const h=rows[0].map(x=>cleanHeader(x)),idx=aliases=>h.findIndex(x=>aliases.some(a=>cleanHeader(a)===x));
  const ni=idx(['이름','성명']),mi=idx(['당원번호']),bi=idx(['생년월일']),pi=idx(['휴대전화','전화번호']),si=idx(['참석상태','참석 여부','상태']);
  if(ni<0&&mi<0)throw Error('이름 또는 당원번호 열이 필요합니다.');
  const statusMap={'참석':'attended','실제참석':'attended','참석완료':'attended','attended':'attended','예정':'planned','참석예정':'planned','planned':'planned','불참':'absent','absent':'absent'};
  const updates=[],reviews=[];
  for(let i=1;i<rows.length;i++){
   const row=rows[i];if(!row.some(x=>String(x||'').trim()))continue;
   const name=ni>=0?String(row[ni]||'').trim():'',member=mi>=0?String(row[mi]||'').trim():'',rawBirth=bi>=0?String(row[bi]||'').trim():'';
   let birth='';try{if(rawBirth)birth=formatBirth(rawBirth)}catch(err){reviews.push(`${i+1}행 ${name}: 생년월일 오류`);continue}
   let matches=member?data.filter(c=>normText(c.member)===normText(member)):[];
   if(!matches.length&&name&&birth)matches=data.filter(c=>normText(c.name)===normText(name)&&c.birth===birth);
   if(matches.length!==1){reviews.push(`${i+1}행 ${name||member}: ${matches.length?'동일인 후보 다수':'일치하는 DB 없음 (이름만으로 연결하지 않음)'}`);continue}
   const c=matches[0];if(name&&normText(name)!==normText(c.name)){reviews.push(`${i+1}행: 당원번호 일치, 이름 충돌`);continue}
   let status=si<0?'attended':statusMap[String(row[si]||'').trim().replace(/\s/g,'')];
   if(!status){reviews.push(`${i+1}행 ${name}: 참석 상태 오류`);continue}
   updates.push({id:c.id,name:c.name,status});
  }
  const ev=events.find(x=>x.id===selectedEvent);if(!ev)throw Error('행사를 먼저 선택하세요.');
  const unique=new Map(updates.map(x=>[x.id,x]));
  const preview=`행사: ${ev.title}\n일괄 반영 대상 ${unique.size}명 / 확인 필요 ${reviews.length}행\n\n`+Array.from(unique.values()).slice(0,30).map(x=>x.name+' — '+x.status).join('\n')+'\n\n[확인 필요]\n'+(reviews.slice(0,30).join('\n')||'없음')+'\n\n반영할까요?';
  if(!confirm(preview))return;
  const previous=structuredClone(ev.attendees||{});ev.attendees=ev.attendees||{};
  for(const u of unique.values())ev.attendees[u.id]=u.status;
  try{await save()}catch(err){ev.attendees=previous;throw err}
  drawCalendar();drawAttendance();
  downloadCSV([['행','검토 사유'],...reviews.map((r,i)=>[i+1,r])],'행사_일괄등록_확인필요.csv');
  alert(`반영 ${unique.size}명 / 확인 필요 ${reviews.length}행`);
 }catch(err){alert('행사 참석자 가져오기 실패: '+err.message)}finally{e.target.value=''}
};

const priorRender=render;render=function(){priorRender();drawCalendar()};
})();
