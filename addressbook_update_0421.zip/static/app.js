
(()=>{'use strict';const KEY='district-addressbook-demo-encrypted-v10';const OLD_KEY='district-addressbook-demo-v1';const fields=['name','birth','phone','member','district','committee','postcode','address','detail','group','role','memo','birthplace','occupation','landline','refusal','refusalReason'];const $=id=>document.getElementById(id);let selectedIds=new Set(),lastFound=[],lastPageItems=[],profileReturn=null,contactPage=1,contactPageSize=(()=>{const v=localStorage.getItem('addressbook-page-size');return v==='all'?'all':([10,30,100].includes(Number(v))?Number(v):30)})();let institutions=[],anonymous=[];let events=[],data=[],members=[],organizations=[],donors=[],editing=null,recs=[],primary=null,affs=[],activeSearch="",activeField="name";const uid=()=>crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random();let vaultKey=null,vaultSalt=null;const te=new TextEncoder(),td=new TextDecoder();const b64=a=>{const u=new Uint8Array(a);let s='';for(let i=0;i<u.length;i+=32768)s+=String.fromCharCode.apply(null,u.subarray(i,i+32768));return btoa(s)};async function streamBytes(bytes,stream){return new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(stream)).arrayBuffer())}async function gzipBytes(bytes){if(typeof CompressionStream==='undefined')throw Error('이 브라우저는 압축 저장을 지원하지 않습니다. Edge 또는 Chrome 최신 버전을 사용해 주세요.');return streamBytes(bytes,new CompressionStream('gzip'))}async function gunzipBytes(bytes){if(typeof DecompressionStream==='undefined')throw Error('이 브라우저는 압축 해제를 지원하지 않습니다. Edge 또는 Chrome 최신 버전을 사용해 주세요.');return streamBytes(bytes,new DecompressionStream('gzip'))}const un64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));async function derive(p,s){const k=await crypto.subtle.importKey('raw',te.encode(p),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt:s,iterations:250000,hash:'SHA-256'},k,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])}async function encryptedPayload(){if(!vaultKey)throw Error('먼저 잠금을 해제하세요.');const iv=crypto.getRandomValues(new Uint8Array(12));const ct=await crypto.subtle.encrypt({name:'AES-GCM',iv},vaultKey,await gzipBytes(te.encode(JSON.stringify({contacts:data,events,members,organizations,donors,institutions,anonymous}))));return JSON.stringify({format:'district-addressbook-encrypted-v11',compression:'gzip',salt:b64(vaultSalt),iv:b64(iv),ciphertext:b64(ct)})}async function decryptPayload(obj,p){if(obj.format!=='district-addressbook-encrypted-v10'&&obj.format!=='district-addressbook-encrypted-v11')throw Error('지원하지 않는 암호화 파일입니다. (새 버전에서 만든 파일이면 프로그램을 업데이트해 주세요)');const salt=un64(obj.salt),k=await derive(p,salt);const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:un64(obj.iv)},k,un64(obj.ciphertext));const parsed=JSON.parse(td.decode(obj.compression==='gzip'?await gunzipBytes(plain):plain));return {salt,key:k,contacts:normalize(Array.isArray(parsed)?parsed:parsed.contacts),events:Array.isArray(parsed.events)?parsed.events:[],members:Array.isArray(parsed.members)?parsed.members:[],organizations:Array.isArray(parsed.organizations)?parsed.organizations:[],institutions:Array.isArray(parsed.institutions)?parsed.institutions:[],anonymous:Array.isArray(parsed.anonymous)?parsed.anonymous:[],donors:Array.isArray(parsed.donors)?parsed.donors:[]}}async function save(){absorbAnonymous();const payload=await encryptedPayload();await window.vaultStore.set(payload)}function lockVault(){selectedIds.clear();lastFound=[];profileReturn=null;document.getElementById('returnBar')?.remove();$('personFullPage')?.classList.add('hidden');$('list')?.closest('section.panel')?.classList.remove('hidden');events=[];data=[];members=[];organizations=[];donors=[];institutions=[];anonymous=[];vaultKey=null;vaultSalt=null;$('vaultContent').classList.add('hidden');$('vault').classList.remove('hidden');$('vaultPassword').value='';$('vaultMessage').textContent='잠겼습니다.';['memberRows','orgRows','donorRows','donationHistory'].forEach(id=>{const el=$(id);if(el)el.innerHTML=''});['memberEditor','orgEditor','donorEditor'].forEach(id=>$(id)?.classList.add('hidden'))}async function openVault(){try{if(!crypto.subtle)throw Error('브라우저가 Web Crypto를 지원하지 않습니다.');const p=$('vaultPassword').value;if(p.length<8)throw Error('비밀번호는 8자 이상이어야 합니다.');const stored=window.vaultStore.get();if(stored){const o=await decryptPayload(JSON.parse(stored),p);vaultKey=o.key;vaultSalt=o.salt;data=o.contacts;events=o.events||[];members=o.members||[];organizations=o.organizations||[];donors=o.donors||[];institutions=o.institutions||[];anonymous=o.anonymous||[]}else{vaultSalt=crypto.getRandomValues(new Uint8Array(16));vaultKey=await derive(p,vaultSalt);data=sample();events=[];members=[];organizations=[];donors=[];institutions=[];anonymous=[];await save()}$('vaultPassword').value='';$('vault').classList.add('hidden');$('vaultContent').classList.remove('hidden');await reconcileExistingRecords();await save();render();renderMembers();renderDonors();renderInstitutions();renderAnonymous()}catch(e){vaultKey=null;vaultSalt=null;$('vaultMessage').textContent='열기 실패: '+e.message}}$('vaultOpen').onclick=openVault;$('vaultLock').onclick=lockVault;
function sample(){return [{id:uid(),name:'김가상',birth:'1975-03-15',phone:'010-0000-0001',member:'DEMO-001',district:'원종동',committee:'부천시(갑)',address:'가상 주소 1',detail:'',group:'통장협의회',role:'회원',memo:'시험용 가상 데이터',recs:[{id:uid(),name:'이가상'},{id:uid(),name:'박가상'}],primary:null},{id:uid(),name:'이가상',birth:'',phone:'010-0000-0002',member:'DEMO-002',district:'고강동',committee:'부천시(갑)',address:'',detail:'',group:'주민자치회',role:'',memo:'',recs:[],primary:null}]}function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}function affiliations(c){return Array.isArray(c.affiliations)?c.affiliations:((c.group||c.role)?[{group:c.group||'',role:c.role||''}]:[])}function affRender(){$('affs').innerHTML=affs.map((a,i)=>`<span class="tag">${esc(a.group||'(단체 미입력)')} / ${esc(a.role||'(직책 미입력)')} <button type="button" data-aff-remove="${i}" aria-label="소속 삭제">×</button></span>`).join('')}function addAff(){let group=$('group').value.trim(),role=$('role').value.trim();if(!group&&!role)return true;if(!group){alert('소속 단체명을 입력해 주세요.');return false}if(affs.some(a=>normText(a.group)===normText(group)&&normText(a.role)===normText(role))){alert('동일한 단체와 직책이 이미 등록되어 있습니다.');return false}affs.push({group,role});$('group').value='';$('role').value='';affRender();return true}let activePhoneTab='mobile';
function render(){
 const q=activeSearch.toLowerCase(),field=activeField;
 let found=data.filter(c=>{
  if(activePhoneTab==='mobile'&&!c.phone)return false;
  if(activePhoneTab==='landline'&&!c.landline)return false;
  if(!q)return true;
  let values=field==='name'?[c.name]:field==='phone'?[c.phone,c.landline]:field==='recommender'?(c.recs||[]).map(r=>r.name):field==='group'?affiliations(c).map(a=>a.group):field==='role'?affiliations(c).map(a=>a.role):field==='occupation'?[c.occupation]:field==='birthplace'?[c.birthplace]:field==='refusal'?[c.refusal]:[...fields.map(k=>c[k]),...affiliations(c).flatMap(a=>[a.group,a.role]),...(c.recs||[]).map(r=>r.name)];
  if(field==='phone'){let digits=q.replace(/\D/g,'');return digits?values.some(v=>String(v||'').replace(/\D/g,'').includes(digits)):false}
  return values.some(v=>String(v||'').toLowerCase().includes(q));
 });
 const allIds=new Set(data.map(c=>c.id));for(const id of [...selectedIds])if(!allIds.has(id))selectedIds.delete(id);lastFound=found;
 const size=contactPageSize==='all'?Math.max(found.length,1):contactPageSize,pages=Math.max(1,Math.ceil(found.length/size));if(contactPage>pages)contactPage=pages;if(contactPage<1)contactPage=1;
 const pageItems=found.slice((contactPage-1)*size,contactPage*size);lastPageItems=pageItems;drawPager(found.length,pages,size);
 $('count').textContent=`${found.length}명 / 전체 ${data.length}명`;
 document.querySelectorAll('[data-phone-tab]').forEach(b=>{b.classList.toggle('tab-selected',b.dataset.phoneTab===activePhoneTab);b.classList.toggle('primary',b.dataset.phoneTab===activePhoneTab)});
 $('list').innerHTML=pageItems.map(c=>`<tr class="${selectedIds.has(c.id)?'row-selected':''}"><td class="sel"><input type="checkbox" data-select="${esc(c.id)}" ${selectedIds.has(c.id)?'checked':''} aria-label="${esc(c.name)} 선택"></td><td><strong>${esc(c.name)}</strong></td><td>${esc(c.birth||'')}</td><td>${esc(activePhoneTab==='landline'?c.landline:activePhoneTab==='mobile'?c.phone:[c.phone,c.landline].filter(Boolean).join(' / '))}</td><td>${esc(c.district)}</td><td>${esc(c.occupation||'')}<div class="mini">${esc(c.birthplace||'')}</div></td><td>${esc(affiliations(c).map(a=>[a.group,a.role].filter(Boolean).join(' / ')).join(', '))}</td><td>${(c.recs||[]).map(r=>{let st=recStatus(r);return esc(r.name)+' <small style="color:'+(st.contact?'#166534':'#9a3412')+'">['+(st.contact?'DB 등록':'미등록')+']</small>'}).join(', ')}</td><td class="${c.refusal&&c.refusal!=='none'?'status-no':''}">${esc(refusalLabel(c.refusal))}</td><td>${eventCounts(c)}회 <button data-history="${esc(c.id)}">이력</button></td><td><button data-person-detail="${esc(c.id)}">통합정보</button> <button data-edit="${esc(c.id)}">수정</button> <button class="danger" data-delete="${esc(c.id)}">삭제</button></td></tr>`).join('')||'<tr><td colspan="11">표시할 연락처가 없습니다.</td></tr>';
 updateBulkBar();
}
function drawPager(total,pages,size){
 const el=$('contactPager');if(!el)return;
 const from=total?(contactPage-1)*size+1:0,to=Math.min(total,contactPage*size);
 let nums=[];const add=n=>{if(!nums.includes(n)&&n>=1&&n<=pages)nums.push(n)};add(1);for(let n=contactPage-2;n<=contactPage+2;n++)add(n);add(pages);nums.sort((a,b)=>a-b);
 let btns='';let prev=0;for(const n of nums){if(n-prev>1)btns+='<span class="muted">…</span>';btns+=`<button type="button" data-page="${n}" class="${n===contactPage?'primary':''}" ${n===contactPage?'aria-current="page"':''}>${n}</button>`;prev=n}
 el.innerHTML=`<span class="muted">${total?`${from}–${to}번째 표시 / 총 ${total}명`:'표시할 연락처 없음'}</span><span class="actions" style="align-items:center">${pages>1?`<button type="button" data-page="${contactPage-1}" ${contactPage===1?'disabled':''}>◀ 이전</button>${btns}<button type="button" data-page="${contactPage+1}" ${contactPage===pages?'disabled':''}>다음 ▶</button>`:''}<label for="pageSize" style="margin:0 0 0 8px">표시 개수</label><select id="pageSize" style="width:auto">${[10,30,100,'all'].map(v=>`<option value="${v}" ${String(contactPageSize)===String(v)?'selected':''}>${v==='all'?'전체보기':v+'명씩'}</option>`).join('')}</select></span>`;
}
function refusalLabel(v){return ({none:'정상',sms:'문자 거절',call:'전화 거절',both:'전체 거절'})[v]||'정상'}
// v0.4.17: 당원·후원인 목록도 주소록처럼 10·30·100명씩 / 전체보기로 나눠 보기
const listPagers={};
function listPager(key,boxId,rerender){
 if(listPagers[key])return listPagers[key];
 const saved=(()=>{try{return localStorage.getItem('addressbook-page-size-'+key)}catch(e){return null}})();
 const st={page:1,size:saved==='all'?'all':([10,30,100].includes(Number(saved))?Number(saved):30),q:null};
 st.slice=(rows,q)=>{if(q!==st.q){st.q=q;st.page=1}const size=st.size==='all'?Math.max(rows.length,1):st.size,pages=Math.max(1,Math.ceil(rows.length/size));if(st.page>pages)st.page=pages;if(st.page<1)st.page=1;
  const el=$(boxId);if(el){const total=rows.length,from=total?(st.page-1)*size+1:0,to=Math.min(total,st.page*size);
   let nums=[];const add=n=>{if(!nums.includes(n)&&n>=1&&n<=pages)nums.push(n)};add(1);for(let n=st.page-2;n<=st.page+2;n++)add(n);add(pages);nums.sort((a,b)=>a-b);
   let btns='',prev=0;for(const n of nums){if(n-prev>1)btns+='<span class="muted">…</span>';btns+=`<button type="button" data-lp="${n}" class="${n===st.page?'primary':''}" ${n===st.page?'aria-current="page"':''}>${n}</button>`;prev=n}
   el.innerHTML=`<span class="muted">${total?`${from.toLocaleString()}–${to.toLocaleString()}번째 표시 / 총 ${total.toLocaleString()}명`:'표시할 항목 없음'}</span><span class="actions" style="align-items:center">${pages>1?`<button type="button" data-lp="${st.page-1}" ${st.page===1?'disabled':''}>◀ 이전</button>${btns}<button type="button" data-lp="${st.page+1}" ${st.page===pages?'disabled':''}>다음 ▶</button>`:''}<label style="margin:0 0 0 8px">표시 개수</label><select data-lp-size style="width:auto">${[10,30,100,'all'].map(v=>`<option value="${v}" ${String(st.size)===String(v)?'selected':''}>${v==='all'?'전체보기':v+'명씩'}</option>`).join('')}</select></span>`}
  return rows.slice((st.page-1)*size,st.page*size)};
 const el=$(boxId);
 if(el){el.addEventListener('click',e=>{const b=e.target.closest('[data-lp]');if(!b||b.disabled)return;st.page=Number(b.dataset.lp);rerender();el.closest('section')?.scrollIntoView({block:'start'})});
  el.addEventListener('change',e=>{if(!e.target.matches('[data-lp-size]'))return;st.size=e.target.value==='all'?'all':Number(e.target.value);try{localStorage.setItem('addressbook-page-size-'+key,String(st.size))}catch(err){}st.page=1;rerender()})}
 return listPagers[key]=st;
}
$('phoneTabs').onclick=e=>{const b=e.target.closest('[data-phone-tab]');if(b){activePhoneTab=b.dataset.phoneTab;contactPage=1;render()}};
function recStatus(r){let linked=r.contactId?data.find(c=>c.id===r.contactId):null;return linked?{kind:'등록',contact:linked}: {kind:'미등록',contact:null}}
function recRender(){$('recs').innerHTML=recs.map(r=>{let st=recStatus(r);return `<span class="tag">${esc(r.name)} <strong style="color:${st.contact?'#166534':'#9a3412'}">[${st.contact?'DB 등록':'미등록'}]</strong> ${st.contact?`<button type="button" data-view-rec="${esc(st.contact.id)}">정보 보기</button>`:''}<button type="button" data-primary="${esc(r.id)}">${primary===r.id?'★ 대표':'☆ 대표 지정'}</button><button type="button" data-remove="${esc(r.id)}" aria-label="추천인 삭제">×</button></span>`}).join('');showRecMatches()}
function showRecMatches(){let v=$('recommender').value.trim();let matches=v?data.filter(c=>c.id!==editing&&normText(c.name).includes(normText(v))).slice(0,12):[];$('recMatches').innerHTML=matches.length?'<div style="margin:8px 0">DB 검색 결과 — 아래에서 해당 인물을 선택하면 등록자로 연결됩니다.</div>'+matches.map(c=>`<button type="button" data-link-rec="${esc(c.id)}" style="margin:2px">${esc(c.name)} (${esc(c.phone||'전화번호 없음')}) · DB 등록</button>`).join(''):v?'<div style="margin:8px 0">일치하는 DB 등록자를 찾지 못했습니다. 이름만 추가하면 미등록으로 표시됩니다.</div>':''}
function addRec(name,contactId=null){if(recs.some(r=>contactId?r.contactId===contactId:!r.contactId&&normText(r.name)===normText(name))){alert('이미 등록된 추천인입니다.');return}recs.push({id:uid(),name,contactId});$('recommender').value='';recRender()}
function open(c){editing=c?.id||null;fields.forEach(k=>$(k).value=c?.[k]||'');if(c?.rrn_demo&&!c?.birth)$('birth').value=c.rrn_demo;affs=affiliations(c||{}).map(a=>({...a}));$('group').value='';$('role').value='';affRender();recs=(c?.recs||[]).map(r=>({...r}));primary=c?.primary||null;$('formtitle').textContent=editing?'연락처 수정':'새 연락처 등록';$('editor').classList.remove('hidden');recRender();$('editor').scrollIntoView({behavior:'smooth'})}function close(){$('editor').classList.add('hidden');editing=null}function normPhone(v){return String(v||'').replace(/[^0-9]/g,'')}function normText(v){return String(v||'').trim().replace(/\s+/g,' ').toLowerCase()}function dateValid(y,m,d){let dt=new Date(Date.UTC(y,m-1,d));return dt.getUTCFullYear()===y&&dt.getUTCMonth()===m-1&&dt.getUTCDate()===d}
function formatBirth(value){let v=String(value||'').trim();if(!v)return '';if(/^DEMO-/i.test(v)){if(!/^DEMO-\d{6}-\d{7}$/i.test(v))throw Error('가상번호는 DEMO-900729-1234567 형식이어야 합니다.');return v.toUpperCase()}
let digits=v.replace(/[-.\/\s]/g,'');if(!/^\d+$/.test(digits))throw Error('생년월일은 숫자 6자리 또는 8자리로 입력해 주세요.');if(digits.length!==6&&digits.length!==8)throw Error(`생년월일 숫자는 6자리 또는 8자리여야 합니다. 현재 ${digits.length}자리입니다.`);
let year,month,day;if(digits.length===6){let yy=Number(digits.slice(0,2)),cutoff=new Date().getFullYear()%100;year=(yy<=cutoff?2000:1900)+yy;month=Number(digits.slice(2,4));day=Number(digits.slice(4,6))}else{year=Number(digits.slice(0,4));month=Number(digits.slice(4,6));day=Number(digits.slice(6,8))}if(!dateValid(year,month,day))throw Error('실제 존재하는 생년월일을 입력해 주세요.');if(new Date(Date.UTC(year,month-1,day))>new Date())throw Error('미래 생년월일은 입력할 수 없습니다.');return `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`}
function formatPhone(value){let v=String(value||'').trim();if(!v)return '';if(/[^0-9\s().-]/.test(v))throw Error('전화번호는 숫자와 하이픈(-)만 입력해 주세요.');let d=v.replace(/\D/g,'');if(d.startsWith('010')){if(d.length!==11)throw Error(`010으로 시작하는 전화번호는 010 뒤에 숫자 8자리가 필요합니다. 현재 ${Math.max(0,d.length-3)}자리입니다.`);return `010-${d.slice(3,7)}-${d.slice(7)}`}
if(d.length<9||d.length>11)throw Error(`전화번호 자릿수를 확인해 주세요. 현재 ${d.length}자리입니다.`);if(d.startsWith('02'))return `02-${d.slice(2,-4)}-${d.slice(-4)}`;return `${d.slice(0,3)}-${d.slice(3,-4)}-${d.slice(-4)}`}
function duplicateOf(o,arr,exclude){return arr.find(c=>c.id!==exclude&&((normPhone(o.phone)&&normPhone(o.phone)===normPhone(c.phone))||(normText(o.member)&&normText(o.member)===normText(c.member))||(normText(o.name)&&o.birth&&normText(o.name)===normText(c.name)&&o.birth===c.birth)))}function normalize(v){
 if(!Array.isArray(v)||v.length>500000)throw Error('유효한 주소록 배열이 아닙니다.');
 const used=new Set();let normalized=v.map(c=>{
  if(!c||typeof c!=='object'||typeof c.name!=='string'||!c.name.trim())throw Error('이름이 없는 연락처가 있습니다.');
  let id=typeof c.id==='string'&&c.id&&!used.has(c.id)?c.id:uid();used.add(id);
  let o={id};fields.forEach(k=>o[k]=String(c[k]??(k==='birth'?c.rrn_demo:'')??'').slice(0,k==='memo'?3000:300));
  o.recs=Array.isArray(c.recs)?c.recs.slice(0,100).map(r=>({id:String(r?.id||uid()),name:String(r?.name||'').slice(0,80),contactId:r?.contactId||null})).filter(r=>r.name):[];
  o.primary=o.recs.some(r=>r.id===c.primary)?c.primary:null;
  o.refusalChangedAt=String(c.refusalChangedAt||'');
  o.affiliations=affiliations(c).slice(0,100).map(a=>({group:String(a.group||'').slice(0,100),role:String(a.role||'').slice(0,100)}));return o
 });
 {const byPhone=new Map(),byMember=new Map(),byNameBirth=new Map();for(const c of normalized){const ph=normPhone(c.phone),mn=normText(c.member),nb=normText(c.name)&&c.birth?normText(c.name)+'|'+c.birth:'';const dup=(ph&&byPhone.get(ph))||(mn&&byMember.get(mn))||(nb&&byNameBirth.get(nb));if(dup)throw Error('백업 파일에 중복 연락처가 있습니다: '+c.name+' / '+dup.name);if(ph)byPhone.set(ph,c);if(mn)byMember.set(mn,c);if(nb)byNameBirth.set(nb,c)}}
 return normalized
}
function runSearch(){activeField=$('searchField').value;activeSearch=$('search').value.trim();contactPage=1;render()}$('searchBtn').addEventListener('click',runSearch);$('search').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();runSearch()}});$('searchClear').addEventListener('click',()=>{$('search').value='';activeSearch='';contactPage=1;activeField=$('searchField').value;render()});$('searchField').addEventListener('change',()=>{const names={name:'이름',phone:'전화번호',recommender:'추천인',group:'소속 단체',role:'직책',occupation:'직업',birthplace:'출생지',refusal:'수신거절',all:'전체 항목'};$('search').placeholder=(names[$('searchField').value]||'검색어')+' 입력 후 검색'});$('new').onclick=()=>open(null);$('cancel').onclick=close;$('reset').onclick=()=>{if(confirm('현재 입력을 초기화할까요?'))open(null)};$('addaff').onclick=addAff;$('affs').onclick=e=>{let b=e.target.closest('button');if(b&&b.dataset.affRemove!==undefined){affs.splice(Number(b.dataset.affRemove),1);affRender()}};$('addrec').onclick=()=>{let name=$('recommender').value.trim();if(!name)return;let matches=data.filter(c=>c.id!==editing&&normText(c.name)===normText(name));if(matches.length){alert('DB에 같은 이름이 있습니다. 아래 검색 결과에서 전화번호를 확인해 해당 인물을 선택하거나, 미등록 추천인으로 추가할 수 있습니다.')}addRec(name)};$('recommender').addEventListener('input',showRecMatches);$('recMatches').onclick=e=>{let b=e.target.closest('button[data-link-rec]');if(!b)return;let c=data.find(x=>x.id===b.dataset.linkRec);if(c)addRec(c.name,c.id)};$('recommender').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('addrec').click()}});$('recs').onclick=e=>{let b=e.target.closest('button');if(!b)return;if(b.dataset.remove){recs=recs.filter(r=>r.id!==b.dataset.remove);if(primary===b.dataset.remove)primary=null}else if(b.dataset.primary){primary=primary===b.dataset.primary?null:b.dataset.primary}else if(b.dataset.viewRec){let c=data.find(x=>x.id===b.dataset.viewRec);if(c)alert('DB 등록 추천인\n이름: '+c.name+'\n전화번호: '+(c.phone||'없음')+'\n행정동: '+(c.district||'없음'))}recRender()};$('birth').addEventListener('blur',()=>{let el=$('birth');if(!el.value.trim())return;try{el.value=formatBirth(el.value)}catch(err){el.setCustomValidity(err.message);el.reportValidity();return}el.setCustomValidity('')});$('birth').addEventListener('input',()=> $('birth').setCustomValidity(''));$('phone').addEventListener('blur',()=>{let el=$('phone');if(!el.value.trim())return;try{el.value=formatPhone(el.value)}catch(err){el.setCustomValidity(err.message);el.reportValidity();return}el.setCustomValidity('')});$('phone').addEventListener('input',()=> $('phone').setCustomValidity(''));// 카카오 우편번호 검색은 외부 서비스가 필요하지만 연락처는 로컬에만 저장합니다.
let postcodeLoading=null;
function loadPostcode(){if(window.kakao?.Postcode||window.daum?.Postcode)return Promise.resolve();if(postcodeLoading)return postcodeLoading;postcodeLoading=new Promise((resolve,reject)=>{
 // v0.4.19: 카카오 주소(새 주소)와 다음 주소(예전 주소) 중 되는 쪽을 차례로 시도
 const urls=['https://t1.kakaocdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js','https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js'];
 const tryAt=i=>{if(i>=urls.length){reject(Error('인터넷 연결 또는 주소 검색 서비스 접속을 확인하세요.'));return}let script=document.createElement('script');script.src=urls[i];script.onload=()=>window.kakao?.Postcode||window.daum?.Postcode?resolve():tryAt(i+1);script.onerror=()=>{script.remove();tryAt(i+1)};document.head.appendChild(script)};tryAt(0)}).catch(e=>{postcodeLoading=null;throw e});return postcodeLoading}
$('postcodeSearch').onclick=async()=>{let btn=$('postcodeSearch');btn.disabled=true;try{await loadPostcode();let Postcode=window.kakao?.Postcode||window.daum?.Postcode;new Postcode({oncomplete:function(d){$('postcode').value=d.zonecode||'';$('address').value=d.userSelectedType==='J'?(d.jibunAddress||d.address):(d.roadAddress||d.address);const adminDong=String(d.hname||'').trim();$('district').value=adminDong;$('districtHint').textContent=adminDong?'행정동 자동 입력 완료: '+adminDong+' (필요하면 수정 가능)':'검색 결과에 행정동 정보가 없어 직접 입력해 주세요. 법정동과 행정동은 다를 수 있습니다.';$('detail').focus();}}).open()}catch(e){alert(e.message+'\n주소는 직접 입력할 수도 있습니다.')}finally{btn.disabled=false}};
$('postcode').addEventListener('blur',()=>{let v=$('postcode').value.trim();if(v&&!/^\d{5}$/.test(v)){ $('postcode').setCustomValidity('우편번호는 숫자 5자리로 입력하세요.');$('postcode').reportValidity()}else $('postcode').setCustomValidity('')});$('postcode').addEventListener('input',()=> $('postcode').setCustomValidity(''));
$('form').onsubmit=async e=>{e.preventDefault();let o={id:editing||uid()};fields.forEach(k=>o[k]=$(k).value.trim());try{o.birth=formatBirth(o.birth);o.phone=formatPhone(o.phone);o.landline=formatPhone(o.landline);
 const mobile=v=>/^(010|011|016|017|018|019)/.test(v||'');
 if(o.phone&&!mobile(o.phone)){if(!o.landline){o.landline=o.phone;o.phone=''}else throw Error('일반전화 번호가 두 개 입력됐습니다. 한 개만 등록할 수 있습니다.')}
 if(o.landline&&mobile(o.landline)){if(!o.phone){o.phone=o.landline;o.landline=''}else throw Error('휴대전화 번호가 두 개 입력됐습니다. 한 개만 등록할 수 있습니다.')}
 }catch(err){alert(err.message);return}if(($('group').value.trim()||$('role').value.trim())&&!addAff())return;o.affiliations=affs.map(a=>({...a}));o.group=o.affiliations.map(a=>a.group).join('; ');o.role=o.affiliations.map(a=>a.role).join('; ');o.recs=recs.map(r=>({...r}));o.primary=primary;const prev=data.find(c=>c.id===editing);o.refusalChangedAt=prev?.refusalChangedAt||'';if((prev?.refusal||'none')!==(o.refusal||'none'))o.refusalChangedAt=new Date().toISOString();if(!o.name){alert('이름을 입력하세요.');return}let dup=duplicateOf(o,data,editing);if(dup){alert(`중복 등록이 차단되었습니다.\n기존 연락처: ${dup.name}\n전화번호, 당원번호 또는 이름+생년월일이 일치합니다.\n기존 연락처를 수정해 주세요.`);return;}if(editing){let i=data.findIndex(c=>c.id===editing);if(i>=0)data[i]=o;else data.push(o)}else data.push(o);for(const m of members.filter(x=>x.contactId===o.id)){m.memberName=o.name;m.mobilePhone=o.phone;m.homePhone=o.landline;m.memberNo=o.member||m.memberNo;m.adminDong=o.district;m.roadAddress=o.address;m.postcode=o.postcode}for(const d of donors.filter(x=>x.contactId===o.id)){d.name=o.name;d.phone=o.phone;d.address=o.address}await save();render();close();window.scrollTo({top:0,behavior:'smooth'})};$('list').onclick=async e=>{let b=e.target.closest('button');if(!b)return;if(b.dataset.history){let c=data.find(x=>x.id===b.dataset.history);if(c){let h=events.filter(ev=>ev.attendees?.[c.id]).sort((a,b)=>evSort(b,a));alert(c.name+' 행사 참석 이력 (실제 참석 '+eventCounts(c)+'회)\n'+(h.map(ev=>ev.date+' '+(timeRange(ev)?timeRange(ev)+' ':'')+ev.title+' — '+({attended:'실제 참석',planned:'참석 예정',absent:'불참'}[ev.attendees[c.id]]||'')).join('\n')||'등록된 이력 없음'))}}if(b.dataset.edit){let c=data.find(c=>c.id===b.dataset.edit);if(c)open(c)}if(b.dataset.delete){openDeleteDialog([b.dataset.delete])}};// Offline XLSX writer: text cells preserve leading zeroes in phone numbers and member IDs.
function xesc(v){return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;').replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g,'')}
function colName(n){let s='';for(n++;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s}
function crc32(u){let c=0xffffffff;for(let b of u){c^=b;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0)}return (c^0xffffffff)>>>0}
function zipStore(files){let enc=new TextEncoder(),chunks=[],central=[],offset=0;const u16=n=>[n&255,(n>>>8)&255],u32=n=>[n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255];for(let [name,content] of files){let nb=enc.encode(name),b=enc.encode(content),crc=crc32(b),local=new Uint8Array([...u32(0x04034b50),...u16(20),...u16(0),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(b.length),...u32(b.length),...u16(nb.length),...u16(0),...nb]);chunks.push(local,b);central.push(new Uint8Array([...u32(0x02014b50),...u16(20),...u16(20),...u16(0),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(b.length),...u32(b.length),...u16(nb.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset),...nb]));offset+=local.length+b.length}let cdsize=central.reduce((n,a)=>n+a.length,0);return new Blob([...chunks,...central,new Uint8Array([...u32(0x06054b50),...u16(0),...u16(0),...u16(files.length),...u16(files.length),...u32(cdsize),...u32(offset),...u16(0)])],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})}
function excelBackup(){let headers=['이름','생년월일 / 가상 주민등록번호','휴대전화','일반전화','직업','출생지','수신거절','수신거절 사유','당원번호','행정동','소속 지역위원회','우편번호','주소','상세주소','소속 단체','직책','추천인','대표 추천인','메모'];let rows=[headers,...data.map(c=>{let a=affiliations(c);let rs=Array.isArray(c.recs)?c.recs:[];let pr=rs.find(r=>r.id===c.primary);return [c.name,c.birth,c.phone,c.landline||'',c.occupation||'',c.birthplace||'',c.refusal||'',c.refusalReason||'',c.member,c.district,c.committee,c.postcode||'',c.address,c.detail,a.map(x=>x.group).join('; '),a.map(x=>x.role).join('; '),rs.map(x=>x.name).join('; '),pr?.name||'',c.memo]})];let xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetData>'+rows.map((r,i)=>'<row r="'+(i+1)+'">'+r.map((v,j)=>'<c r="'+colName(j)+(i+1)+'" t="inlineStr"><is><t xml:space="preserve">'+xesc(v)+'</t></is></c>').join('')+'</row>').join('')+'</sheetData><autoFilter ref="A1:S'+rows.length+'"/></worksheet>';let files=[['[Content_Types].xml','<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'],['_rels/.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],['xl/workbook.xml','<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="주소록" sheetId="1" r:id="rId1"/></sheets></workbook>'],['xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'],['xl/worksheets/sheet1.xml',xml]];let url=URL.createObjectURL(zipStore(files)),a=document.createElement('a');a.href=url;a.download='지역위원회_주소록_백업_'+new Date().toISOString().slice(0,10)+'.xlsx';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000)}
$('excelbackup').onclick=()=>{try{excelBackup()}catch(err){alert('엑셀 백업 실패: '+err.message)}};

// Shared, conservative merge engine. Strong matches: unique party ID or name+birth;
// phone alone is never sufficient for an automatic identity decision.
function identityDecision(incoming,arr){
 const member=normText(incoming.member), name=normText(incoming.name), birth=incoming.birth;
 const strong=arr.filter(c=>(member&&normText(c.member)===member)||(name&&birth&&normText(c.name)===name&&c.birth===birth));
 const phone=normPhone(incoming.phone);
 const phoneMatches=phone?arr.filter(c=>normPhone(c.phone)===phone):[];
 const exact=name&&phone?arr.filter(c=>normText(c.name)===name&&normPhone(c.phone)===phone):[];
 if(exact.length>1)return {type:'review',reason:'동일 이름·휴대폰번호 연락처가 여러 명',target:null};
 if(exact.length===1)return {type:'merge',reason:'이름+휴대폰번호 일치',target:exact[0]};
 // 번호는 같은데 이름이 다름: 신규 등록하지 않고 기존 연락처 메모에 '○○ 번호 중복'을 남김
 if(phoneMatches.length===1&&!strong.some(c=>c.id!==phoneMatches[0].id))return {type:'phonedup',reason:'번호는 같고 이름이 다름',target:phoneMatches[0]};
 const sameName=name?arr.filter(c=>normText(c.name)===name):[];
 if(sameName.length&&!strong.length){
  // 동명이인: 새 휴대폰번호가 있고, 같은 이름의 기존 연락처들과 번호가 모두 다르면 다른 사람으로 신규 등록
  if(phone&&!phoneMatches.length&&sameName.every(c=>normPhone(c.phone)&&normPhone(c.phone)!==phone))return {type:'new',reason:'동명이인 — 휴대폰번호가 달라 신규 등록',target:null};
  return {type:'review',reason:phone?'이름이 같은 연락처의 번호가 비어 있어 동일인 여부 확인 필요':'이름이 같은 연락처가 있고 휴대폰번호가 없어 확인 필요',target:null};
 }
 if(strong.length>1)return {type:'review',reason:'복수의 동일인 후보',target:null};
 if(strong.length===1){const target=strong[0];
  if(phone&&normPhone(target.phone)&&phone!==normPhone(target.phone))return {type:'review',reason:'이름+생년월일(또는 당원번호)이 같은 연락처의 휴대폰번호가 다름 — 번호 변경인지 확인 필요',target};
  if(name&&normText(target.name)!==name)return {type:'review',reason:'당원번호 일치하지만 이름 상이',target};
  if(birth&&target.birth&&birth!==target.birth)return {type:'review',reason:'생년월일 충돌',target};
  if(member&&target.member&&normText(target.member)!==member)return {type:'review',reason:'당원번호 충돌',target};
  if(phoneMatches.some(c=>c.id!==target.id))return {type:'review',reason:'전화번호가 다른 등록자와 일치',target};
  return {type:'merge',reason:'동일인 확인(당원번호 또는 이름+생년월일)',target};
 }
 if(phoneMatches.length)return {type:'review',reason:'전화번호만 일치 — 동일인 수동 확인 필요',target:phoneMatches[0]};
 return {type:'new',reason:'신규',target:null};
}
// v0.4.6 엑셀 가져오기 규칙: 이름+휴대폰번호가 같으면 같은 사람. 모든 정보가 같으면 중복(건너뜀),
// 다른 정보가 있으면 엑셀의 새 값으로 업데이트(빈 칸은 기존 값 유지).
const IMPORT_UPDATE_FIELDS=[['birth','생년월일'],['phone','휴대전화'],['landline','일반전화'],['member','당원번호'],['district','행정동'],['committee','지역위원회'],['postcode','우편번호'],['address','주소'],['detail','상세주소'],['birthplace','출생지'],['occupation','직업'],['refusalReason','수신거절 사유'],['memo','메모']];
function normRefusal(v){const t=String(v||'').replace(/\s/g,'').toLowerCase();if(!t)return '';if(['sms','문자','문자거절','문자수신거절'].includes(t))return 'sms';if(['call','전화','전화거절','전화수신거절'].includes(t))return 'call';if(['both','전체','전체거절','문자·전화거절','문자전화거절','문자,전화','모두'].includes(t))return 'both';if(['none','없음','정상','해당없음'].includes(t))return 'none';return String(v).trim()}
function mergeExtra(target,incoming){
 const next={...target,affiliations:affiliations(target).map(a=>({...a})),recs:(target.recs||[]).map(r=>({...r}))};
 const changes=[];
 for(const [k,label] of IMPORT_UPDATE_FIELDS){
  const v=String(incoming[k]??'').trim();
  if(v&&normText(v)!==normText(next[k])){changes.push(`${label}: ${next[k]||'(없음)'} → ${v}`);next[k]=v}
 }
 const r=normRefusal(incoming.refusal);
 if(r&&(r||'none')!==(next.refusal||'none')){changes.push(`수신거절: ${refusalLabel(next.refusal)} → ${refusalLabel(r)}`);next.refusal=r;next.refusalChangedAt=new Date().toISOString()}
 for(const a of affiliations(incoming)){
  if(!a.group)continue;
  if(!next.affiliations.some(x=>normText(x.group)===normText(a.group)&&normText(x.role)===normText(a.role))){next.affiliations.push({group:a.group,role:a.role||''});changes.push('소속 추가: '+a.group+(a.role?' / '+a.role:''))}
 }
 if(changes.some(x=>x.startsWith('소속 추가'))){next.group=next.affiliations.map(a=>a.group).join('; ');next.role=next.affiliations.map(a=>a.role).join('; ')}
 for(const rc of incoming.recs||[]){if(!rc?.name)continue;
  if(!next.recs.some(x=>(rc.contactId&&x.contactId===rc.contactId)||(!rc.contactId&&!x.contactId&&normText(x.name)===normText(rc.name)))){next.recs.push({id:uid(),name:rc.name,contactId:rc.contactId||null});changes.push('추천인 추가: '+rc.name)}
 }
 return {next,changes,conflicts:[]};
}
async function applyMergedImport(source,sourceName){
 const working=data.map(c=>({...c,affiliations:affiliations(c).map(a=>({...a})),recs:(c.recs||[]).map(r=>({...r}))}));
 const newRows=[],merged=[],dupes=[],phoneDups=[],review=[],idMap=new Map(),processed=[];
 // v0.4.13: 이름이 비어 있고 번호만 있는 줄은 익명 번호로 등록
 const anonWork=anonymous.map(a=>({...a})),anonAdded=[],anonSkipped=[];
 for(let i=0;i<source.length;i++){
  const entry=source[i],c=entry.o,old=entry.old||c;
  const rv=(reason,target)=>{const same=working.filter(x=>normText(x.name)===normText(c.name)||(target&&x.id===target.id));const ex=(target?[target,...same.filter(x=>x.id!==target.id)]:same).slice(0,3).map(x=>x.name+' '+(x.phone||'번호없음')+(x.birth?' ('+x.birth+')':'')).join(', ');review.push({index:entry.row||i+2,name:c.name||'(이름 없음)',phone:String(c.phone||''),birth:String(c.birth||''),district:String(c.district||''),existing:ex,reason})};
  if(!c.name?.trim()){
   if(!String(c.phone||'').trim()){rv('이름과 휴대전화가 모두 없음');continue}
   let ph;try{ph=formatPhone(c.phone)}catch(e){rv('이름 없음 · '+e.message);continue}
   const d=normPhone(ph);
   if(anonWork.some(a=>normPhone(a.phone)===d)||working.some(x=>normPhone(x.phone)===d||normPhone(x.landline)===d)){anonSkipped.push({index:entry.row||i+2,phone:ph});continue}
   const a={id:uid(),phone:ph,source:'주소록 엑셀',district:String(c.district||'').trim(),memo:String(c.memo||'').trim().slice(0,500),date:new Date().toISOString().slice(0,10)};
   anonWork.push(a);anonAdded.push({index:entry.row||i+2,phone:ph});continue
  }
  try{c.birth=formatBirth(c.birth);c.phone=formatPhone(c.phone);c.landline=formatPhone(c.landline||'');c.refusal=normRefusal(c.refusal)}catch(e){rv(e.message);continue}
  const decision=identityDecision(c,working);
  if(decision.type==='review'){rv(decision.reason,decision.target);continue}
  if(decision.type==='phonedup'){
   const t=decision.target,idx=working.findIndex(x=>x.id===t.id),note=c.name.trim()+' 번호 중복';
   if(String(t.memo||'').includes(note)){dupes.push({index:i+1,name:c.name});continue}
   const next={...working[idx],memo:(working[idx].memo?working[idx].memo+'\n':'')+note};
   if(next.memo.length>3000){rv('기존 연락처 메모가 가득 차 번호 중복 기록을 남기지 못함',t);continue}
   working[idx]=next;phoneDups.push({index:entry.row||i+2,name:c.name,existing:t.name,phone:t.phone});continue
  }
  if(decision.type==='new'){
   const added={...c,id:uid(),affiliations:affiliations(c).map(a=>({...a})),recs:(c.recs||[]).map(r=>({...r}))};
   if(added.refusal&&added.refusal!=='none')added.refusalChangedAt=new Date().toISOString();
   if(duplicateOf(added,working,null)){rv('당원번호 또는 이름+생년월일이 다른 연락처와 겹침',duplicateOf(added,working,null));continue}
   working.push(added);newRows.push({index:i+1,name:c.name,record:added});processed.push({added,old});
   if(old.id)idMap.set(old.id,added.id);
  }else{
   const target=decision.target,change=mergeExtra(target,c);
   if(!change.changes.length){dupes.push({index:i+1,name:c.name});if(old.id)idMap.set(old.id,target.id);continue}
   const clash=duplicateOf(change.next,working,target.id);
   if(clash){rv(`업데이트하면 다른 연락처(${clash.name})와 휴대폰·당원번호·이름+생년월일이 겹침`,clash);continue}
   const idx=working.findIndex(x=>x.id===target.id);working[idx]=change.next;
   merged.push({index:i+1,name:c.name,changes:change.changes});
   if(old.id)idMap.set(old.id,target.id);
  }
 }
 for(const {added,old} of processed){
  for(let i=0;i<added.recs.length;i++){const raw=old.recs?.[i];if(raw?.contactId&&idMap.has(raw.contactId))added.recs[i].contactId=idMap.get(raw.contactId)}
  if(old.primary){const primaryOld=(old.recs||[]).find(r=>r.id===old.primary);if(primaryOld){const found=added.recs.find(r=>normText(r.name)===normText(primaryOld.name));if(found)added.primary=found.id}}
 }
 const details=merged.slice(0,30).map(x=>x.name+': '+x.changes.join(', '));
 const warning=review.slice(0,20).map(x=>'엑셀 '+x.index+'행 '+x.name+' '+(x.phone||'번호없음')+': '+x.reason+(x.existing?' [기존: '+x.existing+']':''));
 const summary=`${sourceName} ${source.length}건 검사\n신규 등록 ${newRows.length}명 / 정보 업데이트 ${merged.length}명 / 번호 중복 메모 ${phoneDups.length}건 / 완전 중복(건너뜀) ${dupes.length}건 / 확인 필요 ${review.length}건${anonAdded.length||anonSkipped.length?`\n이름 없는 번호 → 익명 번호 탭에 등록 ${anonAdded.length}건${anonSkipped.length?` / 이미 등록된 번호라 건너뜀 ${anonSkipped.length}건`:''}`:''}\n\n[업데이트 내용]\n${details.join('\n')||'없음'}${merged.length>30?'\n… 외 '+(merged.length-30)+'명':''}\n\n[번호는 같고 이름이 다름 — 기존 연락처 메모에 기록]\n${phoneDups.slice(0,20).map(x=>'엑셀 '+x.index+'행 '+x.name+' → 기존 '+x.existing+' '+x.phone+' 메모에 "'+x.name+' 번호 중복"').join('\n')||'없음'}\n\n[확인 필요 — 등록하지 않음]\n${warning.join('\n')||'없음'}\n\n엑셀의 빈 칸은 기존 정보를 지우지 않습니다. 반영 전 자동 백업됩니다. 진행할까요?`;
 if(!confirm(summary))return;
 const before=await encryptedPayload(),prior=data;
 try{await serverBackup(before,'엑셀 가져오기 전 자동백업')}catch(e){alert('자동 백업에 실패해 가져오기를 중단했습니다: '+e.message);return}
 const priorAnon=anonymous;
 try{data=working;anonymous=anonWork;await reconcileExistingRecords();await save()}catch(e){data=prior;anonymous=priorAnon;throw e}
 renderAnonymous();
 render();close();$('importpreview').classList.add('hidden');
 if(review.length)downloadCSV([['엑셀 행','이름','휴대전화','생년월일','행정동','확인 필요 사유','비교할 기존 연락처(이름 번호 생년월일)'],...review.map(x=>[x.index,x.name,x.phone,x.birth,x.district,x.reason,x.existing])],'주소록_가져오기_확인필요_'+new Date().toISOString().slice(0,10)+'.csv');
 alert(`가져오기 완료\n신규 등록 ${newRows.length}명 / 정보 업데이트 ${merged.length}명 / 번호 중복 메모 ${phoneDups.length}건 / 완전 중복 건너뜀 ${dupes.length}건 / 확인 필요 ${review.length}건`+(anonAdded.length?`\n이름 없는 번호 ${anonAdded.length}건은 익명 번호 탭에 등록했습니다.`:'')+(review.length?'\n확인 필요 목록만 CSV로 내려받았습니다.':''));
}

$('backup').onclick=async()=>{let blob=new Blob([await encryptedPayload()],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='addressbook-encrypted-backup-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};$('restore').onchange=async e=>{let file=e.target.files[0];if(!file)return;try{if(file.size>5e6)throw Error('5MB 이하의 파일만 복원할 수 있습니다.');let parsed=JSON.parse(await file.text());if(parsed.format==='district-addressbook-demo-v1'){
 if(!Array.isArray(parsed.contacts)||parsed.contacts.length>20000)throw Error('v9 연락처 배열이 올바르지 않습니다.');
 const rows=parsed.contacts.map(c=>{const o={...c,id:uid(),affiliations:affiliations(c).map(a=>({...a})),recs:Array.isArray(c.recs)?c.recs.map(r=>({...r})):[]};return {o,old:c}});
 await applyMergedImport(rows,'v9 백업');
 }else if(parsed.format==='district-addressbook-encrypted-v10'){
 let password=prompt('백업 파일의 비밀번호를 입력하세요.');if(password===null)return;let opened=await decryptPayload(parsed,password);let incoming=opened.contacts;if(!confirm(`현재 ${data.length}명 데이터를 백업 파일의 ${incoming.length}명으로 교체할까요? 먼저 현재 데이터를 백업하는 것을 권장합니다.`))return;let old=data,oldEvents=events,oldMembers=members,oldOrganizations=organizations,oldDonors=donors,oldInstitutions=institutions,oldAnonymous=anonymous;try{data=incoming;events=opened.events||[];members=opened.members||[];organizations=opened.organizations||[];donors=opened.donors||[];institutions=opened.institutions||[];anonymous=opened.anonymous||[];await save()}catch(err){institutions=oldInstitutions;anonymous=oldAnonymous;data=old;events=oldEvents;members=oldMembers;organizations=oldOrganizations;donors=oldDonors;throw err}render();close();alert('복원이 완료되었습니다.')
 }else throw Error('지원하지 않는 백업 형식입니다. v9 또는 v10 JSON을 선택해 주세요.')
 }catch(err){alert('복원 실패: '+err.message)}finally{e.target.value=''}};
// Excel/CSV import: no external libraries or network requests.
let pending=null;
const headerAliases={name:['이름','성명','성함','name'],birth:['생년월일','생일','출생일','birth'],phone:['전화번호','휴대전화','휴대폰','핸드폰','연락처','휴대전화번호','phone'],member:['당원번호','당원 번호','member'],district:['행정동','동','지역','district'],committee:['지역위원회','소속 지역위원회','위원회'],postcode:['우편번호','우편 번호','postcode','zip'],address:['주소','도로명주소','거주지'],detail:['상세주소','주소상세'],group:['소속단체','소속 단체','단체','소속'],role:['직책','직위'],memo:['메모','비고','참고'],recs:['추천인','추천인명','추천인 이름'],landline:['일반전화','유선전화','집전화','지역번호'],occupation:['직업','업종'],birthplace:['출생지','태어난곳'],refusal:['수신거절','연락거절'],refusalReason:['수신거절 사유','거절사유']};
const cleanHeader=v=>String(v||'').trim().toLowerCase().replace(/[\s_()]/g,'');
function parseCSV(t){t=t.replace(/^\ufeff/,'');let rows=[],row=[],cell='',quoted=false;for(let i=0;i<t.length;i++){let c=t[i];if(quoted){if(c==='"'&&t[i+1]==='"'){cell+='"';i++}else if(c==='"')quoted=false;else cell+=c}else if(c==='"')quoted=true;else if(c===','){row.push(cell);cell=''}else if(c==='\n'||c==='\r'){if(c==='\r'&&t[i+1]==='\n')i++;row.push(cell);if(row.some(x=>x.trim()))rows.push(row);row=[];cell=''}else cell+=c}if(quoted)throw Error('CSV 따옴표가 닫히지 않았습니다.');row.push(cell);if(row.some(x=>x.trim()))rows.push(row);return trimSheetRows(rows)}
function csvEscape(v){let t=String(v??'');if(/^[=+@\-\t\r]/.test(t))t="'"+t;return '"'+t.replace(/"/g,'""')+'"'}
function downloadCSV(rows,name){let csv='\ufeff'+rows.map(r=>r.map(csvEscape).join(',')).join('\r\n');let url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));let a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500)}
function downloadTemplateXlsx(){
 const headers=['이름','생년월일','휴대전화','일반전화','당원번호','행정동','지역위원회','우편번호','주소','상세주소','출생지','직업','소속 단체','직책','추천인','수신거절','수신거절 사유','메모'];
 downloadXlsxRows([headers],'주소록_입력양식_생년월일6자리.xlsx');
}
$('template').onclick=()=>{try{downloadTemplateXlsx()}catch(err){alert('양식 다운로드 실패: '+err.message)}};

const utf8=b=>new TextDecoder('utf-8').decode(b);
async function unzipXlsx(buf){let v=new DataView(buf),u=new Uint8Array(buf),end=-1;for(let i=u.length-22;i>=Math.max(0,u.length-65557);i--)if(v.getUint32(i,true)===0x06054b50){end=i;break}if(end<0)throw Error('올바른 XLSX 파일이 아닙니다.');let count=v.getUint16(end+10,true),pos=v.getUint32(end+16,true),out={};for(let i=0;i<count;i++){if(v.getUint32(pos,true)!==0x02014b50)throw Error('ZIP 목록 오류');let method=v.getUint16(pos+10,true),size=v.getUint32(pos+20,true),n=v.getUint16(pos+28,true),extra=v.getUint16(pos+30,true),comment=v.getUint16(pos+32,true),off=v.getUint32(pos+42,true),name=utf8(u.slice(pos+46,pos+46+n));pos+=46+n+extra+comment;if(!/^\/?xl\/(worksheets\/[^/]+\.xml|sharedstrings\d*\.xml|workbook\.xml|_rels\/workbook\.xml\.rels)$/i.test(name))continue;if(size>30e6)throw Error('시트 크기가 너무 큽니다.');let start=off+30+v.getUint16(off+26,true)+v.getUint16(off+28,true);let compressed=u.slice(start,start+size);if(method===0)out[name]=utf8(compressed);else if(method===8){if(typeof DecompressionStream==='undefined')throw Error('이 브라우저에서는 XLSX 압축 해제가 지원되지 않습니다. CSV로 저장 후 업로드해 주세요.');let stream=new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate-raw'));out[name]=utf8(new Uint8Array(await new Response(stream).arrayBuffer()))}else throw Error('지원되지 않는 XLSX 압축 방식입니다.')}return out}
function excelDate(n){let d=new Date(Date.UTC(1899,11,30)+Number(n)*86400000);return Number.isFinite(d.getTime())?d.toISOString().slice(0,10):String(n)}
// v0.4.10: 여러 시트·접두사 XML·제목 줄이 있는 엑셀도 읽도록 개선
function trimSheetRows(rows){
 rows=rows.map(r=>Array.from(r,x=>x==null?'':String(x)));
 // 맨 위의 빈 줄·제목 줄(내용이 1칸 이하인 줄)은 건너뛰고, 여러 칸이 채워진 첫 줄을 제목 행으로 사용
 let k=0;while(k<Math.min(15,rows.length-1)&&rows[k].filter(x=>x.trim()).length<=1)k++;
 const out=rows.slice(k);out.headerRow=k+1;out.dataCount=out.slice(1).filter(r=>r.some(x=>x.trim())).length;return out;
}
async function parseXlsx(file){
 const raw=await unzipXlsx(await file.arrayBuffer()),z={};for(const [k,v] of Object.entries(raw))z[k.toLowerCase()]=v;
 const parser=new DOMParser(),parse=t=>{const d=parser.parseFromString(t,'application/xml');if(d.getElementsByTagName('parsererror').length)throw Error('엑셀 XML 읽기 오류');return d};
 const tags=(node,name)=>[...node.getElementsByTagNameNS('*',name)];
 let strings=[];
 const ssPath=Object.keys(z).find(k=>/^xl\/sharedstrings\d*\.xml$/.test(k));
 if(ssPath)strings=tags(parse(z[ssPath]),'si').map(si=>tags(si,'t').filter(t=>!t.closest||!(t.parentNode&&t.parentNode.localName==='rPh')).map(x=>x.textContent).join(''));
 // 통합문서에 적힌 시트 순서대로 시트 파일 찾기
 let order=[];
 try{
  const wb=parse(z['xl/workbook.xml']),rels=z['xl/_rels/workbook.xml.rels']?parse(z['xl/_rels/workbook.xml.rels']):null;
  const map={};if(rels)for(const r of tags(rels,'Relationship'))map[r.getAttribute('Id')]=String(r.getAttribute('Target')||'').replace(/^\//,'').replace(/^xl\//i,'');
  for(const s of tags(wb,'sheet')){const rid=s.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id')||s.getAttribute('r:id');const t=map[rid];if(t)order.push({name:s.getAttribute('name')||'',path:('xl/'+t).toLowerCase()})}
 }catch(e){}
 const sheetFiles=Object.keys(z).filter(k=>/^xl\/worksheets\/[^/]+\.xml$/.test(k)).sort((a,b)=>Number((a.match(/\d+/g)||[0]).at(-1))-Number((b.match(/\d+/g)||[0]).at(-1)));
 for(const p of sheetFiles)if(!order.some(o=>o.path===p))order.push({name:p.split('/').pop(),path:p});
 order=order.filter(o=>z[o.path]);
 if(!order.length)throw Error('엑셀 시트를 찾지 못했습니다.');
 const readSheet=xml=>{const doc=parse(xml),rows=[];
  for(const r of tags(doc,'row')){const arr=[];let next=0;
   for(const c of tags(r,'c')){const ref=c.getAttribute('r')||'';let idx;const m=ref.match(/^[A-Z]+/i);if(m){idx=0;for(const ch of m[0].toUpperCase())idx=idx*26+ch.charCodeAt(0)-64;idx--}else idx=next;next=idx+1;
    const type=c.getAttribute('t'),v=tags(c,'v')[0];let val=v?.textContent||'';
    if(type==='inlineStr')val=tags(c,'t').map(t=>t.textContent).join('');else if(type==='s')val=strings[Number(val)]??'';
    arr[idx]=val}
   const rowNo=Number(r.getAttribute('r'));if(rowNo>0&&rows.length<rowNo-1)while(rows.length<rowNo-1)rows.push([]);
   rows.push(Array.from(arr,x=>x??''));if(rows.length>200000)throw Error('최대 200,000행까지 지원합니다.')}
  return rows};
 const found=[];
 for(const o of order){const rows=trimSheetRows(readSheet(z[o.path]));found.push(o.name+' '+rows.dataCount+'행');if(rows.dataCount>=1)return rows}
 throw Error('데이터가 있는 시트를 찾지 못했습니다. (시트별 데이터: '+found.join(', ')+') 첫 줄에 제목(이름, 휴대전화 등), 둘째 줄부터 데이터가 있어야 합니다.');
}
function toContacts(rows){if(rows.length<2)throw Error('제목 행과 데이터 행이 필요합니다. 첫 줄에 이름·휴대전화 같은 제목, 둘째 줄부터 데이터를 넣어 주세요.');let headers=rows[0].map(x=>String(x||'').trim()),mapping={};for(let [field,aliases] of Object.entries(headerAliases)){let idx=headers.findIndex(h=>aliases.some(a=>cleanHeader(a)===cleanHeader(h)));if(idx>=0)mapping[field]=idx}if(mapping.name===undefined)throw Error('제목 행에 이름(또는 성명) 열이 필요합니다. 읽은 제목: '+headers.filter(Boolean).slice(0,12).join(', '));let results=[];for(let i=1;i<rows.length;i++){let row=rows[i];if(!row.some(x=>String(x||'').trim()))continue;let o={id:uid()};fields.forEach(k=>o[k]=mapping[k]===undefined?'':String(row[mapping[k]]??'').trim());if(o.birth){if(/^\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2}/.test(o.birth)){let m=o.birth.match(/^(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})/);o.birth=`${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`}else if(/^\d{5}$/.test(o.birth))o.birth='0'+o.birth}let rs=mapping.recs===undefined?'':String(row[mapping.recs]||'');let gs=o.group.split(/[;、\n]/).map(x=>x.trim()),roles=o.role.split(/[;、\n]/).map(x=>x.trim());o.affiliations=gs.map((group,i)=>({group,role:roles[i]||''})).filter(a=>a.group);o.recs=rs.split(/[,;、\n]/).map(x=>x.trim()).filter(Boolean).map(name=>({id:uid(),name}));o.primary=null;results.push({o,row,rowNumber:i+(rows.headerRow||1)});}return {headers,results}}
function previewImport(rows){let {headers,results}=toContacts(rows);if(results.length>20000)throw Error('20,000명 이하로 업로드해 주세요.');
 pending={headers,results};$('importpreview').classList.remove('hidden');
 $('importsummary').textContent=`${results.length}건 검사 준비 · 확인 버튼을 누르면 신규/병합/검토 내역을 먼저 보여줍니다.`;
 $('importconfirm').disabled=!results.length;$('duplicatesdownload').disabled=true;
 $('importrows').innerHTML=results.slice(0,80).map(x=>`<tr><td>${x.rowNumber}</td><td>${esc(x.o.name)}</td><td>검사 대기</td><td>확인 후 처리</td></tr>`).join('');$('importpreview').scrollIntoView({behavior:'smooth'})}
$('importfile').onchange=async e=>{let file=e.target.files[0];if(!file)return;try{if(file.size>15e6)throw Error('15MB 이하 파일만 지원합니다.');let rows=/\.xlsx$/i.test(file.name)?await parseXlsx(file):/\.csv$/i.test(file.name)?parseCSV(await file.text()):null;if(!rows)throw Error('xlsx 또는 csv 파일만 업로드할 수 있습니다.');previewImport(rows)}catch(err){alert('업로드 검사 실패: '+err.message)}finally{e.target.value=''}};
// Optional bulk lookup: official road-address API. Never guess a postal code.
$('batchPostcode').onclick=async()=>{
 if(!pending){alert('먼저 엑셀 또는 CSV 파일을 선택하세요.');return}
 const key=$('jusoKey').value.trim();
 if(!/^[A-Za-z0-9]{10,80}$/.test(key)){alert('도로명주소 검색 API 승인키를 입력해 주세요.');return}
 const candidates=pending.results.filter(x=>!String(x.o.postcode||'').trim()&&String(x.o.address||'').trim()).slice(0,100);
 if(!candidates.length){$('postcodeSummary').textContent='조회할 빈 우편번호가 없습니다.';return}
 if(!confirm(`${candidates.length}건의 주소를 도로명주소 검색 서비스로 전송하여 우편번호를 확인할까요? (가상 데이터 전용)`))return;
 const btn=$('batchPostcode');btn.disabled=true;let done=0,matched=0,review=0,errors=0;
 try{for(const x of candidates){
  $('postcodeSummary').textContent=`조회 중 ${done+1}/${candidates.length} · 자동 입력 ${matched}건 · 확인 필요 ${review}건`;
  try{const res=await fetch('/api/postcode-lookup',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':window.APP_CSRF},body:JSON.stringify({api_key:key,address:x.o.address})});const j=await res.json();if(j.status==='matched'&&/^\d{5}$/.test(j.postcode)){x.o.postcode=j.postcode;matched++}else if(j.status==='review')review++;else errors++}catch(e){errors++}
  done++;
 }
 $('postcodeSummary').textContent=`조회 ${done}건 · 우편번호 자동 입력 ${matched}건 · 주소 확인 필요 ${review}건 · 오류 ${errors}건. 확인 후 등록하세요.`;
 $('importrows').innerHTML=pending.results.slice(0,80).map(x=>`<tr><td>${x.rowNumber}</td><td>${esc(x.o.name)}</td><td>${esc(x.o.postcode||'확인 필요')}</td><td>${esc(x.o.address||'주소 없음')}</td></tr>`).join('');
 }finally{btn.disabled=false}
};
$('importcancel').onclick=()=>{pending=null;$('importpreview').classList.add('hidden')};
$('duplicatesdownload').onclick=()=>alert('가져오기 승인 후 결과 CSV가 자동 다운로드됩니다.');
$('importconfirm').onclick=async()=>{if(!pending)return;try{await applyMergedImport(pending.results.map(x=>({o:x.o,old:x.o,row:x.rowNumber})),'엑셀/CSV');pending=null}catch(err){alert('가져오기 실패: '+err.message)}};

// v11 행사 달력과 참석자 관리. 모든 행사 데이터는 주소록과 함께 암호화 저장됨.
let calendarYear=new Date().getFullYear(),calendarMonth=new Date().getMonth(),selectedEvent=null,editingEvent=null;
const safeDate=s=>/^\d{4}-\d{2}-\d{2}$/.test(s||'');const safeTime=s=>/^([01]\d|2[0-3]):[0-5]\d$/.test(s||'');
function timeRange(e){const a=e?.startTime||'',b=e?.endTime||'';return a&&b?a+'~'+b:a?a+' 시작':b?'~'+b+' 종료':''}
function evSort(a,b){return String(a.date||'').localeCompare(String(b.date||''))||String(a.startTime||'99:99').localeCompare(String(b.startTime||'99:99'))}
const attendanceLabel=v=>({attended:'실제 참석',planned:'참석 예정',absent:'불참'})[v]||v||'';
function eventCounts(c){return events.reduce((n,e)=>n+Object.entries(e.attendees||{}).filter(([id,status])=>id===c.id&&status==='attended').length,0)}
function drawCalendar(){const first=new Date(calendarYear,calendarMonth,1).getDay(),days=new Date(calendarYear,calendarMonth+1,0).getDate();$('eventMonth').textContent=`${calendarYear}년 ${calendarMonth+1}월`;let html=['일','월','화','수','목','금','토'].map(x=>`<div class="event-week">${x}</div>`).join('');for(let i=0;i<first;i++)html+='<div></div>';for(let d=1;d<=days;d++){let date=`${calendarYear}-${String(calendarMonth+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,items=events.filter(e=>e.date===date).sort(evSort);html+=`<button type="button" class="event-day" data-day="${date}"><b>${d}</b>${items.slice(0,2).map(e=>`<small>${e.startTime?esc(e.startTime)+' ':''}${esc(e.title)}</small>`).join('')}${items.length>2?`<small>+${items.length-2}개</small>`:''}</button>`}$('eventCalendar').innerHTML=html;drawEventList()}
function drawEventList(){let prefix=`${calendarYear}-${String(calendarMonth+1).padStart(2,'0')}`,list=events.filter(e=>e.date.startsWith(prefix)).sort(evSort);$('eventDetails').innerHTML='<h3>이번 달 행사</h3>'+(list.length?list.map(e=>{let statuses=Object.values(e.attendees||{});return `<div class="event-row"><span class="time-badge">${esc(timeRange(e)||'시간 미정')}</span><b>${esc(e.date)} · ${esc(e.title)}</b> <span class="muted">${esc(e.place||'')}</span><p class="muted">실제 참석 ${statuses.filter(x=>x==='attended').length}명 / 예정 ${statuses.filter(x=>x==='planned').length}명 / 불참 ${statuses.filter(x=>x==='absent').length}명</p><div class="actions"><button data-event-att="${esc(e.id)}">참석자 관리</button><button data-event-edit="${esc(e.id)}">행사 수정</button><button data-event-delete="${esc(e.id)}" class="danger">삭제</button></div></div>`}).join(''):'<p class="muted">등록된 행사가 없습니다.</p>')}
function editEvent(e,date){editingEvent=e?.id||null;$('eventTitle').value=e?.title||'';$('eventDate').value=e?.date||date||new Date().toISOString().slice(0,10);$('eventPlace').value=e?.place||'';$('eventStart').value=e?.startTime||'';$('eventEnd').value=e?.endTime||'';$('eventEditorTitle').textContent=e?'행사 수정':'새 행사 등록';$('eventEditor').classList.remove('hidden');$('eventEditor').scrollIntoView({behavior:'smooth',block:'nearest'})}
$('eventPrev').onclick=()=>{calendarMonth--;if(calendarMonth<0){calendarMonth=11;calendarYear--}drawCalendar()};$('eventNext').onclick=()=>{calendarMonth++;if(calendarMonth>11){calendarMonth=0;calendarYear++}drawCalendar()};$('eventNew').onclick=()=>editEvent(null);$('eventCancel').onclick=()=>$('eventEditor').classList.add('hidden');$('eventCalendar').onclick=e=>{let b=e.target.closest('[data-day]');if(b)editEvent(null,b.dataset.day)};
$('eventSave').onclick=async()=>{let title=$('eventTitle').value.trim(),date=$('eventDate').value,place=$('eventPlace').value.trim(),startTime=$('eventStart').value.slice(0,5),endTime=$('eventEnd').value.slice(0,5);if(!title||!safeDate(date)){alert('행사명과 날짜를 입력하세요.');return}if((startTime&&!safeTime(startTime))||(endTime&&!safeTime(endTime))){alert('시간을 HH:MM 형식으로 입력하세요.');return}if(endTime&&!startTime){alert('종료시간을 입력하려면 시작시간도 입력하세요.');return}if(startTime&&endTime&&endTime<=startTime){alert('종료시간은 시작시간보다 늦어야 합니다.');return}let old=structuredClone(events);if(editingEvent){let e=events.find(x=>x.id===editingEvent);if(e)Object.assign(e,{title,date,place,startTime,endTime})}else events.push({id:uid(),title,date,place,startTime,endTime,attendees:{}});try{await save();$('eventEditor').classList.add('hidden');calendarYear=+date.slice(0,4);calendarMonth=+date.slice(5,7)-1;drawCalendar()}catch(err){events=old;alert('행사 저장 실패: '+err.message)}};
$('eventDetails').onclick=async e=>{let b=e.target.closest('button');if(!b)return;let id=b.dataset.eventAtt||b.dataset.eventEdit||b.dataset.eventDelete,ev=events.find(x=>x.id===id);if(!ev)return;if(b.dataset.eventAtt)openAttendance(ev);if(b.dataset.eventEdit)editEvent(ev);if(b.dataset.eventDelete&&confirm('행사를 삭제하면 해당 행사 참석 이력도 삭제됩니다. 삭제할까요?')){events=events.filter(x=>x.id!==id);await save();drawCalendar()}};
function openAttendance(ev){selectedEvent=ev.id;$('attendanceTitle').textContent=`${ev.title} · 참석자 관리`;$('attendanceSearch').value='';$('attendanceEditor').classList.remove('hidden');drawAttendance();$('attendanceEditor').scrollIntoView({behavior:'smooth',block:'nearest'})}
function drawAttendance(){let ev=events.find(x=>x.id===selectedEvent);if(!ev)return;let q=$('attendanceSearch').value.trim().toLowerCase(),filtered=data.filter(c=>[c.name,c.phone,c.landline,c.district].some(v=>String(v||'').toLowerCase().includes(q)));$('attendancePeople').innerHTML=filtered.length?filtered.map(c=>`<div class="attendee"><div><b>${esc(c.name)}</b><div class="muted">${esc(c.district||'')} · ${esc(c.phone||c.landline||'번호 없음')} · 누적 ${eventCounts(c)}회</div></div><select data-person="${esc(c.id)}"><option value="">미등록</option><option value="planned" ${ev.attendees?.[c.id]==='planned'?'selected':''}>참석 예정</option><option value="attended" ${ev.attendees?.[c.id]==='attended'?'selected':''}>실제 참석</option><option value="absent" ${ev.attendees?.[c.id]==='absent'?'selected':''}>불참</option></select></div>`).join(''):'<p>검색 결과가 없습니다.</p>';const gone=Object.entries(ev.removedAttendees||{}).filter(([id])=>ev.attendees?.[id]);if(gone.length)$('attendancePeople').innerHTML+='<div class="history"><b>주소록에서 삭제된 참석자 '+gone.length+'명</b> (행사 기록만 보존)<ul>'+gone.map(([id,g])=>'<li>'+esc(g.name)+' · '+esc(attendanceLabel(ev.attendees[id]))+'</li>').join('')+'</ul></div>'}
$('attendanceSearch').oninput=drawAttendance;$('attendanceClose').onclick=()=>$('attendanceEditor').classList.add('hidden');$('attendanceSave').onclick=async()=>{let ev=events.find(x=>x.id===selectedEvent);if(!ev)return;ev.attendees=ev.attendees||{};for(let sel of $('attendancePeople').querySelectorAll('[data-person]')){if(sel.value)ev.attendees[sel.dataset.person]=sel.value;else delete ev.attendees[sel.dataset.person]}try{await save();drawCalendar();drawAttendance();alert('참석 상태를 저장했습니다.')}catch(err){alert('저장 실패: '+err.message)}};
$('attendanceExport').onclick=()=>{let ev=events.find(x=>x.id===selectedEvent);if(!ev)return;let rows=[['행사명','날짜','시작시간','종료시간','장소','이름','휴대전화','일반전화','행정동','참석 상태']];for(let [id,status] of Object.entries(ev.attendees||{})){let c=data.find(x=>x.id===id),gone=ev.removedAttendees?.[id];if(c)rows.push([ev.title,ev.date,ev.startTime||'',ev.endTime||'',ev.place||'',c.name,c.phone,c.landline||'',c.district,attendanceLabel(status)]);else if(gone)rows.push([ev.title,ev.date,ev.startTime||'',ev.endTime||'',ev.place||'',gone.name+' (주소록에서 삭제됨)',gone.phone||'','','',attendanceLabel(status)])}downloadCSV(rows,'행사_참석자_'+ev.date+'.csv')};
// 주소록 갱신 및 잠금 해제 시 행사 달력도 갱신

$('attendanceImport').onchange=async e=>{
 const file=e.target.files[0];if(!file)return;
 try{
  if(file.size>15e6)throw Error('15MB 이하 파일만 지원합니다.');
  const rows=/\.xlsx$/i.test(file.name)?await parseXlsx(file):/\.csv$/i.test(file.name)?parseCSV(await file.text()):null;
  if(!rows||rows.length<2)throw Error('이름/당원번호 열이 포함된 CSV 또는 XLSX 파일이 필요합니다.');
  const h=rows[0].map(x=>cleanHeader(x)),idx=aliases=>h.findIndex(x=>aliases.some(a=>cleanHeader(a)===x));
  const ni=idx(['이름','성명']),mi=idx(['당원번호']),bi=idx(['생년월일']),pi=idx(['휴대전화','전화번호']),si=idx(['참석상태','참석 여부','상태']);
  if(ni<0&&mi<0)throw Error('이름 또는 당원번호 열이 필요합니다.');
  const statusMap={'참석':'attended','실제참석':'attended','참석완료':'attended','attended':'attended','예정':'planned','참석예정':'planned','planned':'planned','불참':'absent','absent':'absent'};
  const updates=[],reviews=[];
  for(let i=1;i<rows.length;i++){
   const row=rows[i];if(!row.some(x=>String(x||'').trim()))continue;
   const name=ni>=0?String(row[ni]||'').trim():'',member=mi>=0?String(row[mi]||'').trim():'',rawBirth=bi>=0?String(row[bi]||'').trim():'';
   let birth='';try{if(rawBirth)birth=formatBirth(rawBirth)}catch(err){reviews.push(`${i+1}행 ${name}: 생년월일 오류`);continue}
   let matches=member?data.filter(c=>normText(c.member)===normText(member)):[];
   if(!matches.length&&name&&birth)matches=data.filter(c=>normText(c.name)===normText(name)&&c.birth===birth);
   if(matches.length!==1){reviews.push(`${i+1}행 ${name||member}: ${matches.length?'동일인 후보 다수':'일치하는 DB 없음 (이름만으로 연결하지 않음)'}`);continue}
   const c=matches[0];if(name&&normText(name)!==normText(c.name)){reviews.push(`${i+1}행: 당원번호 일치, 이름 충돌`);continue}
   let status=si<0?'attended':statusMap[String(row[si]||'').trim().replace(/\s/g,'')];
   if(!status){reviews.push(`${i+1}행 ${name}: 참석 상태 오류`);continue}
   updates.push({id:c.id,name:c.name,status});
  }
  const ev=events.find(x=>x.id===selectedEvent);if(!ev)throw Error('행사를 먼저 선택하세요.');
  const unique=new Map(updates.map(x=>[x.id,x]));
  const preview=`행사: ${ev.title}\n일괄 반영 대상 ${unique.size}명 / 확인 필요 ${reviews.length}행\n\n`+Array.from(unique.values()).slice(0,30).map(x=>x.name+' — '+x.status).join('\n')+'\n\n[확인 필요]\n'+(reviews.slice(0,30).join('\n')||'없음')+'\n\n반영할까요?';
  if(!confirm(preview))return;
  const previous=structuredClone(ev.attendees||{});ev.attendees=ev.attendees||{};
  for(const u of unique.values())ev.attendees[u.id]=u.status;
  try{await save()}catch(err){ev.attendees=previous;throw err}
  drawCalendar();drawAttendance();
  downloadCSV([['행','검토 사유'],...reviews.map((r,i)=>[i+1,r])],'행사_일괄등록_확인필요.csv');
  alert(`반영 ${unique.size}명 / 확인 필요 ${reviews.length}행`);
 }catch(err){alert('행사 참석자 가져오기 실패: '+err.message)}finally{e.target.value=''}
};

const priorRender=render;render=function(){priorRender();drawCalendar()};
const memberSchema=[['memberNo','당원번호'],['memberName','당원명'],['memberType','당원구분'],['memberClass','당원분류'],['province','광역'],['districtElectoral','선거구'],['gender','성별'],['birthDate','생년월일'],['homePhone','집전화번호'],['mobilePhone','휴대폰번호'],['joinDate','입당일자'],['memberStatus','당원상태'],['activityWish','희망활동부문'],['postcode','우편번호'],['roadAddress','집주소-도로명'],['lotAddress','집주소-지번'],['sigungu','시군구'],['adminDong','행정동'],['legalDong','법정동'],['email','이메일'],['recommender','추천인']];
let editingMember=null,editingOrg=null,editingDonor=null;
let _cPos=null,_cArr=null;function contactById(id){if(!id)return null;if(_cArr!==data||!_cPos){_cArr=data;_cPos=new Map(data.map((c,i)=>[c.id,i]))}let i=_cPos.get(id);if(i===undefined||data[i]?.id!==id){_cPos=new Map(data.map((c,i)=>[c.id,i]));i=_cPos.get(id)}return i===undefined?null:data[i]}
function memberContact(m){return m.contactId?contactById(m.contactId):null}
function renderMembers(){const q=($('memberSearch').value||'').trim().toLowerCase(),st=$('memberStatusFilter').value;const rows=members.filter(m=>(!st||m.memberStatus===st)&&(!q||memberSchema.map(([k])=>m[k]||'').join(' ').toLowerCase().includes(q)||String(memberContact(m)?.name||'').toLowerCase().includes(q)));$('memberCount').textContent=members.length.toLocaleString()+'명';const shown=listPager('members','memberPager',renderMembers).slice(rows,q+'|'+st);$('memberRows').innerHTML=shown.map(m=>`<tr><td>${esc(m.memberNo)}</td><td>${esc(m.memberName||memberContact(m)?.name||'')}${m.detachedFromContact&&!m.contactId?'<span class="tag-warn">주소록 연결 해제</span>':''}</td><td>${esc(m.memberType)}</td><td>${esc(m.memberClass)}</td><td>${esc(m.districtElectoral)}</td><td>${esc(m.adminDong)}</td><td>${esc(m.memberStatus)}</td><td><button data-me="${esc(m.id)}">수정</button> <button class="danger" data-md="${esc(m.id)}">삭제</button></td></tr>`).join('')||'<tr><td colspan="8">등록된 당원 정보가 없습니다.</td></tr>';renderOrganizations()}
function buildMemberForm(){$('memberFields').innerHTML=memberSchema.map(([k,l])=>`<div><label>${l}</label><input id="mf_${k}" maxlength="200"></div>`).join('')+`<div class="full"><label>전체 연락처 연결(선택)</label><select id="mf_contact"><option value="">연결 안 함</option>${data.map(c=>`<option value="${esc(c.id)}">${esc(c.name)} · ${esc(c.phone||'번호 없음')}</option>`).join('')}</select></div><div class="full"><label>당원관리 메모</label><textarea id="mf_note"></textarea></div>`}
function openMember(m){editingMember=m?.id||null;buildMemberForm();memberSchema.forEach(([k])=>$('mf_'+k).value=m?.[k]||'');$('mf_contact').value=m?.contactId||'';$('mf_note').value=m?.note||'';$('memberEditorTitle').textContent=m?'당원 정보 수정':'당원 등록';$('memberEditor').classList.remove('hidden')}
$('memberNew').onclick=()=>openMember(null);$('memberCancel').onclick=$('memberCancel2').onclick=()=>{$('memberEditor').classList.add('hidden');editingMember=null};
$('memberForm').onsubmit=async e=>{e.preventDefault();let m={id:editingMember||uid()};memberSchema.forEach(([k])=>m[k]=$('mf_'+k).value.trim());m.contactId=$('mf_contact').value||members.find(x=>x.id===m.id)?.contactId||null;m.note=$('mf_note').value.trim();{const prevM=members.find(x=>x.id===m.id);if(!m.contactId&&prevM?.detachedFromContact)m.detachedFromContact=true}if(!m.memberName&&!m.contactId){alert('당원명 또는 연결할 연락처를 선택하세요.');return}if(m.memberNo&&members.some(x=>x.id!==m.id&&x.memberNo===m.memberNo)){alert('중복 당원번호입니다.');return}let i=members.findIndex(x=>x.id===m.id);if(i>=0)members[i]=m;else members.push(m);await linkAllRecords();activePhoneTab='all';$('memberEditor').classList.add('hidden');renderMembers()};
$('memberRows').onclick=async e=>{let b=e.target.closest('button');if(!b)return;if(b.dataset.me)openMember(members.find(x=>x.id===b.dataset.me));if(b.dataset.md&&confirm('당원관리 정보만 삭제할까요? 연락처는 삭제되지 않습니다.')){members=members.filter(x=>x.id!==b.dataset.md);await save();renderMembers()}};
$('memberSearch').oninput=renderMembers;$('memberStatusFilter').onchange=renderMembers;$('memberSearchClear').onclick=()=>{$('memberSearch').value='';$('memberStatusFilter').value='';renderMembers()};
$('memberExport').onclick=()=>downloadCSV([memberSchema.map(x=>x[1]),...members.map(m=>memberSchema.map(([k])=>m[k]||''))],'당원명단.csv');
$('memberImport').onchange=e=>importIntegratedFile(e,'member');



// v0.4.17: 조직도 — 상위 조직은 목록에서 골라 실제로 연결(하위 조직으로 들여쓰기 표시), 구성원은 검색해서 추가하고 정보 표로 표시
function orgParentOf(o){if(!o)return null;return organizations.find(x=>x.id===o.parentId&&x.id!==o.id)||(!o.parentId&&o.parent?organizations.find(x=>x.id!==o.id&&x.name.trim()===String(o.parent).trim()):null)||null}
function orgDescendants(id){const out=new Set();const walk=pid=>{for(const x of organizations){if(!out.has(x.id)&&x.id!==id&&orgParentOf(x)?.id===pid){out.add(x.id);walk(x.id)}}};walk(id);return out}
function fillOrgParentSelect(selfId,selected){const bad=selfId?orgDescendants(selfId):new Set();if(selfId)bad.add(selfId);$('orgParent').innerHTML='<option value="">(없음 · 최상위 조직)</option>'+organizations.filter(x=>!bad.has(x.id)).map(x=>`<option value="${esc(x.id)}" ${x.id===selected?'selected':''}>${esc(x.name)}${x.type?' ('+esc(x.type)+')':''}</option>`).join('')}
$('orgNew').onclick=()=>{editingOrg=null;['orgName','orgType','orgChair','orgMemo'].forEach(x=>$(x).value='');fillOrgParentSelect(null,'');$('orgEditorTitle').textContent='조직 등록';$('orgEditor').classList.remove('hidden')};$('orgCancel').onclick=()=>$('orgEditor').classList.add('hidden');
$('orgSave').onclick=async()=>{let name=$('orgName').value.trim();if(!name){alert('조직명을 입력하세요.');return}let old=organizations.find(x=>x.id===editingOrg);const pid=$('orgParent').value||'',par=organizations.find(x=>x.id===pid);
 if(editingOrg&&pid&&(pid===editingOrg||orgDescendants(editingOrg).has(pid))){alert('자기 자신이나 자기 하위 조직을 상위 조직으로 정할 수 없습니다.');return}
 let o={...(old||{}),id:editingOrg||uid(),name,parentId:par?par.id:'',parent:par?par.name:'',type:$('orgType').value.trim(),chair:$('orgChair').value.trim(),memo:$('orgMemo').value.trim(),members:old?.members||[]};
 const prev=structuredClone(organizations);let i=organizations.findIndex(x=>x.id===o.id);if(i>=0)organizations[i]=o;else organizations.push(o);
 // 이름이 바뀌면 하위 조직에 적힌 상위 조직 이름도 함께 바꿈
 if(old&&old.name!==name)for(const x of organizations)if(x.parentId===o.id||(!x.parentId&&x.parent===old.name&&x.id!==o.id)){x.parentId=o.id;x.parent=name}
 try{await save()}catch(err){organizations=prev;alert('저장 실패: '+err.message);return}$('orgEditor').classList.add('hidden');renderOrganizations()};
function orgMemberInfo(z){const m=members.find(x=>x.id===z.memberId),c=m?memberContact(m):null;return {m,c,name:m?.memberName||c?.name||z.name||'',no:m?.memberNo||'',phone:m?.mobilePhone||c?.phone||'',dong:m?.adminDong||c?.district||'',status:m?.memberStatus||''}}
function renderOrganizations(){
 const el=$('orgRows');if(!el)return;if(!organizations.length){el.innerHTML='<p class="muted">등록된 조직이 없습니다.</p>';return}
 const seen=new Set();
 const node=(o,depth)=>{if(seen.has(o.id))return '';seen.add(o.id);const par=orgParentOf(o),kids=organizations.filter(x=>x.id!==o.id&&orgParentOf(x)?.id===o.id),ms=o.members||[];
  const table=ms.length?`<div class="tablewrap" style="margin-top:8px"><table style="min-width:0"><thead><tr><th>이름</th><th>직책</th><th>당원번호</th><th>휴대폰</th><th>행정동</th><th>당원상태</th><th></th></tr></thead><tbody>${ms.map((z,k)=>{const f=orgMemberInfo(z);return `<tr><td><b>${esc(f.name)}</b>${f.m?'':' <span class="tag-warn">당원 명단에 없음</span>'}</td><td>${esc(z.role||'위원')}</td><td>${esc(f.no)}</td><td>${esc(f.phone)}</td><td>${esc(f.dong)}</td><td>${esc(f.status)}</td><td style="white-space:nowrap">${f.c?`<button type="button" data-org-profile="${esc(f.c.id)}">통합정보</button> `:''}<button type="button" data-org-role="${esc(o.id)}|${k}">직책 변경</button> <button type="button" class="danger" data-org-rm="${esc(o.id)}|${k}">빼기</button></td></tr>`}).join('')}</tbody></table></div>`:'<p class="muted" style="margin:6px 0 0">구성원이 없습니다. \'구성원 추가\'로 넣어 주세요.</p>';
  return `<div class="event-row" style="margin-left:${Math.min(depth,6)*28}px;${depth?'border-left:4px solid #93c5fd;':''}"><b>${depth?'└ ':''}${esc(o.name)}</b> ${o.type?'· '+esc(o.type):''}<p class="muted">상위 조직 ${par?'<b>'+esc(par.name)+'</b>':'-'} · 위원장 ${esc(o.chair||'-')} · 구성원 ${ms.length}명${kids.length?' · 하위 조직 '+kids.length+'개':''}${o.memo?' · '+esc(o.memo):''}</p><div class="actions"><button data-oe="${esc(o.id)}">수정</button><button data-oa="${esc(o.id)}">구성원 추가</button><button data-osub="${esc(o.id)}">하위 조직 추가</button><button class="danger" data-od="${esc(o.id)}">삭제</button></div>${table}</div>`+kids.map(k=>node(k,depth+1)).join('')};
 const roots=organizations.filter(o=>!orgParentOf(o));let html=roots.map(o=>node(o,0)).join('');
 for(const o of organizations)if(!seen.has(o.id))html+=node(o,0); // 순환 연결 등 예외
 el.innerHTML=html;
}
let omOrg=null;
function openOrgMemberAdd(o){omOrg=o.id;$('omOrgName').textContent=o.name;$('omSearch').value='';$('omRole').value='위원';$('omResults').innerHTML='<p class="muted">이름·당원번호·휴대폰·행정동으로 검색하세요.</p>';$('orgMemberEditor').classList.remove('hidden');$('omSearch').focus()}
function drawOmResults(){const q=$('omSearch').value.trim().toLowerCase(),qd=q.replace(/\D/g,'');const o=organizations.find(x=>x.id===omOrg);if(!o)return;if(!q){$('omResults').innerHTML='<p class="muted">이름·당원번호·휴대폰·행정동으로 검색하세요.</p>';return}
 const inOrg=new Set((o.members||[]).map(z=>z.memberId));const res=[];for(const m of members){const c=memberContact(m),name=m.memberName||c?.name||'';const hay=[name,m.memberNo,m.adminDong,m.districtElectoral].join(' ').toLowerCase();if(hay.includes(q)||(qd.length>=4&&cleanPhone(m.mobilePhone||c?.phone).includes(qd))){res.push({m,c,name});if(res.length>=50)break}}
 $('omResults').innerHTML=res.length?`<div class="tablewrap"><table style="min-width:0"><thead><tr><th>이름</th><th>당원번호</th><th>휴대폰</th><th>행정동</th><th>당원상태</th><th></th></tr></thead><tbody>${res.map(({m,c,name})=>`<tr><td><b>${esc(name)}</b></td><td>${esc(m.memberNo||'')}</td><td>${esc(m.mobilePhone||c?.phone||'')}</td><td>${esc(m.adminDong||'')}</td><td>${esc(m.memberStatus||'')}</td><td>${inOrg.has(m.id)?'<span class="muted">이미 구성원</span>':`<button type="button" class="primary" data-om-add="${esc(m.id)}">추가</button>`}</td></tr>`).join('')}</tbody></table></div>${res.length>=50?'<p class="muted">50명까지만 표시합니다. 더 자세히 검색해 주세요.</p>':''}`:'<p class="muted">당원 명단에서 찾지 못했습니다.</p>'}
$('omSearch').oninput=drawOmResults;$('omCancel').onclick=()=>{$('orgMemberEditor').classList.add('hidden');omOrg=null};
$('omResults').onclick=async e=>{const b=e.target.closest('[data-om-add]');if(!b)return;const o=organizations.find(x=>x.id===omOrg),m=members.find(x=>x.id===b.dataset.omAdd);if(!o||!m)return;if((o.members||[]).some(z=>z.memberId===m.id)){alert('이미 이 조직의 구성원입니다.');return}
 const prev=structuredClone(organizations);o.members=o.members||[];o.members.push({memberId:m.id,name:m.memberName||memberContact(m)?.name||'',role:$('omRole').value.trim()||'위원'});
 try{await save()}catch(err){organizations=prev;alert('저장 실패: '+err.message);return}renderOrganizations();drawOmResults();b.closest('td').innerHTML='<span class="muted">추가됨</span>'};
$('orgRows').onclick=async e=>{let b=e.target.closest('button');if(!b)return;
 if(b.dataset.orgProfile){$('navContacts').click();showFullProfile(b.dataset.orgProfile,'org');return}
 if(b.dataset.orgRm||b.dataset.orgRole){const [oid,k]=(b.dataset.orgRm||b.dataset.orgRole).split('|'),o=organizations.find(x=>x.id===oid),z=o?.members?.[Number(k)];if(!z)return;const prev=structuredClone(organizations);
  if(b.dataset.orgRm){if(!confirm(`${orgMemberInfo(z).name}님을 ${o.name}에서 뺄까요? (당원 정보는 그대로)`))return;o.members.splice(Number(k),1)}else{const r=prompt('직책',z.role||'위원');if(r===null)return;z.role=r.trim()||'위원'}
  try{await save()}catch(err){organizations=prev;alert('저장 실패: '+err.message);return}renderOrganizations();return}
 let id=b.dataset.oe||b.dataset.oa||b.dataset.od||b.dataset.osub,o=organizations.find(x=>x.id===id);if(!o)return;
 if(b.dataset.oe){editingOrg=o.id;$('orgName').value=o.name;fillOrgParentSelect(o.id,orgParentOf(o)?.id||'');$('orgType').value=o.type||'';$('orgChair').value=o.chair||'';$('orgMemo').value=o.memo||'';$('orgEditorTitle').textContent='조직 수정';$('orgEditor').classList.remove('hidden')}
 if(b.dataset.osub){editingOrg=null;['orgName','orgType','orgChair','orgMemo'].forEach(x=>$(x).value='');fillOrgParentSelect(null,o.id);$('orgEditorTitle').textContent=o.name+' 하위 조직 등록';$('orgEditor').classList.remove('hidden')}
 if(b.dataset.oa)openOrgMemberAdd(o);
 if(b.dataset.od){const kids=organizations.filter(x=>orgParentOf(x)?.id===o.id);if(!confirm(`'${o.name}' 조직을 삭제할까요?${kids.length?`\n하위 조직 ${kids.length}개는 최상위 조직으로 올라갑니다.`:''}\n당원 정보는 삭제되지 않습니다.`))return;const prev=structuredClone(organizations);for(const k of kids){k.parentId='';k.parent=''}organizations=organizations.filter(x=>x.id!==id);try{await save()}catch(err){organizations=prev;alert('삭제 실패: '+err.message)}renderOrganizations()}};
$('donorNew').onclick=()=>{editingDonor=null;['donorName','donorPhone','donorEmail','donorPostcode','donorAddress','donorWorkPostcode','donorWorkAddress','donorMemo','donationAmount','donationMemo','receiptDate','yearendDate'].forEach(x=>$(x).value='');donorAffsSet([]);$('donationDate').value=new Date().toISOString().slice(0,10);$('donationHistory').innerHTML='';$('donorEditorTitle').textContent='후원인 등록';$('donorEditor').classList.remove('hidden')};$('donorCancel').onclick=()=>$('donorEditor').classList.add('hidden');
$('donorSave').onclick=async()=>{let name=$('donorName').value.trim();if(!name){alert('후원인명을 입력하세요.');return}if(!editingDonor){const phone=$('donorPhone').value.replace(/\D/g,'');if(phone&&donors.some(d=>d.phone.replace(/\D/g,'')===phone)){alert('같은 휴대폰번호의 후원인이 이미 있습니다. 기존 후원인의 상세/수정에서 후원 이력을 추가하세요.');return}editingDonor=uid();donors.push({id:editingDonor,name,phone:$('donorPhone').value.trim(),email:$('donorEmail').value.trim(),postcode:$('donorPostcode').value.trim(),address:$('donorAddress').value.trim(),workPostcode:$('donorWorkPostcode').value.trim(),workAddress:$('donorWorkAddress').value.trim(),affiliations:donorAffsRead(),memo:$('donorMemo').value.trim(),donations:[]})}else{let d=donors.find(x=>x.id===editingDonor);Object.assign(d,{name,phone:$('donorPhone').value.trim(),email:$('donorEmail').value.trim(),postcode:$('donorPostcode').value.trim(),address:$('donorAddress').value.trim(),workPostcode:$('donorWorkPostcode').value.trim(),workAddress:$('donorWorkAddress').value.trim(),affiliations:donorAffsRead(),memo:$('donorMemo').value.trim()})}await linkAllRecords();activePhoneTab='all';render();renderDonors();alert('후원인 정보를 저장했습니다.')};
$('donationAdd').onclick=async()=>{if(!editingDonor){alert('먼저 후원인 정보를 저장하세요.');return}let date=$('donationDate').value,amount=Number($('donationAmount').value);if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isSafeInteger(amount)||amount<=0){alert('후원일자와 양의 정수 금액을 입력하세요.');return}let d=donors.find(x=>x.id===editingDonor);d.donations=d.donations||[];d.donations.push({id:uid(),date,amount,memo:$('donationMemo').value.trim(),receiptDate:$('receiptDate').value,yearendDate:$('yearendDate').value});await save();$('donationAmount').value='';$('donationMemo').value='';$('receiptDate').value='';$('yearendDate').value='';renderDonationHistory(d);renderDonors()};
function renderDonationHistory(d){$('donationHistory').innerHTML='<h3>후원 이력 '+(d.donations||[]).length+'회 · 누적 '+(d.donations||[]).reduce((s,x)=>s+x.amount,0).toLocaleString()+'원</h3>'+((d.donations||[]).slice().sort((a,b)=>b.date.localeCompare(a.date)).map(x=>`<div class="attendee">${esc(x.date)} · ${Number(x.amount).toLocaleString()}원 · ${esc(x.memo||'')} · 영수증 ${x.receiptDate?'발급완료 '+esc(x.receiptDate):'미발급'} · 연말정산 ${x.yearendDate?'등록완료 '+esc(x.yearendDate):'미등록'} <button data-re="${esc(x.id)}">처리일 수정</button> <button data-dd="${esc(x.id)}">삭제</button></div>`).join('')||'후원 이력이 없습니다.')}
$('donationHistory').onclick=async e=>{let b=e.target.closest('button');if(!b||!editingDonor)return;let d=donors.find(x=>x.id===editingDonor);if(b.dataset.re){let x=d.donations.find(x=>x.id===b.dataset.re);if(!x)return;const receipt=prompt('영수증 발급일자 (YYYY-MM-DD, 미발급은 빈칸)',x.receiptDate||'');if(receipt===null)return;const yearend=prompt('연말정산 등록일자 (YYYY-MM-DD, 미등록은 빈칸)',x.yearendDate||'');if(yearend===null)return;const valid=v=>!v||/^\d{4}-\d{2}-\d{2}$/.test(v)&&!Number.isNaN(Date.parse(v));if(!valid(receipt)||!valid(yearend)){alert('날짜를 YYYY-MM-DD 형식으로 입력하세요.');return}x.receiptDate=receipt;x.yearendDate=yearend;await save();renderDonationHistory(d);renderDonors();return}if(b.dataset.dd&&confirm('후원 이력을 삭제할까요?')){d.donations=d.donations.filter(x=>x.id!==b.dataset.dd);await save();renderDonationHistory(d);renderDonors()}};
function renderDonors(){let q=$('donorSearch').value.trim().toLowerCase();$('donorCount').textContent=donors.length.toLocaleString()+'명';let rows=donors.filter(d=>!q||[d.name,d.phone,d.email,...(d.affiliations||[]).flatMap(a=>[a.group,a.role])].join(' ').toLowerCase().includes(q));$('donorRows').innerHTML=listPager('donors','donorPager',renderDonors).slice(rows,q).map(d=>{let ds=d.donations||[],dates=ds.map(x=>x.date).sort();return `<tr><td>${esc(d.name)}${d.detachedFromContact&&!d.contactId?'<span class="tag-warn">주소록 연결 해제</span>':''}${(d.affiliations||[]).length?'<div class="mini">'+esc(d.affiliations.map(a=>a.group+(a.role?' '+a.role:'')).join(', '))+'</div>':''}</td><td>${esc(d.phone)}</td><td>${ds.length}회</td><td>${ds.reduce((s,x)=>s+Number(x.amount||0),0).toLocaleString()}원</td><td>${dates[0]||'-'}</td><td>${dates.at(-1)||'-'}</td><td><button data-de="${esc(d.id)}">상세/수정</button> <button class="danger" data-dx="${esc(d.id)}">삭제</button></td></tr>`}).join('')||'<tr><td colspan="7">등록된 후원인이 없습니다.</td></tr>'}
$('donorRows').onclick=async e=>{let b=e.target.closest('button');if(!b)return;let id=b.dataset.de||b.dataset.dx,d=donors.find(x=>x.id===id);if(!d)return;if(b.dataset.de){editingDonor=id;$('donorName').value=d.name||'';$('donorPhone').value=d.phone||'';$('donorEmail').value=d.email||'';$('donorPostcode').value=d.postcode||'';$('donorAddress').value=d.address||'';$('donorWorkPostcode').value=d.workPostcode||'';$('donorWorkAddress').value=d.workAddress||'';donorAffsSet(d.affiliations);$('donorMemo').value=d.memo||'';$('donationDate').value=new Date().toISOString().slice(0,10);$('donationAmount').value='';$('donationMemo').value='';$('donorEditorTitle').textContent='후원인 상세 및 수정';renderDonationHistory(d);$('donorEditor').classList.remove('hidden')}if(b.dataset.dx&&confirm('후원인과 후원 이력을 삭제할까요?')){donors=donors.filter(x=>x.id!==id);await save();renderDonors()}};$('donorSearch').oninput=renderDonors;
$('donorExport').onclick=()=>downloadCSV([['후원인명','휴대폰','이메일','주소','후원일자','후원금액','후원메모','영수증 발급일자','연말정산 등록일자'],...donors.flatMap(d=>(d.donations?.length?d.donations:[{}]).map(x=>[d.name,d.phone,d.email,d.address,x.date||'',x.amount||'',x.memo||'',x.receiptDate||'',x.yearendDate||'']))],'후원인현황.csv');

// Integrated identity resolution: never merge on name or phone alone.
const integratedContactFields=['name','birth','phone','landline','member','district','postcode','address','committee'];
function cleanPhone(v){return String(v||'').replace(/\D/g,'')}
// v0.4.14: 수만 명 규모에서도 빠르게 찾도록 이름·번호·당원번호 색인을 씁니다(판단 기준은 그대로).
function makeContactIndex(arr){
 const idx={byName:new Map(),byPhone:new Map(),byMember:new Map(),byId:new Map()};
 const put=(map,k,c)=>{if(!k)return;let s=map.get(k);if(!s){s=new Set();map.set(k,s)}s.add(c)};
 idx.add=c=>{put(idx.byName,String(c.name||'').trim(),c);put(idx.byPhone,cleanPhone(c.phone),c);put(idx.byMember,c.member?String(c.member).trim():'',c);idx.byId.set(c.id,c)};
 idx.get=(map,k)=>k&&map.has(k)?[...map.get(k)]:[];
 for(const c of arr)idx.add(c);return idx;
}
function identityFor(record,contacts,idx){
 if(idx)return identityForIndexed(record,idx);
 const name=String(record.name||'').trim(), phone=cleanPhone(record.phone);
 // Exact name + mobile is the primary identity key across every menu.
 if(name&&phone){
  const matches=contacts.filter(c=>String(c.name||'').trim()===name&&cleanPhone(c.phone)===phone);
  if(matches.length===1)return {status:'linked',contact:matches[0]};
  if(matches.length>1)return {status:'review',reason:'이름과 휴대폰번호가 같은 연락처가 여러 명'};
 }
 const no=String(record.member||'').trim(),birth=String(record.birth||'').trim();
 const strong=contacts.filter(c=>(no&&c.member&&String(c.member).trim()===no)||(name&&birth&&String(c.name||'').trim()===name&&String(c.birth||'').trim()===birth));
 if(strong.length>1)return {status:'review',reason:'동일인 후보가 여러 명'};
 if(strong.length===1){const c=strong[0];if((name&&c.name&&c.name!==name)||(phone&&cleanPhone(c.phone)&&cleanPhone(c.phone)!==phone))return {status:'review',reason:'식별정보 충돌'};return {status:'linked',contact:c}}
 const sameName=name?contacts.filter(c=>String(c.name||'').trim()===name):[];
 if(sameName.length){
  if(phone&&!contacts.some(c=>cleanPhone(c.phone)===phone)&&sameName.every(c=>cleanPhone(c.phone)&&cleanPhone(c.phone)!==phone))return {status:'new'};
  return {status:'review',reason:'동명이인 가능성 — 기존 연락처 또는 새 명단에 휴대폰번호가 없어 확인 필요'};
 }
 if(phone&&contacts.some(c=>cleanPhone(c.phone)===phone))return {status:'review',reason:'휴대폰번호 일치 — 이름 확인 필요'};
 return {status:'new'};
}
function memberAsContact(m){return {name:m.memberName||'',birth:normalizePartyBirth(m.birthDate),phone:m.mobilePhone||'',landline:m.homePhone||'',member:m.memberNo||'',district:m.adminDong||'',postcode:m.postcode||'',address:m.roadAddress||m.lotAddress||'',committee:m.districtElectoral||''}}
function identityForIndexed(record,idx){
 const name=String(record.name||'').trim(), phone=cleanPhone(record.phone);
 const named=name?idx.get(idx.byName,name).filter(c=>String(c.name||'').trim()===name):[];
 if(name&&phone){
  const matches=named.filter(c=>cleanPhone(c.phone)===phone);
  if(matches.length===1)return {status:'linked',contact:matches[0]};
  if(matches.length>1)return {status:'review',reason:'이름과 휴대폰번호가 같은 연락처가 여러 명'};
 }
 const no=String(record.member||'').trim(),birth=String(record.birth||'').trim();
 const cand=new Set([...(no?idx.get(idx.byMember,no):[]),...(birth?named:[])]);
 const strong=[...cand].filter(c=>(no&&c.member&&String(c.member).trim()===no)||(name&&birth&&String(c.name||'').trim()===name&&String(c.birth||'').trim()===birth));
 if(strong.length>1)return {status:'review',reason:'동일인 후보가 여러 명'};
 if(strong.length===1){const c=strong[0];if((name&&c.name&&c.name!==name)||(phone&&cleanPhone(c.phone)&&cleanPhone(c.phone)!==phone))return {status:'review',reason:'식별정보 충돌'};return {status:'linked',contact:c}}
 const phoneUsed=phone?idx.get(idx.byPhone,phone).some(c=>cleanPhone(c.phone)===phone):false;
 if(named.length){
  if(phone&&!phoneUsed&&named.every(c=>cleanPhone(c.phone)&&cleanPhone(c.phone)!==phone))return {status:'new'};
  return {status:'review',reason:'동명이인 가능성 — 기존 연락처 또는 새 명단에 휴대폰번호가 없어 확인 필요'};
 }
 if(phoneUsed)return {status:'review',reason:'휴대폰번호 일치 — 이름 확인 필요'};
 return {status:'new'};
}
function normalizePartyBirth(v){let t=String(v||'').trim();if(!t)return '';try{return formatBirth(t)}catch(e){return t}}
function donorAsContact(d){return {name:d.name||'',phone:d.phone||'',address:d.address||'',birth:'',member:'',landline:'',district:'',postcode:d.address?(d.postcode||''):'',committee:''}}
function planIntegrated(type,records){
 const contacts=structuredClone(data),linked=type==='member'?structuredClone(members):structuredClone(donors);
 const plan={contacts,linked,newContacts:0,newRecords:0,updated:0,filled:0,reviews:[],skipped:0};
 const cidx=makeContactIndex(contacts),byNo=new Map();if(type==='member')for(const m of linked)if(m.memberNo&&!byNo.has(m.memberNo))byNo.set(m.memberNo,m);
 for(let i=0;i<records.length;i++){
  const r=records[i],base=type==='member'?memberAsContact(r):donorAsContact(r);
  if(type==='donor'&&(r.donationDate||r.donationAmount)){const a=Number(String(r.donationAmount||'').replace(/[,\s원]/g,''));if(!/^\d{4}-\d{2}-\d{2}$/.test(String(r.donationDate||''))||!Number.isSafeInteger(a)||a<=0){plan.reviews.push(`${i+2}행: 후원일자 또는 금액 오류`);continue}}
  if(!base.name){plan.reviews.push(`${i+2}행: 이름 누락`);continue}
  let existing=type==='member'?(r.memberNo?byNo.get(r.memberNo)||null:null):null;
  if(type==='donor'){
   const matches=linked.filter(d=>d.name===r.name&&cleanPhone(d.phone)&&cleanPhone(d.phone)===cleanPhone(r.phone));
   if(matches.length>1){plan.reviews.push(`${i+2}행: 후원인 중복 후보 다수`);continue}
   existing=matches[0]||null;
   if(!existing){const same=linked.filter(d=>d.name===r.name),ph=cleanPhone(r.phone);if(same.length&&!(ph&&same.every(d=>cleanPhone(d.phone)&&cleanPhone(d.phone)!==ph))){plan.reviews.push(`${i+2}행: 동명이인 가능성 — 휴대폰번호가 없어 후원인 확인 필요`);continue}}
  }
  let result=existing?.contactId?{status:'linked',contact:cidx.byId.get(existing.contactId)}:identityFor(base,contacts,cidx);
  if(result.status==='linked'&&!result.contact)result=identityFor(base,contacts,cidx);
  if(result.status==='review'){plan.reviews.push(`${i+2}행 ${base.name}: ${result.reason}`);continue}
  let c=result.contact;
  if(!c){c={id:uid(),...base,recs:[],affiliations:[]};contacts.push(c);cidx.add(c);plan.newContacts++}
  else{
   // v0.4.16: 전화번호는 하이픈·띄어쓰기 등 표기와 관계없이 숫자만 같으면 같은 번호로 봄
   const conflicts=integratedContactFields.filter(k=>base[k]&&c[k]&&((k==='phone'||k==='landline')?cleanPhone(base[k])!==cleanPhone(c[k]):String(base[k]).trim()!==String(c[k]).trim()));
   if(conflicts.length){plan.reviews.push(`${i+2}행 ${base.name}: 기존 연락처와 충돌 (${conflicts.join(', ')})`);continue}
   for(const k of integratedContactFields)if(base[k]&&!c[k]){c[k]=base[k];plan.filled++}
   cidx.add(c);
  }
  if(type==='member'){
   if(existing){for(const [k] of memberSchema)if(r[k]&&!existing[k]){existing[k]=r[k];plan.filled++}existing.contactId=c.id;plan.updated++}
   else {const nm={...r,id:uid(),contactId:c.id};linked.push(nm);if(nm.memberNo&&!byNo.has(nm.memberNo))byNo.set(nm.memberNo,nm);plan.newRecords++}
  }else{
   if(existing){for(const k of ['email','postcode','address','workPostcode','workAddress','memo'])if(r[k]&&!existing[k]){existing[k]=r[k];plan.filled++}if(r.affiliations?.length){existing.affiliations=existing.affiliations||[];for(const a of r.affiliations)if(!existing.affiliations.some(x=>x.group===a.group&&x.role===a.role)){existing.affiliations.push(a);plan.filled++}}}
   else{existing={id:uid(),name:r.name,phone:r.phone||'',email:r.email||'',postcode:r.postcode||'',address:r.address||'',workPostcode:r.workPostcode||'',workAddress:r.workAddress||'',affiliations:r.affiliations||[],memo:r.memo||'',donations:[],contactId:c.id};linked.push(existing);plan.newRecords++}
   existing.contactId=c.id;
   if(r.donationDate||r.donationAmount){
    const amount=Number(String(r.donationAmount||'').replace(/[,\s원]/g,''));const date=String(r.donationDate||'').trim();
    if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isSafeInteger(amount)||amount<=0){plan.reviews.push(`${i+2}행 ${base.name}: 후원일자 또는 금액 오류`);continue}
    // Same date/amount/memo is ambiguous: skip rather than double-count.
    if(existing.donations.some(x=>x.date===date&&Number(x.amount)===amount&&String(x.memo||'')===String(r.donationMemo||''))){plan.skipped++;continue}
    existing.donations.push({id:uid(),date,amount,memo:r.donationMemo||'',receiptDate:r.receiptDate||'',yearendDate:r.yearendDate||''});plan.updated++;
   }
  }
 }
 return plan;
}
async function commitIntegrated(plan,type,label){
 const summary=`${label} 교차검사 결과\n신규 연락처 ${plan.newContacts}명 / 신규 ${type==='member'?'당원':'후원인'} ${plan.newRecords}명\n기존 정보 보완 ${plan.filled}건 / 추가 기록 ${plan.updated}건\n중복 건너뜀 ${plan.skipped}건 / 확인 필요 ${plan.reviews.length}건\n\n확인 필요 항목은 자동 반영하지 않습니다.\n\n${plan.reviews.slice(0,18).join('\n')||'충돌 없음'}\n\n검사 결과대로 반영할까요?`;
 if(!confirm(summary))return;
 const snapshot=await encryptedPayload(),oldData=data,oldMembers=members,oldDonors=donors;
 // Encrypted backup is downloaded BEFORE changing the working dataset.
 const backupBlob=new Blob([snapshot],{type:'application/json'}),backupUrl=URL.createObjectURL(backupBlob),a=document.createElement('a');a.href=backupUrl;a.download='주소록_업로드전_암호화백업_'+new Date().toISOString().replace(/[:.]/g,'-')+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(backupUrl),3000);
 try{data=plan.contacts;if(type==='member')members=plan.linked;else donors=plan.linked;await save()}catch(e){data=oldData;members=oldMembers;donors=oldDonors;throw e}
 activePhoneTab='all';render();renderMembers();renderDonors();
 downloadCSV([['확인 필요 내용'],...plan.reviews.map(x=>[x])],`${label}_검토필요.csv`);
 alert('반영 완료. 암호화 백업 파일을 안전하게 보관하세요.');
}
async function importIntegratedFile(e,type){
 const file=e.target.files?.[0];if(!file)return;
 try{
  if(file.size>15e6)throw Error('15MB 이하 파일만 지원합니다.');
  const rows=/\.xlsx$/i.test(file.name)?await parseXlsx(file):/\.csv$/i.test(file.name)?parseCSV(await file.text()):null;
  if(!rows?.length)throw Error('CSV 또는 XLSX 파일을 선택하세요.');
  const headers=rows[0].map(cleanHeader),get=(row,aliases)=>{const i=headers.findIndex(h=>aliases.some(a=>cleanHeader(a)===h));return i<0?'':String(row[i]??'').trim()};
  const records=rows.slice(1).filter(r=>r.some(v=>String(v??'').trim())).map(row=>{
   if(type==='member'){const m={};memberSchema.forEach(([k,l])=>m[k]=get(row,[l,k]));return m}
   return {name:get(row,['후원인명','이름','성명']),phone:get(row,['휴대폰','휴대전화','휴대폰번호','전화번호']),email:get(row,['이메일']),postcode:get(row,['집 우편번호','집우편번호','우편번호']),address:get(row,['집주소','집 주소','주소']),workPostcode:get(row,['직장 우편번호','직장우편번호']),workAddress:get(row,['직장주소','직장 주소']),affiliations:donorAffParse(get(row,['소속 단체','소속단체','소속']),get(row,['직책'])),memo:get(row,['후원인메모','메모']),donationDate:get(row,['후원일자','후원날짜']),donationAmount:get(row,['후원금액','금액']),donationMemo:get(row,['후원메모','후원내역메모']),receiptDate:get(row,['영수증 발급일자','영수증발급일자']),yearendDate:get(row,['연말정산 등록일자','연말정산등록일자'])};
  });
  if(!records.length)throw Error('등록할 데이터가 없습니다.');if(!headers.includes(cleanHeader(type==='member'?'당원명':'후원인명'))&&!headers.includes(cleanHeader('이름')))throw Error('명단의 이름 열을 찾지 못했습니다.');
  await commitIntegrated(planIntegrated(type,records),type,type==='member'?'당원명부':'후원인명부');
 }catch(err){alert('통합 가져오기 실패: '+err.message)}finally{e.target.value=''}
}
async function reconcileExistingRecords(){
 const idx=makeContactIndex(data);
 const reconcile=(record,base)=>{
  if(record.detachedFromContact&&!record.contactId)return;
  const current=record.contactId?idx.byId.get(record.contactId):null;
  const result=current?{status:'linked',contact:current}:identityFor(base,data,idx);
  if(result.status==='review')return;
  let c=result.contact;
  if(!c){c={id:uid(),...base,recs:[],affiliations:[]};data.push(c);idx.add(c)}
  record.contactId=c.id;
  let filled=false;for(const k of integratedContactFields){if(base[k]&&!c[k]){c[k]=base[k];filled=true}}
  if(filled)idx.add(c);
 };
 for(const m of members)reconcile(m,memberAsContact(m));
 for(const d of donors)reconcile(d,donorAsContact(d));
}
async function linkAllRecords(){
 const oldData=structuredClone(data),oldMembers=structuredClone(members),oldDonors=structuredClone(donors);
 try{await reconcileExistingRecords();await save();render()}
 catch(e){data=oldData;members=oldMembers;donors=oldDonors;throw e}
}
// Reconcile existing separate records only after the user approves.
window.reconcileAddressbookRecords=async()=>{
 if(!confirm('기존 당원·후원인 명단을 전체 주소록과 이름+휴대폰번호로 대조해 연결합니다. 계속할까요?'))return;
 const backup=await encryptedPayload(),blob=new Blob([backup],{type:'application/json'}),u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='주소록_통합전_암호화백업.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),3000);
 await linkAllRecords();renderMembers();renderDonors();alert('연결 완료. 동명이인 또는 번호 충돌 기록은 자동 병합하지 않았습니다.');
};
function downloadXlsxRows(rows,filename){
 const xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+rows.map((r,i)=>'<row r="'+(i+1)+'">'+r.map((v,j)=>'<c r="'+colName(j)+(i+1)+'" t="inlineStr"><is><t xml:space="preserve">'+xesc(v??'')+'</t></is></c>').join('')+'</row>').join('')+'</sheetData></worksheet>';
 const files=[['[Content_Types].xml','<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'],['_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],['xl/workbook.xml','<?xml version="1.0"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="목록" sheetId="1" r:id="rId1"/></sheets></workbook>'],['xl/_rels/workbook.xml.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'],['xl/worksheets/sheet1.xml',xml]];
 const url=URL.createObjectURL(zipStore(files)),a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);
}
const donorHeaders=['후원인명','휴대폰','이메일','집 우편번호','집주소','직장 우편번호','직장주소','소속 단체','직책','후원인메모','후원일자','후원금액','후원메모','영수증 발급일자','연말정산 등록일자'];
$('memberExport').onclick=()=>downloadXlsxRows([memberSchema.map(x=>x[1]),...members.map(m=>memberSchema.map(([k])=>m[k]||''))],'당원명단.xlsx');
$('donorExport').onclick=()=>downloadXlsxRows([donorHeaders,...donors.flatMap(d=>d.donations?.length?d.donations.map(x=>[d.name,d.phone,d.email,d.postcode||'',d.address||'',d.workPostcode||'',d.workAddress||'',...donorAffCols(d),d.memo||'',x.date,x.amount,x.memo||'',x.receiptDate||'',x.yearendDate||'']):[[d.name,d.phone,d.email,d.postcode||'',d.address||'',d.workPostcode||'',d.workAddress||'',...donorAffCols(d),d.memo||'','','','','','']])],'후원인_후원이력.xlsx');
$('donorImport').onchange=e=>importIntegratedFile(e,'donor');


$('memberTemplate').onclick=()=>downloadXlsxRows([memberSchema.map(x=>x[1])],'당원_입력양식.xlsx');
$('donorTemplate').onclick=()=>downloadXlsxRows([donorHeaders],'후원인_입력양식.xlsx');
// Full read-only person profile, shown beside the contact list rather than in an alert.
let selectedPersonId=null;
const memberLabels=Object.fromEntries(memberSchema);
const contactLabels={name:'이름',birth:'생년월일',phone:'휴대폰번호',landline:'집전화번호',member:'당원번호',district:'행정동',committee:'지역위원회',postcode:'우편번호',address:'주소',detail:'상세주소',group:'소속 단체',role:'직책',memo:'메모',birthplace:'출생지',occupation:'직업',refusal:'수신거절',refusalReason:'수신거절 사유',recs:'추천인',primary:'대표 추천인',affiliations:'소속 및 직책'};
const donorLabels={name:'후원인명',phone:'휴대폰번호',email:'이메일',postcode:'집 우편번호',address:'집주소',workPostcode:'직장 우편번호',workAddress:'직장주소',affiliations:'소속 단체 · 직책',memo:'후원인 메모',contactId:'연결 연락처 ID'};
const donationLabels={date:'후원일자',amount:'후원금액(원)',memo:'후원 메모',receiptDate:'영수증 발급일자',yearendDate:'연말정산 등록일자'};
function profileValue(v){if(v===null||v===undefined||v==='')return '미등록';if(Array.isArray(v)&&v.length&&v.every(x=>x&&typeof x==='object'&&'group' in x))return v.map(x=>x.group+(x.role?' · '+x.role:'')).join(', ');if(Array.isArray(v))return v.length?v.map(x=>typeof x==='object'?Object.entries(x).filter(([k])=>k!=='id').map(([k,z])=>k+': '+String(z??'')).join(' / '):String(x)).join('; '):'미등록';if(typeof v==='object')return Object.entries(v).map(([k,z])=>k+': '+String(z??'')).join('; ')||'미등록';return String(v)}
const HIDDEN_PROFILE_KEYS=new Set(['id','refusalChangedAt','detachedFromContact','removedAttendees']);
function profileRows(o,labels,exclude=[]){return '<dl>'+Object.entries(o||{}).filter(([k])=>!HIDDEN_PROFILE_KEYS.has(k)&&!exclude.includes(k)).map(([k,v])=>`<dt>${esc(labels[k]||k)}</dt><dd>${esc(profileValue(v))}</dd>`).join('')+'</dl>'}
function profileSection(title,body,open=false){return `<details ${open?'open':''}><summary>${esc(title)}</summary>${body}</details>`}
function profileMarkup(id){const c=data.find(x=>x.id===id);if(!c)return '<p>연락처를 찾을 수 없습니다.</p>';
 const norm=(v)=>String(v||'').replace(/\D/g,'');const same=(x)=>x.contactId===id||(!x.contactId&&x.name===c.name&&norm(x.phone)&&norm(x.phone)===norm(c.phone));
 const ms=members.filter(m=>m.contactId===id||(!m.contactId&&m.memberName===c.name&&norm(m.mobilePhone)&&norm(m.mobilePhone)===norm(c.phone)));
 const ds=donors.filter(same);const evs=events.filter(e=>e.attendees?.[id]);
 const orgs=organizations.flatMap(o=>(o.members||[]).filter(z=>ms.some(m=>m.id===z.memberId)).map(z=>({organization:o.name,organizationType:o.type,parent:o.parent,role:z.role,appointedAt:z.appointedAt||'',endedAt:z.endedAt||'',status:z.status||(!z.endedAt?'현직':'종료'),memo:z.memo||''})));
 const aff=affiliations(c).map(a=>({organization:a.group,role:a.role}));
 const total=ds.reduce((n,d)=>n+(d.donations||[]).reduce((sum,x)=>sum+Number(x.amount||0),0),0),count=ds.reduce((n,d)=>n+(d.donations||[]).length,0);
 let sections=profileSection('기본정보 · 전체 항목',profileRows(c,contactLabels),true);
 sections+=profileSection(`당원정보 · ${ms.length}건`,ms.length?ms.map((m,i)=>`<div class="history-card"><strong>당원 기록 ${i+1}</strong>${profileRows(m,memberLabels,['contactId'])}</div>`).join(''):'<p class="muted">등록된 당원정보 없음</p>');
 sections+=profileSection(`정당 직책 · ${orgs.length}건`,orgs.length||aff.length?[...orgs,...aff].map((o,i)=>`<div class="history-card"><strong>직책 ${i+1}</strong>${profileRows(o,{organization:'소속 조직',organizationType:'조직 유형',parent:'상위 조직',role:'직책',appointedAt:'임명일',endedAt:'종료일',status:'재임 상태',memo:'비고'})}</div>`).join(''):'<p class="muted">등록된 정당 직책 없음</p>');
 sections+=profileSection(`후원인정보 · ${ds.length}건`,ds.length?ds.map((d,i)=>`<div class="history-card"><strong>후원인 기록 ${i+1}</strong>${profileRows(d,donorLabels,['donations','contactId'])}</div>`).join(''):'<p class="muted">등록된 후원인정보 없음</p>');
 sections+=profileSection(`후원이력 · ${count}회 / ${total.toLocaleString()}원`,ds.flatMap(d=>d.donations||[]).map((v,i)=>`<div class="history-card"><strong>후원 ${i+1}회차</strong>${profileRows(v,donationLabels)}</div>`).join('')||'<p class="muted">등록된 후원이력 없음</p>');
 sections+=profileSection(`행사 참석 이력 · ${evs.length}건`,evs.map(e=>`<div class="history-card">${profileRows({title:e.title,date:e.date,place:e.place,attendance:e.attendees?.[id]}, {title:'행사명',date:'행사일',place:'장소',attendance:'참석 정보'})}</div>`).join('')||'<p class="muted">등록된 행사 이력 없음</p>');
 return `<h3>${esc(c.name||'이름 없음')} · 통합 상세정보</h3><p class="muted">${esc(c.phone||'휴대폰번호 미등록')}</p><div class="actions"><button type="button" id="profileNewWindow">새 창에서 보기</button><button type="button" id="profileClose">닫기</button></div>${sections}`;
}
function integratedPersonDetails(id){selectedPersonId=id;const panel=$('personDetailPanel');if(!panel)return;panel.innerHTML=profileMarkup(id);panel.querySelector('#profileClose').onclick=()=>{selectedPersonId=null;panel.innerHTML='<h3>통합 상세정보</h3><p class="muted">연락처를 선택하세요.</p>'};panel.querySelector('#profileNewWindow').onclick=()=>{const w=window.open('','_blank','width=1050,height=850');if(!w){alert('팝업 차단을 해제해 주세요.');return}const clone=panel.cloneNode(true);clone.querySelector('.actions')?.remove();const css=document.querySelector('style')?.textContent||'';w.document.open();w.document.write('<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>통합 상세정보</title><style>'+css+'body{padding:24px;max-width:1000px;margin:auto}.person-detail{max-height:none;position:static}</style></head><body><article class="person-detail">'+clone.innerHTML+'</article></body></html>');w.document.close()};}
const contactList=$('list');
// Capture the detail click before legacy delegated handlers; no browser alert.
// Full-screen handler installed below; legacy panel handler disabled.
// Contact editor navigation: all three edit modes reference the same contact ID.
const editNav=document.createElement('div');editNav.className='actions';editNav.id='linkedEditTabs';editNav.style.margin='12px 0';
editNav.innerHTML='<button type="button" data-linked-edit="contact" class="primary">기본정보 수정</button><button type="button" data-linked-edit="member">당원정보 수정</button><button type="button" data-linked-edit="donor">후원인정보 수정</button>';
$('formtitle').parentElement.after(editNav);
function linkedMatch(c,record,nameKey,phoneKey){return record.contactId===c.id||(!record.contactId&&normText(record[nameKey])===normText(c.name)&&normPhone(record[phoneKey])!==''&&normPhone(record[phoneKey])===normPhone(c.phone))}
function openLinkedEdit(kind,id){const c=data.find(x=>x.id===id);if(!c)return;
 if(kind==='contact'){open(c);return}
 if(kind==='member'){
   const matches=members.filter(m=>linkedMatch(c,m,'memberName','mobilePhone'));
   if(matches.length>1){alert('연결된 당원 기록이 여러 건입니다. 당원관리에서 선택해 주세요.');return}
   $('navMembers').click();openMember(matches[0]||null);
   $('mf_contact').value=c.id;
   if(!matches.length){$('mf_memberName').value=c.name||'';$('mf_mobilePhone').value=c.phone||'';$('mf_birthDate').value=c.birth||'';}
   $('memberEditor').scrollIntoView({block:'start'});
 }else if(kind==='donor'){
   const matches=donors.filter(d=>linkedMatch(c,d,'name','phone'));
   if(matches.length>1){alert('연결된 후원인 기록이 여러 건입니다. 후원인관리에서 선택해 주세요.');return}
   $('navDonors').click();
   if(matches.length){const d=matches[0];editingDonor=d.id;$('donorName').value=d.name||'';$('donorPhone').value=d.phone||'';$('donorEmail').value=d.email||'';$('donorPostcode').value=d.postcode||'';$('donorAddress').value=d.address||'';$('donorWorkPostcode').value=d.workPostcode||'';$('donorWorkAddress').value=d.workAddress||'';donorAffsSet(d.affiliations);$('donorMemo').value=d.memo||'';$('donationDate').value=new Date().toISOString().slice(0,10);$('donationAmount').value='';$('donationMemo').value='';$('donorEditorTitle').textContent='후원인 상세 및 수정';renderDonationHistory(d);$('donorEditor').classList.remove('hidden')}
   else{$('donorNew').click();$('donorName').value=c.name||'';$('donorPhone').value=c.phone||'';$('donorPostcode').value=c.postcode||'';$('donorAddress').value=[c.address,c.detail].filter(Boolean).join(' ');}
   $('donorEditor').scrollIntoView({block:'start'});
 }
}
editNav.addEventListener('click',e=>{const b=e.target.closest('[data-linked-edit]');if(b&&editing)openLinkedEdit(b.dataset.linkedEdit,editing)});
// The detail panel also offers direct edit actions without a popup.
const oldIntegratedPersonDetails=integratedPersonDetails;
integratedPersonDetails=function(id){oldIntegratedPersonDetails(id);const panel=$('personDetailPanel');const actions=panel.querySelector('.actions');if(!actions)return;
 const btn=document.createElement('div');btn.className='actions';btn.innerHTML='<button type="button" data-panel-edit="contact">기본정보 수정</button><button type="button" data-panel-edit="member">당원정보 수정</button><button type="button" data-panel-edit="donor">후원인정보 수정</button>';
 actions.after(btn);btn.addEventListener('click',e=>{const b=e.target.closest('[data-panel-edit]');if(b)openLinkedEdit(b.dataset.panelEdit,id)});
};

// Full-width profile page with one browser scrollbar and five navigation tabs.
const fullPage=$('personFullPage');
const contactsListPanel=$('list')?.closest('section.panel');
let fullTab='basic';
const fullTabs=[['basic','기본정보'],['party','당원정보'],['donor','후원정보'],['org','정당 직책'],['event','행사이력']];
function profileFieldGrid(obj,labels,exclude=[]){
 const pairs=Object.entries(obj||{}).filter(([k])=>!HIDDEN_PROFILE_KEYS.has(k)&&!exclude.includes(k));
 return '<dl class="profile-grid">'+pairs.map(([k,v])=>'<div class="profile-field"><dt>'+esc(labels[k]||k)+'</dt><dd>'+esc(profileValue(v))+'</dd></div>').join('')+'</dl>';
}
function personFullContent(c,tab){
 const norm=v=>String(v||'').replace(/\D/g,'');
 const same=(x,n,p)=>x.contactId===c.id||(!x.contactId&&normText(x[n])===normText(c.name)&&norm(x[p])&&norm(x[p])===norm(c.phone));
 const ms=members.filter(m=>same(m,'memberName','mobilePhone'));
 const ds=donors.filter(d=>same(d,'name','phone'));
 const orgs=organizations.flatMap(o=>(o.members||[]).filter(z=>ms.some(m=>m.id===z.memberId)).map(z=>({organization:o.name,organizationType:o.type,parent:o.parent,role:z.role,appointedAt:z.appointedAt||'',endedAt:z.endedAt||'',status:z.status||(!z.endedAt?'현직':'종료'),memo:z.memo||''})));
 const aff=affiliations(c).map(a=>({organization:a.group,role:a.role}));
 const evs=events.filter(e=>e.attendees?.[c.id]);
 const record=(title,o,labels,exclude=[])=>'<article class="profile-record"><h3>'+esc(title)+'</h3>'+profileFieldGrid(o,labels,exclude)+'</article>';
 const empty=message=>'<div class="profile-empty">'+esc(message)+'</div>';
 if(tab==='basic')return '<article class="profile-record"><h3>기본정보 · 등록된 전체 항목</h3>'+profileFieldGrid(basicView(c),basicLabels)+'</article>';
 if(tab==='party')return ms.length?ms.map((m,i)=>record('당원 기록 '+(i+1),m,memberLabels,['contactId'])).join(''):empty('등록된 당원정보가 없습니다.');
 if(tab==='org')return orgs.length||aff.length?[...orgs,...aff].map((o,i)=>record('정당 직책 '+(i+1),o,{organization:'소속 조직',organizationType:'조직 유형',parent:'상위 조직',role:'직책',appointedAt:'임명일',endedAt:'종료일',status:'재임 상태',memo:'비고'})).join(''):empty('등록된 정당 직책이 없습니다.');
 if(tab==='event')return evs.length?evs.slice().sort((a,b)=>evSort(b,a)).map((e,i)=>record('행사 '+(i+1),{title:e.title,date:e.date,startTime:e.startTime||'',endTime:e.endTime||'',place:e.place,attendance:attendanceLabel(e.attendees?.[c.id])},{title:'행사명',date:'행사일자',startTime:'시작시간',endTime:'종료시간',place:'장소',attendance:'참석정보'})).join(''):empty('등록된 행사 이력이 없습니다.');
 const donations=ds.flatMap(d=>d.donations||[]);
 const total=donations.reduce((sum,x)=>sum+Number(x.amount||0),0);
 return (ds.length?ds.map((d,i)=>record('후원인 정보 '+(i+1),d,donorLabels,['contactId','donations'])).join(''):empty('등록된 후원인정보가 없습니다.'))+
 '<h3>후원 이력 · '+donations.length+'건 / '+total.toLocaleString()+'원</h3>'+
 (donations.length?donations.map((d,i)=>record('후원 '+(i+1)+'회차',d,donationLabels)).join(''):empty('후원 이력이 없습니다.'));
}
function showFullProfile(id,tab='basic'){
 const c=data.find(x=>x.id===id);if(!c)return;
 selectedPersonId=id;fullTab=tab;
 contactsListPanel.classList.add('hidden');$('personDetailPanel').classList.add('hidden');fullPage.classList.remove('hidden');
 fullPage.innerHTML='<div class="profile-head"><div><button type="button" id="profileBack">← 목록으로</button><h2 style="margin-top:14px">'+esc(c.name||'이름 없음')+'</h2><p class="muted">'+esc(c.phone||'휴대폰번호 미등록')+'</p></div><div class="actions"><button type="button" id="profileEdit">현재 항목 수정</button></div></div>'+
 '<nav class="profile-tabs" aria-label="통합 상세정보 메뉴">'+fullTabs.map(([key,label])=>'<button type="button" data-profile-tab="'+key+'" aria-selected="'+String(key===tab)+'">'+label+'</button>').join('')+'</nav><div id="profileTabContent">'+personFullContent(c,tab)+'</div>';
 fullPage.querySelector('#profileBack').onclick=()=>{fullPage.classList.add('hidden');contactsListPanel.classList.remove('hidden');window.scrollTo(0,0)};
 fullPage.querySelectorAll('[data-profile-tab]').forEach(b=>b.onclick=()=>showFullProfile(id,b.dataset.profileTab));
 fullPage.querySelector('#profileEdit').onclick=()=>{
   setProfileReturn(id,tab);
   if(tab==='party')openLinkedEdit('member',id);
   else if(tab==='donor')openLinkedEdit('donor',id);
   else if(tab==='basic')openLinkedEdit('contact',id);
   else if(tab==='org'){$('navMembers').click();$('orgRows')?.scrollIntoView({block:'center'});}
   else{$('navEvents').click();}
 };
 fullPage.scrollIntoView({block:'start'});
}
// Replace legacy integrated detail handlers; capture click before older listeners.
document.addEventListener('click',e=>{
 const btn=e.target.closest('button[data-person-detail]');
 if(!btn || !$('contactsPage')?.contains(btn))return;
 e.preventDefault();e.stopImmediatePropagation();
 try {showFullProfile(btn.dataset.personDetail)}
 catch(err){console.error('통합정보 표시 오류:',err);alert('통합정보를 열지 못했습니다: '+err.message)}
},true);
// Reopen the contact list when navigating back from other menus.
$('navContacts')?.addEventListener('click',()=>{
 if(!fullPage.classList.contains('hidden')){fullPage.classList.add('hidden');contactsListPanel.classList.remove('hidden')}
});

window.renderMembers=renderMembers;window.renderDonors=renderDonors;
// ===== v0.4.3: 기본정보 보기, 일괄 삭제(범위 선택·자동 백업), 서버 백업 복원, 통합정보 복귀 =====
window.APP_JS_VERSION='0.4.21';
// 체크박스 제목 칸은 이 파일이 직접 추가합니다(화면 파일과 버전이 섞여도 표가 밀리지 않도록).
{const head=$('list').closest('table').querySelector('thead tr');if(head&&!$('selectAll')){const th=document.createElement('th');th.className='sel';th.innerHTML='<input type="checkbox" id="selectAll" aria-label="이 페이지 전체 선택" title="이 페이지 전체 선택">';head.prepend(th)}}
const basicLabels={name:'이름',birth:'생년월일',phone:'휴대폰번호',landline:'일반전화',member:'당원번호',district:'행정동',committee:'소속 지역위원회',postcode:'우편번호',address:'주소',detail:'상세주소',birthplace:'출생지',occupation:'직업',affiliations:'소속 단체 및 직책',recs:'추천인',primary:'대표 추천인',refusal:'수신거절',refusalReason:'수신거절 사유',memo:'메모'};
function basicView(c){
 const o={};
 for(const k of Object.keys(basicLabels))o[k]=c[k];
 o.affiliations=affiliations(c).map(a=>[a.group,a.role].filter(Boolean).join(' / ')).join(', ');
 o.recs=(c.recs||[]).map(r=>r.name+(recStatus(r).contact?' [DB 등록]':' [미등록]')).join(', ');
 o.primary=(c.recs||[]).find(r=>r.id===c.primary)?.name||'';
 o.refusal=c.refusal&&c.refusal!=='none'?refusalLabel(c.refusal):'없음';
 // 알 수 없는 추가 항목도 숨기지 않고 표시 (group/role은 소속 항목과 중복이라 제외)
 for(const [k,v] of Object.entries(c))if(!(k in o)&&!HIDDEN_PROFILE_KEYS.has(k)&&!['group','role'].includes(k))o[k]=v;
 return o;
}
function updateBulkBar(){
 const n=selectedIds.size;$('selCount').textContent=String(n);$('bulkDelete').disabled=!n;
 $('bulkDelete').textContent=n?`🗑 선택한 ${n}명 삭제`:'🗑 선택한 연락처 삭제';
 const all=$('selectAll'),vis=lastPageItems.filter(c=>selectedIds.has(c.id)).length;
 all.checked=lastPageItems.length>0&&vis===lastPageItems.length;all.indeterminate=vis>0&&vis<lastPageItems.length;
 $('selectVisible').textContent=`검색 결과 전체 선택 (${lastFound.length}명)`;
}
$('list').addEventListener('change',e=>{const cb=e.target.closest('input[data-select]');if(!cb)return;if(cb.checked)selectedIds.add(cb.dataset.select);else selectedIds.delete(cb.dataset.select);cb.closest('tr')?.classList.toggle('row-selected',cb.checked);updateBulkBar()});
$('selectAll').addEventListener('change',e=>{for(const c of lastPageItems){if(e.target.checked)selectedIds.add(c.id);else selectedIds.delete(c.id)}render()});
$('selectVisible').onclick=()=>{for(const c of lastFound)selectedIds.add(c.id);render()};
$('selectNone').onclick=()=>{selectedIds.clear();render()};
$('bulkDelete').onclick=()=>openDeleteDialog([...selectedIds]);
$('contactPager').addEventListener('click',e=>{const b=e.target.closest('[data-page]');if(!b||b.disabled)return;contactPage=Number(b.dataset.page);render();$('list').closest('table').scrollIntoView({block:'start'})});
$('contactPager').addEventListener('change',e=>{if(e.target.id!=='pageSize')return;contactPageSize=e.target.value==='all'?'all':Number(e.target.value);try{localStorage.setItem('addressbook-page-size',String(contactPageSize))}catch(err){}contactPage=1;render()});

// 연결 기록 찾기: 고유 ID 연결이 우선이며, ID가 없는 기록만 이름+휴대폰번호가 모두 같을 때 동일인으로 봅니다.
function linkedRecordsFor(c){
 const n=normText(c.name),p=normPhone(c.phone);
 const loose=(r,nk,pk)=>!r.contactId&&!!n&&!!p&&normText(r[nk])===n&&normPhone(r[pk])===p;
 return {ms:members.filter(m=>m.contactId===c.id||loose(m,'memberName','mobilePhone')),ds:donors.filter(d=>d.contactId===c.id||loose(d,'name','phone'))};
}
function deletionPlan(ids){
 const idSet=new Set(ids),contacts=data.filter(c=>idSet.has(c.id));
 const per=contacts.map(c=>{const l=linkedRecordsFor(c);const mids=new Set(l.ms.map(m=>m.id));return {c,...l,
  evs:events.filter(e=>Object.prototype.hasOwnProperty.call(e.attendees||{},c.id)).length,
  orgs:organizations.reduce((n,o)=>n+(o.members||[]).filter(z=>mids.has(z.memberId)).length,0),
  donations:l.ds.reduce((n,d)=>n+(d.donations||[]).length,0)}});
 const memberIds=new Set(per.flatMap(x=>x.ms.map(m=>m.id))),donorIds=new Set(per.flatMap(x=>x.ds.map(d=>d.id)));
 return {idSet,contacts,per,memberIds,donorIds,
  donationCount:donors.filter(d=>donorIds.has(d.id)).reduce((n,d)=>n+(d.donations||[]).length,0),
  attendance:events.reduce((n,e)=>n+Object.keys(e.attendees||{}).filter(k=>idSet.has(k)).length,0),
  orgRoles:organizations.reduce((n,o)=>n+(o.members||[]).filter(z=>memberIds.has(z.memberId)).length,0)};
}
function applyDeletion(plan,scope){
 const {idSet,memberIds,donorIds}=plan;
 data=data.filter(c=>!idSet.has(c.id));
 for(const c of data){for(const r of c.recs||[])if(r.contactId&&idSet.has(r.contactId))r.contactId=null}
 if(scope==='all'){
  members=members.filter(m=>!memberIds.has(m.id));
  donors=donors.filter(d=>!donorIds.has(d.id));
  for(const e of events){for(const k of Object.keys(e.attendees||{}))if(idSet.has(k))delete e.attendees[k];if(e.removedAttendees)for(const k of Object.keys(e.removedAttendees))if(idSet.has(k))delete e.removedAttendees[k]}
  for(const o of organizations)o.members=(o.members||[]).filter(z=>!memberIds.has(z.memberId));
 }else{
  // 연결 데이터는 보존하고 주소록 연결만 해제. 자동 연결로 연락처가 다시 생성되지 않도록 표시합니다.
  for(const m of members)if(memberIds.has(m.id)){m.contactId=null;m.detachedFromContact=true}
  for(const d of donors)if(donorIds.has(d.id)){d.contactId=null;d.detachedFromContact=true}
  for(const e of events)for(const k of Object.keys(e.attendees||{}))if(idSet.has(k)){const c=plan.contacts.find(x=>x.id===k);e.removedAttendees=e.removedAttendees||{};e.removedAttendees[k]={name:c?.name||'',phone:c?.phone||''}}
 }
}
async function serverBackup(payload,reason){
 const r=await fetch('/api/backups',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':window.APP_CSRF},body:JSON.stringify({payload,reason})});
 if(!r.ok)throw Error('서버 백업 실패 (HTTP '+r.status+')');const j=await r.json();if(!j.ok)throw Error('서버 백업 실패');return j.id;
}
function downloadText(text,filename){const url=URL.createObjectURL(new Blob([text],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000)}
const stamp=()=>new Date().toISOString().replace(/[:.]/g,'-').slice(0,19);
let deleteIds=[];
function deleteScope(){return document.querySelector('input[name="deleteScope"]:checked')?.value||'contact'}
function drawDeletePreview(){
 const plan=deletionPlan(deleteIds),scope=deleteScope();
 $('deleteSummary').textContent=`선택한 ${plan.contacts.length}명을 삭제합니다. 삭제 범위를 선택하세요.`;
 const lines=plan.per.slice(0,60).map(x=>`<li><b>${esc(x.c.name)}</b> (${esc(x.c.phone||x.c.landline||'번호 없음')}) — 당원 ${x.ms.length}건 · 후원인 ${x.ds.length}건(후원 ${x.donations}회) · 행사 ${x.evs}건 · 직책 ${x.orgs}건</li>`).join('');
 const total=scope==='all'
  ?`<b>삭제 대상 합계</b>: 연락처 ${plan.contacts.length}명 · 당원 ${plan.memberIds.size}건 · 후원인 ${plan.donorIds.size}건 · 후원이력 ${plan.donationCount}건 · 행사 참석 ${plan.attendance}건 · 조직 직책 ${plan.orgRoles}건`
  :`<b>삭제 대상</b>: 연락처 ${plan.contacts.length}명만 삭제 · 연결 해제 후 보존: 당원 ${plan.memberIds.size}건 · 후원인 ${plan.donorIds.size}건 · 행사 참석 ${plan.attendance}건`;
 $('deletePreview').innerHTML=total+'<ul>'+lines+(plan.per.length>60?`<li>… 외 ${plan.per.length-60}명</li>`:'')+'</ul>';
 $('deleteAllConfirm').classList.toggle('hidden',scope!=='all');
 $('deleteDownload').disabled=scope==='all';if(scope==='all')$('deleteDownload').checked=true;
 $('deleteConfirm').textContent=scope==='all'?'백업 후 모든 연결 데이터 삭제':'백업 후 주소록에서 삭제';
 $('deleteConfirm').disabled=scope==='all'&&$('deleteConfirmText').value.trim()!=='삭제';
}
function openDeleteDialog(ids){
 deleteIds=ids.filter(id=>data.some(c=>c.id===id));if(!deleteIds.length){alert('삭제할 연락처를 선택하세요.');return}
 document.querySelector('input[name="deleteScope"][value="contact"]').checked=true;$('deleteConfirmText').value='';$('deleteError').textContent='';$('deleteDownload').checked=false;
 drawDeletePreview();$('deleteDialog').showModal();
}
document.querySelectorAll('input[name="deleteScope"]').forEach(r=>r.addEventListener('change',drawDeletePreview));
$('deleteConfirmText').addEventListener('input',drawDeletePreview);
$('deleteForm').addEventListener('submit',e=>e.preventDefault());
$('deleteCancel').onclick=()=>$('deleteDialog').close();
$('deleteConfirm').onclick=async()=>{
 const scope=deleteScope(),btn=$('deleteConfirm');
 if(scope==='all'&&$('deleteConfirmText').value.trim()!=='삭제'){$('deleteError').textContent="'삭제'를 정확히 입력하세요.";return}
 const plan=deletionPlan(deleteIds);if(!plan.contacts.length){$('deleteDialog').close();return}
 if(scope==='all'&&!confirm(`정말 ${plan.contacts.length}명의 연락처와 연결된 당원·후원·행사·직책 기록을 모두 삭제할까요?\n삭제 직전 백업이 저장됩니다.`))return;
 btn.disabled=true;$('deleteError').textContent='백업 중...';
 const prev={data:structuredClone(data),members:structuredClone(members),donors:structuredClone(donors),events:structuredClone(events),organizations:structuredClone(organizations)};
 try{
  const snapshot=await encryptedPayload();
  // 이유 문구에는 개인정보(이름)를 넣지 않습니다. 백업 본문은 암호화 상태로 저장됩니다.
  const backupId=await serverBackup(snapshot,`삭제 전 자동백업 · ${scope==='all'?'모든 연결 데이터 삭제':'주소록에서만 삭제'} · ${plan.contacts.length}명`);
  if(scope==='all'||$('deleteDownload').checked)downloadText(snapshot,'addressbook-before-delete-backup-'+stamp()+'.json');
  try{applyDeletion(plan,scope);await save()}
  catch(err){data=prev.data;members=prev.members;donors=prev.donors;events=prev.events;organizations=prev.organizations;throw err}
  for(const id of plan.idSet)selectedIds.delete(id);
  if(editing&&plan.idSet.has(editing))close();
  if(selectedPersonId&&plan.idSet.has(selectedPersonId)&&!$('personFullPage').classList.contains('hidden')){$('personFullPage').classList.add('hidden');contactsListPanel.classList.remove('hidden')}
  $('deleteDialog').close();render();renderMembers();renderDonors();
  alert(`삭제 완료 (${scope==='all'?'모든 연결 데이터':'주소록에서만'})\n연락처 ${plan.contacts.length}명`+(scope==='all'?` · 당원 ${plan.memberIds.size}건 · 후원인 ${plan.donorIds.size}건 · 행사 참석 ${plan.attendance}건 · 직책 ${plan.orgRoles}건`:` 삭제, 연결 기록은 보존`)+`\n자동 백업 번호: ${backupId} (‘자동 백업 목록·복원’에서 되돌릴 수 있습니다)`);
 }catch(err){$('deleteError').textContent='삭제하지 않았습니다: '+err.message}
 finally{btn.disabled=false;if(deleteScope()==='all')btn.disabled=$('deleteConfirmText').value.trim()!=='삭제'}
};

// 서버 자동 백업 목록 및 복원
async function decryptForRestore(obj){
 if(obj.format!=='district-addressbook-encrypted-v10'&&obj.format!=='district-addressbook-encrypted-v11')throw Error('지원하지 않는 백업 형식입니다.');
 if(vaultSalt&&obj.salt===b64(vaultSalt)){
  const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:un64(obj.iv)},vaultKey,un64(obj.ciphertext));const parsed=JSON.parse(td.decode(obj.compression==='gzip'?await gunzipBytes(plain):plain));
  return {contacts:normalize(Array.isArray(parsed)?parsed:parsed.contacts),events:Array.isArray(parsed.events)?parsed.events:[],members:Array.isArray(parsed.members)?parsed.members:[],organizations:Array.isArray(parsed.organizations)?parsed.organizations:[],institutions:Array.isArray(parsed.institutions)?parsed.institutions:[],anonymous:Array.isArray(parsed.anonymous)?parsed.anonymous:[],donors:Array.isArray(parsed.donors)?parsed.donors:[]};
 }
 const pw=prompt('이 백업은 다른 비밀번호로 암호화되어 있습니다. 백업 당시 비밀번호를 입력하세요.');if(pw===null)return null;return decryptPayload(obj,pw);
}
async function drawBackups(){
 $('backupError').textContent='';$('backupRows').innerHTML='불러오는 중...';
 try{const r=await fetch('/api/backups',{credentials:'same-origin'});if(!r.ok)throw Error('HTTP '+r.status);const j=await r.json();
  $('backupRows').innerHTML=j.backups.length?'<table style="min-width:0"><thead><tr><th>번호</th><th>저장 시각</th><th>사유</th><th>크기</th><th></th></tr></thead><tbody>'+j.backups.map(b=>`<tr><td>${b.id}</td><td>${esc(new Date(b.created*1000).toLocaleString('ko-KR'))}</td><td>${esc(b.reason)}</td><td>${Math.ceil(b.size/1024)}KB</td><td><button type="button" data-restore-backup="${b.id}">복원</button></td></tr>`).join('')+'</tbody></table>':'<p class="muted">저장된 자동 백업이 없습니다.</p>';
 }catch(err){$('backupRows').innerHTML='';$('backupError').textContent='백업 목록을 불러오지 못했습니다: '+err.message}
}
$('serverBackups').onclick=()=>{$('backupDialog').showModal();drawBackups()};
$('backupClose').onclick=()=>$('backupDialog').close();
$('backupNow').onclick=async()=>{try{const id=await serverBackup(await encryptedPayload(),'수동 백업');await drawBackups();$('backupError').textContent='백업 '+id+'번을 저장했습니다.'}catch(err){$('backupError').textContent=err.message}};
$('backupRows').onclick=async e=>{
 const b=e.target.closest('[data-restore-backup]');if(!b)return;
 try{
  const r=await fetch('/api/backups/'+encodeURIComponent(b.dataset.restoreBackup),{credentials:'same-origin'});if(!r.ok)throw Error('HTTP '+r.status);
  const j=await r.json(),opened=await decryptForRestore(JSON.parse(j.payload));if(!opened)return;
  if(!confirm(`백업 ${b.dataset.restoreBackup}번으로 전체 데이터를 교체할까요?\n현재: 연락처 ${data.length}명 · 당원 ${members.length} · 후원인 ${donors.length} · 행사 ${events.length} · 기관 ${institutions.length} · 익명 ${anonymous.length}\n백업: 연락처 ${opened.contacts.length}명 · 당원 ${opened.members.length} · 후원인 ${opened.donors.length} · 행사 ${opened.events.length} · 기관 ${(opened.institutions||[]).length} · 익명 ${(opened.anonymous||[]).length}\n교체 직전 현재 상태도 자동 백업됩니다.`))return;
  await serverBackup(await encryptedPayload(),'복원 직전 자동백업 (백업 '+b.dataset.restoreBackup+'번 복원)');
  const prev={data,members,donors,events,organizations,institutions,anonymous};
  try{data=opened.contacts;members=opened.members;donors=opened.donors;events=opened.events;organizations=opened.organizations;institutions=opened.institutions||[];anonymous=opened.anonymous||[];await save()}
  catch(err){({data,members,donors,events,organizations,institutions,anonymous}=prev);throw err}
  selectedIds.clear();$('backupDialog').close();render();renderMembers();renderDonors();renderInstitutions();renderAnonymous();alert('복원이 완료되었습니다.');
 }catch(err){$('backupError').textContent='복원 실패: '+err.message}
};

// 통합정보 → 수정 → 저장 후 통합정보로 돌아오기
function setProfileReturn(id,tab){
 profileReturn={id,tab};let bar=$('returnBar');
 if(!bar){bar=document.createElement('div');bar.id='returnBar';bar.className='return-bar';$('vaultContent').prepend(bar)}
 const c=data.find(x=>x.id===id);
 bar.innerHTML=`<span>통합정보에서 수정 중: <b>${esc(c?.name||'')}</b> · 저장 후 아래 버튼으로 돌아가 결과를 확인하세요.</span><span class="actions"><button type="button" id="returnToProfile">← 통합정보로 돌아가기</button><button type="button" id="returnDismiss" aria-label="닫기">✕</button></span>`;
 bar.querySelector('#returnToProfile').onclick=returnToProfile;
 bar.querySelector('#returnDismiss').onclick=()=>{profileReturn=null;bar.remove()};
 setTimeout(()=>window.__popupSync?.(),0);
}
function returnToProfile(){
 const r=profileReturn;profileReturn=null;$('returnBar')?.remove();if(!r)return;
 $('editor').classList.add('hidden');$('memberEditor').classList.add('hidden');$('donorEditor').classList.add('hidden');
 $('navContacts').click();
 if(data.some(c=>c.id===r.id))showFullProfile(r.id,r.tab);else alert('연락처를 찾을 수 없습니다.');
}
{const orig=$('form').onsubmit;$('form').onsubmit=async e=>{await orig(e);if(profileReturn&&$('editor').classList.contains('hidden'))returnToProfile()}}
{const orig=$('memberForm').onsubmit;$('memberForm').onsubmit=async e=>{await orig(e);if(profileReturn&&$('memberEditor').classList.contains('hidden'))returnToProfile()}}


// ===== v0.4.9: 기관관리(학교·관공서 등) =====
const instSchema=[['name','기관명'],['category','분류'],['phone','대표전화'],['fax','팩스'],['district','행정동'],['postcode','우편번호'],['address','주소'],['detail','상세주소'],['head','기관장/대표자'],['contactName','담당자'],['contactRole','담당자 직위'],['contactPhone','담당자 연락처'],['email','이메일'],['website','홈페이지'],['memo','메모']];
const instCategories=['초등학교','중학교','고등학교','대학교','어린이집·유치원','관공서','주민센터','경찰·소방','복지시설','의료기관','종교시설','단체·협회','기업·상가','기타'];
let editingInst=null;
function instPhone(v){try{return formatPhone(v)}catch(e){return String(v||'').trim()}}
function instRelatedContacts(i){const n=normText(i.name);if(!n)return [];return data.filter(c=>affiliations(c).some(a=>normText(a.group)===n))}
function renderInstitutions(){
 const q=($('instSearch').value||'').trim().toLowerCase(),cat=$('instCategoryFilter').value;
 const rows=institutions.filter(i=>(!cat||i.category===cat)&&(!q||instSchema.map(([k])=>i[k]||'').join(' ').toLowerCase().includes(q))).sort((a,b)=>String(a.category||'').localeCompare(String(b.category||''))||String(a.name).localeCompare(String(b.name),'ko'));
 $('instCount').textContent=`${rows.length}곳 / 전체 ${institutions.length}곳`;
 $('instRows').innerHTML=rows.map(i=>{const rel=instRelatedContacts(i).length;return `<tr><td><strong>${esc(i.name)}</strong></td><td>${esc(i.category||'')}</td><td style="white-space:nowrap">${esc(i.phone||'')}</td><td style="white-space:nowrap">${esc(i.fax||'')}</td><td>${esc(i.email||'')}</td><td>${esc(i.district||'')}</td><td>${esc([i.address,i.detail].filter(Boolean).join(' '))}</td><td>${esc(i.contactName||'')}${i.contactRole?' <span class="mini">'+esc(i.contactRole)+'</span>':''}<div class="mini">${esc(i.contactPhone||'')}</div></td><td>${rel?rel+'명':'-'}</td><td style="white-space:nowrap"><button data-ie="${esc(i.id)}">상세/수정</button> <button class="danger" data-ix="${esc(i.id)}">삭제</button></td></tr>`}).join('')||'<tr><td colspan="10">등록된 기관이 없습니다. \'+ 기관 등록\'을 눌러 추가하세요.</td></tr>';
}
function openInstitution(i){
 editingInst=i?.id||null;
 for(const [k] of instSchema)$('if_'+k).value=i?.[k]||'';
 $('instEditorTitle').textContent=i?'기관 정보 수정':'기관 등록';
 const rel=i?instRelatedContacts(i):[];
 $('instRelated').innerHTML=i?('<h3>이 기관 소속으로 등록된 연락처 '+rel.length+'명</h3>'+(rel.length?rel.map(c=>`<span class="tag">${esc(c.name)} · ${esc(affiliations(c).filter(a=>normText(a.group)===normText(i.name)).map(a=>a.role).filter(Boolean).join(', ')||'직책 없음')} · ${esc(c.phone||c.landline||'번호 없음')}</span>`).join(''):'<p class="muted">연락처의 \'소속 단체\'에 이 기관명을 입력하면 여기에 표시됩니다.</p>')):'';
 $('instEditor').classList.remove('hidden');$('instEditor').scrollIntoView({behavior:'smooth',block:'start'});
}
$('instNew').onclick=()=>openInstitution(null);
$('instCancel').onclick=$('instCancel2').onclick=()=>{$('instEditor').classList.add('hidden');editingInst=null};
$('instForm').onsubmit=async e=>{
 e.preventDefault();
 const prev=institutions.find(x=>x.id===editingInst);
 const o={...(prev||{}),id:editingInst||uid()};
 for(const [k] of instSchema)o[k]=$('if_'+k).value.trim();
 if(!o.name){alert('기관명을 입력하세요.');return}
 o.phone=instPhone(o.phone);o.fax=instPhone(o.fax);o.contactPhone=instPhone(o.contactPhone);
 if(o.postcode&&!/^\d{5}$/.test(o.postcode)){alert('우편번호는 숫자 5자리로 입력하세요.');return}
 const dup=institutions.find(x=>x.id!==o.id&&normText(x.name)===normText(o.name)&&normPhone(x.phone)===normPhone(o.phone));
 if(dup){alert(`같은 기관명과 대표전화로 이미 등록된 기관이 있습니다: ${dup.name} ${dup.phone||''}\n기존 기관을 수정해 주세요.`);return}
 const old=structuredClone(institutions);
 const idx=institutions.findIndex(x=>x.id===o.id);if(idx>=0)institutions[idx]=o;else institutions.push(o);
 try{await save()}catch(err){institutions=old;alert('저장 실패: '+err.message);return}
 $('instEditor').classList.add('hidden');editingInst=null;renderInstitutions();
};
$('instRows').onclick=async e=>{
 const b=e.target.closest('button');if(!b)return;const id=b.dataset.ie||b.dataset.ix,i=institutions.find(x=>x.id===id);if(!i)return;
 if(b.dataset.ie)openInstitution(i);
 if(b.dataset.ix&&confirm(`'${i.name}' 기관을 삭제할까요?\n연락처의 소속 정보는 삭제되지 않습니다. 삭제 직전 자동 백업됩니다.`)){
  try{await serverBackup(await encryptedPayload(),'기관 삭제 전 자동백업')}catch(err){alert('자동 백업에 실패해 삭제하지 않았습니다: '+err.message);return}
  institutions=institutions.filter(x=>x.id!==id);await save();if(editingInst===id){$('instEditor').classList.add('hidden');editingInst=null}renderInstitutions();
 }
};
$('instSearch').oninput=renderInstitutions;$('instCategoryFilter').onchange=renderInstitutions;
$('instSearchClear').onclick=()=>{$('instSearch').value='';$('instCategoryFilter').value='';renderInstitutions()};
$('instExport').onclick=()=>downloadXlsxRows([instSchema.map(x=>x[1]),...institutions.map(i=>instSchema.map(([k])=>i[k]||''))],'기관목록.xlsx');
$('instTemplate').onclick=()=>downloadXlsxRows([instSchema.map(x=>x[1])],'기관_입력양식.xlsx');
$('instImport').onchange=async e=>{
 const file=e.target.files?.[0];if(!file)return;
 try{
  if(file.size>15e6)throw Error('15MB 이하 파일만 지원합니다.');
  const rows=/\.xlsx$/i.test(file.name)?await parseXlsx(file):/\.csv$/i.test(file.name)?parseCSV(await file.text()):null;
  if(!rows||rows.length<2)throw Error('제목 행과 데이터 행이 있는 CSV 또는 XLSX 파일이 필요합니다.');
  const h=rows[0].map(cleanHeader),aliases={name:['기관명','기관','학교명','이름','명칭'],category:['분류','구분','종류'],phone:['대표전화','전화번호','전화'],fax:['팩스','fax'],district:['행정동','동'],postcode:['우편번호'],address:['주소','도로명주소'],detail:['상세주소'],head:['기관장/대표자','기관장','대표자','교장'],contactName:['담당자','담당자명'],contactRole:['담당자 직위','직위','직책'],contactPhone:['담당자 연락처','담당자연락처','담당자 전화','휴대전화'],email:['이메일','email'],website:['홈페이지','웹사이트'],memo:['메모','비고']};
  const col=k=>h.findIndex(x=>(aliases[k]||[]).some(a=>cleanHeader(a)===x));
  const idx=Object.fromEntries(instSchema.map(([k])=>[k,col(k)]));
  if(idx.name<0)throw Error('첫 행에 기관명 열이 필요합니다.');
  const working=structuredClone(institutions),added=[],updated=[],skipped=[],review=[];
  for(let r=1;r<rows.length;r++){
   const row=rows[r];if(!row.some(v=>String(v??'').trim()))continue;
   const o={};for(const [k] of instSchema)o[k]=idx[k]<0?'':String(row[idx[k]]??'').trim();
   if(!o.name){review.push(`엑셀 ${r+(rows.headerRow||1)}행: 기관명 누락`);continue}
   o.phone=instPhone(o.phone);o.fax=instPhone(o.fax);o.contactPhone=instPhone(o.contactPhone);
   const same=working.filter(x=>normText(x.name)===normText(o.name));
   const match=same.find(x=>normPhone(x.phone)===normPhone(o.phone))||(same.length===1&&(!o.phone||!same[0].phone)?same[0]:null);
   if(!match){working.push({...o,id:uid()});added.push(o.name);continue}
   const changes=[];for(const [k,l] of instSchema){if(o[k]&&normText(o[k])!==normText(match[k])){changes.push(`${l}: ${match[k]||'(없음)'} → ${o[k]}`);match[k]=o[k]}}
   if(changes.length)updated.push(o.name+' — '+changes.join(', '));else skipped.push(o.name);
  }
  if(!confirm(`기관 명단 검사 결과\n신규 등록 ${added.length}곳 / 정보 업데이트 ${updated.length}곳 / 완전 중복(건너뜀) ${skipped.length}곳 / 확인 필요 ${review.length}건\n\n[업데이트 내용]\n${updated.slice(0,20).join('\n')||'없음'}\n\n[확인 필요]\n${review.slice(0,20).join('\n')||'없음'}\n\n기관명+대표전화가 같으면 같은 기관으로 봅니다. 엑셀 빈 칸은 기존 값을 지우지 않습니다. 반영 전 자동 백업됩니다. 진행할까요?`))return;
  try{await serverBackup(await encryptedPayload(),'기관 엑셀 가져오기 전 자동백업')}catch(err){alert('자동 백업에 실패해 가져오기를 중단했습니다: '+err.message);return}
  const old=institutions;institutions=working;try{await save()}catch(err){institutions=old;throw err}
  renderInstitutions();
  if(review.length)downloadCSV([['확인 필요 내용'],...review.map(x=>[x])],'기관_가져오기_확인필요.csv');
  alert(`가져오기 완료\n신규 ${added.length}곳 / 업데이트 ${updated.length}곳 / 건너뜀 ${skipped.length}곳 / 확인 필요 ${review.length}건`);
 }catch(err){alert('기관 가져오기 실패: '+err.message)}finally{e.target.value=''}
};
$('instPostcodeSearch').onclick=async()=>{const btn=$('instPostcodeSearch');btn.disabled=true;try{await loadPostcode();const Postcode=window.kakao?.Postcode||window.daum?.Postcode;new Postcode({oncomplete:d=>{$('if_postcode').value=d.zonecode||'';$('if_address').value=d.userSelectedType==='J'?(d.jibunAddress||d.address):(d.roadAddress||d.address);if(d.hname)$('if_district').value=String(d.hname).trim();$('if_detail').focus()}}).open()}catch(err){alert(err.message+'\n주소는 직접 입력할 수도 있습니다.')}finally{btn.disabled=false}};
window.renderInstitutions=renderInstitutions;
// ===== v0.4.12: 익명 번호 관리 =====
// 이름 없이 번호만 등록. 주소록·당원·후원인에 같은 번호가 있으면 그 사람으로 바꿔(치환) 보여 줍니다.
let editingAnon=null,anonFilter='all';
function anonMatch(phone){
 const d=normPhone(phone);if(!d)return null;
 const c=data.find(x=>normPhone(x.phone)===d||normPhone(x.landline)===d);
 if(c)return {kind:'주소록',name:c.name,contactId:c.id,detail:[c.district,affiliations(c).map(a=>a.group).filter(Boolean).join(', ')].filter(Boolean).join(' · ')};
 const m=members.find(x=>normPhone(x.mobilePhone)===d||normPhone(x.homePhone)===d);
 if(m)return {kind:'당원',name:m.memberName||memberContact(m)?.name||'(이름 없음)',contactId:m.contactId||null,detail:[m.memberNo,m.adminDong].filter(Boolean).join(' · ')};
 const o=donors.find(x=>normPhone(x.phone)===d);
 if(o)return {kind:'후원인',name:o.name||'(이름 없음)',contactId:o.contactId||null,detail:(o.donations||[]).length?'후원 '+(o.donations||[]).length+'회':''};
 return null;
}
function anonPhone(v){return formatPhone(v)}
// 익명 번호가 주소록·당원·후원인에 있는 번호가 되면 익명 기록은 지우고, 메모는 그 사람 쪽 메모에 붙여 정보가 사라지지 않게 합니다.
function anonTarget(phone){
 const d=normPhone(phone);if(!d)return null;
 const c=data.find(x=>normPhone(x.phone)===d||normPhone(x.landline)===d);if(c)return {kind:'주소록',name:c.name,obj:c,key:'memo',max:3000};
 const m=members.find(x=>normPhone(x.mobilePhone)===d||normPhone(x.homePhone)===d);if(m)return {kind:'당원',name:m.memberName||memberContact(m)?.name||'(이름 없음)',obj:m,key:'note',max:5000};
 const o=donors.find(x=>normPhone(x.phone)===d);if(o)return {kind:'후원인',name:o.name||'(이름 없음)',obj:o,key:'memo',max:5000};
 return null;
}
let lastAbsorbed=[];
function absorbAnonymous(){
 lastAbsorbed=[];if(!Array.isArray(anonymous)||!anonymous.length)return lastAbsorbed;
 const keep=[];
 for(const a of anonymous){
  const t=anonTarget(a.phone);if(!t){keep.push(a);continue}
  const info=[a.source,a.district,a.memo].map(v=>String(v||'').trim()).filter(Boolean);
  const cur=String(t.obj[t.key]||'');
  if(info.length&&!(a.memo&&cur.includes(String(a.memo).trim()))){
   const line=`[익명 번호 기록${a.date?' '+a.date:''}] ${info.join(' / ')}`;const next=cur?cur+'\n'+line:line;
   if(next.length>t.max){keep.push(a);continue}
   t.obj[t.key]=next;
  }
  lastAbsorbed.push({phone:a.phone,name:t.name,kind:t.kind});
 }
 anonymous=keep;return lastAbsorbed;
}
function renderAnonymous(){
 const q=($('anonSearch').value||'').trim().toLowerCase(),qd=q.replace(/\D/g,'');
 const all=anonymous.map(a=>({a,m:anonMatch(a.phone)}));
 const matched=all.filter(x=>x.m).length;
 const rows=all.filter(({a,m})=>(anonFilter==='all'||(anonFilter==='anon'&&!m)||(anonFilter==='matched'&&m))&&(!q||(qd&&normPhone(a.phone).includes(qd))||[a.memo,a.source,a.district,m?.name].join(' ').toLowerCase().includes(q)))
  .sort((x,y)=>String(y.a.date||'').localeCompare(String(x.a.date||'')));
 $('anonCount').textContent=`익명 ${anonymous.length}건`;
 $('anonRows').innerHTML=rows.map(({a,m})=>`<tr><td style="white-space:nowrap"><strong>${esc(a.phone)}</strong></td><td>${m?`<b>${esc(m.name)}</b> <span class="tag" style="padding:2px 7px">${esc(m.kind)}</span>${m.detail?'<div class="mini">'+esc(m.detail)+'</div>':''}`:'<span class="muted">익명</span>'}</td><td>${esc(a.source||'')}</td><td>${esc(a.district||'')}</td><td>${esc(a.memo||'')}</td><td style="white-space:nowrap">${esc(a.date||'')}</td><td style="white-space:nowrap">${m?.contactId&&data.some(c=>c.id===m.contactId)?`<button data-an-profile="${esc(m.contactId)}">통합정보</button> `:''}${!m?`<button data-an-new="${esc(a.id)}">연락처로 등록</button> `:''}<button data-an-edit="${esc(a.id)}">수정</button> <button class="danger" data-an-del="${esc(a.id)}">삭제</button></td></tr>`).join('')||'<tr><td colspan="7">등록된 번호가 없습니다.</td></tr>';
 document.querySelectorAll('[data-anon-filter]').forEach(b=>{const on=b.dataset.anonFilter===anonFilter;b.classList.toggle('primary',on);b.setAttribute('aria-pressed',String(on))});
}
function openAnon(a){
 editingAnon=a?.id||null;$('an_phone').value=a?.phone||'';$('an_source').value=a?.source||'';$('an_district').value=a?.district||'';$('an_memo').value=a?.memo||'';$('an_date').value=a?.date||new Date().toISOString().slice(0,10);
 $('anonEditorTitle').textContent=a?'익명 번호 수정':'익명 번호 등록';$('anonHint').textContent='';
 $('anonEditor').classList.remove('hidden');$('an_phone').focus();
}
$('an_phone').addEventListener('input',()=>{const m=anonMatch($('an_phone').value);$('anonHint').innerHTML=m?`이 번호는 <b>${esc(m.name)}</b>(${esc(m.kind)})님의 번호입니다. 저장하면 익명 목록에는 남기지 않고, 메모는 그분 정보의 메모에 붙여 둡니다.`:''});
$('anonNew').onclick=()=>openAnon(null);
$('anonCancel').onclick=()=>{$('anonEditor').classList.add('hidden');editingAnon=null};
$('anonForm').onsubmit=async e=>{
 e.preventDefault();
 let phone;try{phone=anonPhone($('an_phone').value)}catch(err){alert(err.message);return}
 if(!phone){alert('전화번호를 입력하세요.');return}
 const dup=anonymous.find(x=>x.id!==editingAnon&&normPhone(x.phone)===normPhone(phone));
 if(dup){alert(`이미 등록된 번호입니다 (${dup.date||''} ${dup.memo||''}). 기존 항목을 수정해 주세요.`);return}
 const prev=anonymous.find(x=>x.id===editingAnon);
 const o={...(prev||{}),id:editingAnon||uid(),phone,source:$('an_source').value.trim(),district:$('an_district').value.trim(),memo:$('an_memo').value.trim(),date:$('an_date').value||new Date().toISOString().slice(0,10)};
 const old=structuredClone(anonymous);const i=anonymous.findIndex(x=>x.id===o.id);if(i>=0)anonymous[i]=o;else anonymous.push(o);
 try{await save()}catch(err){anonymous=old;alert('저장 실패: '+err.message);return}
 const ab=lastAbsorbed.find(x=>normPhone(x.phone)===normPhone(phone));
 $('anonEditor').classList.add('hidden');editingAnon=null;renderAnonymous();
 if(ab)alert(`이 번호는 ${ab.kind}에 등록된 '${ab.name}'님 번호라 익명 목록에는 남기지 않았습니다. 입력한 메모는 그분 메모에 붙여 두었습니다.`);
};
$('anonRows').onclick=async e=>{
 const b=e.target.closest('button');if(!b)return;
 if(b.dataset.anProfile){$('navContacts').click();showFullProfile(b.dataset.anProfile,'basic');return}
 const id=b.dataset.anEdit||b.dataset.anDel||b.dataset.anNew,a=anonymous.find(x=>x.id===id);if(!a)return;
 if(b.dataset.anEdit)openAnon(a);
 if(b.dataset.anNew){$('navContacts').click();open(null);$('phone').value=a.phone;$('district').value=a.district||'';$('memo').value=a.memo||'';$('name').focus();alert('이름을 입력해 저장하면 익명 목록에서 이 번호가 그 이름으로 표시됩니다.')}
 if(b.dataset.anDel&&confirm(`${a.phone} 번호를 익명 목록에서 삭제할까요?\n주소록·당원·후원인 정보는 삭제되지 않습니다.`)){const old=anonymous;anonymous=anonymous.filter(x=>x.id!==id);try{await save()}catch(err){anonymous=old;alert('삭제 실패: '+err.message)}renderAnonymous()}
};
$('anonSearch').oninput=renderAnonymous;
$('anonFilters').onclick=e=>{const b=e.target.closest('[data-anon-filter]');if(!b)return;anonFilter=b.dataset.anonFilter;renderAnonymous()};
$('anonExport').onclick=()=>downloadXlsxRows([['전화번호','확인된 이름','구분','경로','행정동','메모','등록일'],...anonymous.map(a=>{const m=anonMatch(a.phone);return [a.phone,m?.name||'',m?.kind||'익명',a.source||'',a.district||'',a.memo||'',a.date||'']})],'익명번호_목록.xlsx');
$('anonTemplate').onclick=()=>downloadXlsxRows([['전화번호','경로','행정동','메모','등록일']],'익명번호_입력양식.xlsx');
$('anonImport').onchange=async e=>{
 const file=e.target.files?.[0];if(!file)return;
 try{
  if(file.size>15e6)throw Error('15MB 이하 파일만 지원합니다.');
  const rows=/\.xlsx$/i.test(file.name)?await parseXlsx(file):/\.csv$/i.test(file.name)?parseCSV(await file.text()):null;
  if(!rows||rows.length<2)throw Error('제목 행과 데이터 행이 있는 CSV 또는 XLSX 파일이 필요합니다.');
  const h=rows[0].map(cleanHeader),col=al=>h.findIndex(x=>al.some(a=>cleanHeader(a)===x));
  const pi=col(['전화번호','휴대전화','휴대폰','연락처','번호','phone']),si=col(['경로','출처','구분']),di=col(['행정동','동']),mi=col(['메모','비고','내용']),ti=col(['등록일','날짜','일자']);
  if(pi<0)throw Error('제목 행에 전화번호 열이 필요합니다.');
  const working=structuredClone(anonymous),seen=new Set(working.map(a=>normPhone(a.phone)));let added=0,skipped=0,named=0;const review=[];
  for(let r=1;r<rows.length;r++){const row=rows[r];if(!row.some(v=>String(v??'').trim()))continue;
   const line=r+(rows.headerRow||1);let phone;try{phone=anonPhone(String(row[pi]??''))}catch(err){review.push(`엑셀 ${line}행: ${err.message}`);continue}
   if(!phone){review.push(`엑셀 ${line}행: 전화번호 없음`);continue}
   if(seen.has(normPhone(phone))){skipped++;continue}
   seen.add(normPhone(phone));if(anonMatch(phone))named++;
   const dt=ti<0?'':String(row[ti]??'').trim();
   working.push({id:uid(),phone,source:si<0?'':String(row[si]??'').trim(),district:di<0?'':String(row[di]??'').trim(),memo:mi<0?'':String(row[mi]??'').trim(),date:/^\d{4}-\d{2}-\d{2}$/.test(dt)?dt:/^\d{5}$/.test(dt)?excelDate(dt):new Date().toISOString().slice(0,10)});added++}
  if(!confirm(`익명 번호 검사 결과\n익명 신규 ${added-named}건 / 주소록·당원·후원인에 이미 있는 번호 ${named}건 (익명으로 남기지 않고 메모만 그 사람에게 붙임) / 이미 있는 번호 건너뜀 ${skipped}건 / 확인 필요 ${review.length}건\n\n${review.slice(0,20).join('\n')||''}\n\n반영할까요?`))return;
  const old=anonymous;anonymous=working;try{await save()}catch(err){anonymous=old;throw err}
  renderAnonymous();if(review.length)downloadCSV([['확인 필요 내용'],...review.map(x=>[x])],'익명번호_가져오기_확인필요.csv');
  alert(`가져오기 완료: 익명 신규 ${added-named}건 / 기존 사람 번호 ${named}건 / 건너뜀 ${skipped}건 / 확인 필요 ${review.length}건`);
 }catch(err){alert('익명 번호 가져오기 실패: '+err.message)}finally{e.target.value=''}
};
window.renderAnonymous=renderAnonymous;
// v0.4.21: 후원인 소속 단체·직책 (주소록과 같은 방식: 단체+직책 한 쌍씩 여러 개)
let donorAffs=[];
function donorAffsDraw(){$('donorAffs').innerHTML=donorAffs.map((a,i)=>`<span class="tag">${esc(a.group)}${a.role?' · '+esc(a.role):''} <button type="button" data-daff-rm="${i}" aria-label="삭제" style="padding:0 6px">×</button></span>`).join('')}
function donorAffsSet(list){donorAffs=(list||[]).map(a=>({group:String(a.group||''),role:String(a.role||'')})).filter(a=>a.group);donorAffsDraw()}
function donorAffAdd(){const g=$('donorGroup').value.trim(),r=$('donorRole').value.trim();if(!g){if(r){alert('소속 단체명을 입력하세요.');return false}return true}if(!donorAffs.some(a=>a.group===g&&a.role===r))donorAffs.push({group:g,role:r});$('donorGroup').value='';$('donorRole').value='';donorAffsDraw();return true}
function donorAffsRead(){donorAffAdd();return donorAffs.map(a=>({...a}))}
function donorAffCols(d){const a=d.affiliations||[];return [a.map(x=>x.group).join('; '),a.map(x=>x.role).join('; ')]}
function donorAffParse(g,r){const gs=String(g||'').split(/[;、\n]/).map(x=>x.trim()),rs=String(r||'').split(/[;、\n]/).map(x=>x.trim());return gs.map((group,i)=>({group,role:rs[i]||''})).filter(a=>a.group)}
$('donorAddAff').onclick=donorAffAdd;
$('donorAffs').onclick=e=>{const b=e.target.closest('[data-daff-rm]');if(!b)return;donorAffs.splice(Number(b.dataset.daffRm),1);donorAffsDraw()};
// v0.4.18: 후원인 집주소·직장주소 우편번호 검색
function donorPostcode(btnId,pcId,addrId){$(btnId).onclick=async()=>{const btn=$(btnId);btn.disabled=true;try{await loadPostcode();const Postcode=window.kakao?.Postcode||window.daum?.Postcode;new Postcode({oncomplete:d=>{$(pcId).value=d.zonecode||'';$(addrId).value=(d.userSelectedType==='J'?(d.jibunAddress||d.address):(d.roadAddress||d.address))+' ';$(addrId).focus()}}).open()}catch(err){alert(err.message+'\n주소는 직접 입력할 수도 있습니다.')}finally{btn.disabled=false}}}
donorPostcode('donorPostcodeSearch','donorPostcode','donorAddress');donorPostcode('donorWorkPostcodeSearch','donorWorkPostcode','donorWorkAddress');
// v0.4.15: 팝업 수정 창은 Esc 키로 닫기, 열릴 때 창 맨 위부터 보이게
document.addEventListener('keydown',e=>{if(e.key!=='Escape'||document.querySelector('dialog[open]'))return;for(const [ed,btn] of [['orgMemberEditor','omCancel'],['memberEditor','memberCancel'],['orgEditor','orgCancel'],['donorEditor','donorCancel'],['instEditor','instCancel']]){if(!$(ed)?.classList.contains('hidden')){$(btn)?.click();break}}});
{const POP=['memberEditor','orgEditor','donorEditor','instEditor','orgMemberEditor'];const bd=document.createElement('div');bd.id='editorBackdrop';bd.className='hidden';bd.title='닫기 버튼이나 Esc 키로 창을 닫으세요';document.body.appendChild(bd);
 const sync=()=>{const open=POP.map(id=>$(id)).find(el=>el&&!el.classList.contains('hidden'));bd.classList.toggle('hidden',!open);
  // 통합정보에서 수정 중일 때 '돌아가기' 줄은 팝업 창 맨 위로 옮겨 보이게 함
  const bar=$('returnBar');if(bar){if(open&&bar.parentNode!==open)open.prepend(bar);else if(!open&&bar.parentNode!==$('vaultContent'))$('vaultContent').prepend(bar)}};
 window.__popupSync=sync;
 for(const ed of POP){const el=$(ed);if(el)new MutationObserver(()=>{if(!el.classList.contains('hidden'))el.scrollTop=0;sync()}).observe(el,{attributes:true,attributeFilter:['class']})}
 // 다른 메뉴로 이동하거나 잠글 때는 팝업 창도 닫힘
 document.addEventListener('click',e=>{if(e.target.closest('#navContacts,#navEvents,#navMembers,#navDonors,#navInstitutions,#navAnonymous,#vaultLock,#returnToProfile'))POP.forEach(id=>$(id)?.classList.add('hidden'))},true)}


})();
