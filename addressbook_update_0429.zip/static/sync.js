(async function(){
 // v0.4.24: 브라우저 저장공간(localStorage, 약 5MB) 대신 주소록 엔진(서버)에 직접 저장합니다.
 const KEY='district-addressbook-demo-encrypted-v10';
 const status=()=>document.getElementById('sync-status');
 let cache=null,chain=Promise.resolve(),busy=0;
 // v0.4.26: 로그인 남은 시간 표시·연장 버튼, 로그인이 풀리면 이 화면에서 바로 다시 로그인 (작성 중인 내용은 저장 대기)
 let expiresAt=0,reloginWait=null;
 function seen(r){const v=Number(r.headers.get('X-Session-Remaining'));if(v>0){expiresAt=Date.now()+v*1000;drawTimer()}}
 function timerBox(){let b=document.getElementById('sessionTimer');if(!b){b=document.createElement('div');b.id='sessionTimer';b.style.cssText='position:fixed;top:8px;right:104px;z-index:9999;display:flex;gap:6px;align-items:center;background:#fff;border:1px solid #cbd5e1;border-radius:8px;padding:4px 8px;font:12px system-ui;color:#0f172a';b.innerHTML='<span id="sessionLeft"></span><button type="button" id="sessionExtend" style="padding:3px 8px;font-size:12px">연장</button>';document.body.appendChild(b);b.querySelector('#sessionExtend').onclick=()=>ping(true)}return b}
 function drawTimer(){timerBox();const el=document.getElementById('sessionLeft');const ms=expiresAt-Date.now();if(!expiresAt){el.textContent='🔐 로그인 확인 중';return}if(ms<=0){el.textContent='🔒 로그인 만료됨';el.style.color='#dc2626';return}const m=Math.floor(ms/60000),h=Math.floor(m/60);el.textContent='🔐 로그인 '+(h?h+'시간 ':'')+(m%60)+'분 남음';el.style.color=ms<30*60000?'#dc2626':'#0f172a'}
 function reloginBox(){let b=document.getElementById('reloginBox');if(b)return b;b=document.createElement('div');b.id='reloginBox';b.style.cssText='position:fixed;inset:0;background:rgba(15,23,42,.6);z-index:10000;display:flex;align-items:center;justify-content:center';b.innerHTML='<form id="reloginForm" style="background:#fff;padding:24px;border-radius:14px;width:min(420px,92vw);font:15px system-ui"><h3 style="margin:0 0 8px">로그인이 풀렸습니다</h3><p style="margin:0 0 12px;color:#334155">처음 로그인할 때 쓰는 관리자 비밀번호를 다시 입력해 주세요. <b>작성 중인 내용은 지워지지 않고</b>, 다시 로그인하면 바로 저장됩니다. 이 창을 새로고침하거나 닫지 마세요.</p><input id="reloginPw" type="password" autocomplete="current-password" placeholder="관리자 비밀번호" style="width:100%;box-sizing:border-box;padding:10px;margin-bottom:8px"><div id="reloginMsg" style="color:#dc2626;min-height:20px;font-size:13px"></div><button type="submit" id="reloginBtn" style="width:100%;padding:10px;background:#173b75;color:#fff;border:0;border-radius:8px">다시 로그인</button></form>';document.body.appendChild(b);
  b.querySelector('#reloginForm').onsubmit=async e=>{e.preventDefault();const msg=b.querySelector('#reloginMsg');msg.textContent='확인 중...';try{const r=await fetch('/api/relogin',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:b.querySelector('#reloginPw').value}),credentials:'same-origin'});const j=await r.json().catch(()=>({}));if(!r.ok||!j.ok){msg.textContent=j.error||('다시 로그인 실패 '+r.status);return}window.APP_CSRF=j.csrf;document.querySelectorAll('#logout-form input[name=csrf]').forEach(i=>i.value=j.csrf);seen(r);b.remove();const w=reloginWait;reloginWait=null;if(w)w.resolve()}catch(err){msg.textContent='주소록 엔진(검은 창)이 꺼져 있는지 확인하세요: '+err.message}};
  setTimeout(()=>b.querySelector('#reloginPw').focus(),0);return b}
 function needLogin(){expiresAt=-1;drawTimer();if(!reloginWait){let res;const pr=new Promise(r=>res=r);reloginWait={promise:pr,resolve:res}}reloginBox();if(status())status().textContent='로그인이 풀렸습니다. 다시 로그인하면 저장됩니다.';return reloginWait.promise}
 async function ping(manual){try{const r=await fetch('/api/ping',{credentials:'same-origin',cache:'no-store'});if(r.status===401){needLogin();return}seen(r);if(manual&&status())status().textContent='로그인 연장됨 (12시간)'}catch(e){if(manual)alert('주소록 엔진에 연결할 수 없습니다. 검은 창이 켜져 있는지 확인하세요.')}}
 window.sessionPing=ping;
 async function put(value){
   for(;;){
     const response=await fetch('/api/data',{method:'PUT',headers:{'Content-Type':'application/json','X-CSRF-Token':window.APP_CSRF},body:JSON.stringify({payload:value}),credentials:'same-origin'});
     if(response.status===401||response.status===403&&expiresAt<0){await needLogin();continue}
     if(!response.ok) throw Error(response.status===413||response.status===400?'데이터가 너무 큽니다 ('+response.status+')':'서버 저장 실패 '+response.status);
     seen(response);return;
   }
 }
 window.vaultStore={
   get(){return cache},
   set(value){
     cache=String(value);const snapshot=cache;busy++;
     if(status())status().textContent='저장 중...';
     const p=chain.then(()=>put(snapshot));
     chain=p.catch(()=>{});
     return p.then(()=>{if(status())status().textContent='서버 저장 완료'},e=>{if(status())status().textContent='저장 오류: '+e.message;throw e}).finally(()=>{busy--});
   },
   pending(){return busy>0}
 };
 // v0.4.25: 창을 열어 두는 동안 로그인이 풀리지 않도록 10분마다 서버에 신호를 보냅니다.
 setInterval(()=>ping(false),10*60*1000);setInterval(()=>{drawTimer();if(expiresAt>0&&Date.now()>expiresAt)ping(false)},30*1000);
 // 절전·화면 전환 뒤 돌아오면 바로 로그인 상태 확인
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')ping(false)});window.addEventListener('focus',()=>ping(false));
 window.addEventListener('beforeunload',e=>{if(busy>0){e.preventDefault();e.returnValue='저장 중입니다.'}});
 try{
   const r=await fetch('/api/data',{credentials:'same-origin'});if(!r.ok)throw Error('로그인이 만료됐습니다');seen(r);
   const data=await r.json();
   let local=null;try{local=localStorage.getItem(KEY)}catch(e){}
   if(data.payload!==null){cache=data.payload}
   // 처음 한 번: 서버에 데이터가 없고 이 브라우저에만 있으면 서버로 옮깁니다.
   else if(local){await put(local);cache=local}
   // 서버에 안전하게 있으므로 브라우저 저장공간의 옛 사본은 지워 공간을 비웁니다.
   if(local&&cache!==null){try{localStorage.removeItem(KEY)}catch(e){}}
   const s=document.createElement('script');s.src='/static/app.js?v=0.4.29';s.onload=()=>{if(window.APP_JS_VERSION!==window.APP_EXPECTED_VERSION)document.getElementById('versionWarn')?.classList.remove('hidden')};s.onerror=()=>document.getElementById('versionWarn')?.classList.remove('hidden');document.body.appendChild(s);
   if(status())status().textContent='서버 연결됨';
 }catch(e){if(status())status().textContent='연결 오류: '+e.message;alert('주소록 서버 연결에 실패했습니다. 데이터를 수정하지 마세요. '+e.message)}
})();
