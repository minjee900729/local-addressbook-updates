(async function(){
 // v0.4.14: 브라우저 저장공간(localStorage, 약 5MB) 대신 주소록 엔진(서버)에 직접 저장합니다.
 const KEY='district-addressbook-demo-encrypted-v10';
 const status=()=>document.getElementById('sync-status');
 let cache=null,chain=Promise.resolve(),busy=0;
 async function put(value){
   const response=await fetch('/api/data',{method:'PUT',headers:{'Content-Type':'application/json','X-CSRF-Token':window.APP_CSRF},body:JSON.stringify({payload:value}),credentials:'same-origin'});
   if(!response.ok) throw Error(response.status===401?'로그인이 만료됐습니다. 다시 로그인해 주세요.':response.status===413||response.status===400?'데이터가 너무 큽니다 ('+response.status+')':'서버 저장 실패 '+response.status);
 }
 window.vaultStore={
   get(){return cache},
   set(value){
     cache=String(value);const snapshot=cache;busy++;
     if(status())status().textContent='저장 중...';
     const p=chain.then(()=>put(snapshot));
     chain=p.catch(()=>{});
     return p.then(()=>{if(status())status().textContent='서버 저장 완료'},e=>{if(status())status().textContent='저장 오류: '+e.message;throw e}).finally(()=>{busy--});
   },
   pending(){return busy>0}
 };
 window.addEventListener('beforeunload',e=>{if(busy>0){e.preventDefault();e.returnValue='저장 중입니다.'}});
 try{
   const r=await fetch('/api/data',{credentials:'same-origin'});if(!r.ok)throw Error('로그인이 만료됐습니다');
   const data=await r.json();
   let local=null;try{local=localStorage.getItem(KEY)}catch(e){}
   if(data.payload!==null){cache=data.payload}
   // 처음 한 번: 서버에 데이터가 없고 이 브라우저에만 있으면 서버로 옮깁니다.
   else if(local){await put(local);cache=local}
   // 서버에 안전하게 있으므로 브라우저 저장공간의 옛 사본은 지워 공간을 비웁니다.
   if(local&&cache!==null){try{localStorage.removeItem(KEY)}catch(e){}}
   const s=document.createElement('script');s.src='/static/app.js?v=0.4.14';s.onload=()=>{if(window.APP_JS_VERSION!==window.APP_EXPECTED_VERSION)document.getElementById('versionWarn')?.classList.remove('hidden')};s.onerror=()=>document.getElementById('versionWarn')?.classList.remove('hidden');document.body.appendChild(s);
   if(status())status().textContent='서버 연결됨';
 }catch(e){if(status())status().textContent='연결 오류: '+e.message;alert('주소록 서버 연결에 실패했습니다. 데이터를 수정하지 마세요. '+e.message)}
})();
