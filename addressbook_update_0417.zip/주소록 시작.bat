@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
 set "PYTHON=py -3"
) else (
 where python >nul 2>nul
 if errorlevel 1 (
  echo Python 3 is required. Install Python from https://www.python.org/downloads/windows/
  echo During setup check "Add python.exe to PATH".
  pause
  exit /b 1
 )
 set "PYTHON=python"
)
if not exist ".venv\Scripts\python.exe" (
 echo Creating local Python environment...
 %PYTHON% -m venv .venv
 if errorlevel 1 goto failed
)
".venv\Scripts\python.exe" -c "import flask" >nul 2>nul
if errorlevel 1 (
 echo Installing dependencies. Internet is needed for first setup.
 ".venv\Scripts\python.exe" -m pip install -r requirements.txt
 if errorlevel 1 goto failed
)
".venv\Scripts\python.exe" updater.py
".venv\Scripts\python.exe" local_start.py
if errorlevel 1 goto failed
exit /b 0
:failed
echo An error occurred. Check README.md.
pause
exit /b 1
