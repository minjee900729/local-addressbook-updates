import os, sqlite3, hmac, hashlib, secrets, time, json, urllib.parse, urllib.request, re, threading
from pathlib import Path
from flask import Flask, request, session, redirect, render_template, jsonify, abort
from werkzeug.security import generate_password_hash, check_password_hash

ROOT=Path(__file__).parent
DB=Path(os.environ.get('DB_PATH',str(ROOT/'addressbook.sqlite3')))
app=Flask(__name__,template_folder='templates',static_folder='static')
app.secret_key=os.environ.get('SECRET_KEY','')
if len(app.secret_key)<32: raise RuntimeError('SECRET_KEY 환경변수를 32자 이상으로 설정하세요')
app.config.update(TEMPLATES_AUTO_RELOAD=True,SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SECURE=os.environ.get('LOCAL_HTTP')!='1',SESSION_COOKIE_SAMESITE='Strict',MAX_CONTENT_LENGTH=300*1024*1024,PERMANENT_SESSION_LIFETIME=3600)
ADMIN=os.environ.get('ADMIN_PASSWORD','')
if len(ADMIN)<12: raise RuntimeError('ADMIN_PASSWORD 환경변수를 12자 이상으로 설정하세요')
# password verifier created once; changing ADMIN_PASSWORD after initial setup does not change it
DB.parent.mkdir(parents=True,exist_ok=True)
with sqlite3.connect(DB) as c:
 c.execute('CREATE TABLE IF NOT EXISTS config (k TEXT PRIMARY KEY,v TEXT NOT NULL)')
 c.execute('CREATE TABLE IF NOT EXISTS data (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL, updated INTEGER NOT NULL)')
 # v0.4.3: encrypted snapshots taken automatically before deletions/restores (payload stays client-side encrypted)
 c.execute('CREATE TABLE IF NOT EXISTS backups (id INTEGER PRIMARY KEY AUTOINCREMENT, created INTEGER NOT NULL, reason TEXT NOT NULL, payload TEXT NOT NULL)')
 if not c.execute("SELECT v FROM config WHERE k='password_hash'").fetchone():
  c.execute('INSERT INTO config VALUES (?,?)',('password_hash',generate_password_hash(ADMIN)))

def auth(): return bool(session.get('authenticated'))
def csrf(): return session.get('csrf') and hmac.compare_digest(request.headers.get('X-CSRF-Token',''),session['csrf'])
@app.after_request
def headers(resp):
 resp.headers['X-Content-Type-Options']='nosniff';resp.headers['X-Frame-Options']='DENY';resp.headers['Referrer-Policy']='no-referrer';resp.headers['Cache-Control']='no-store'
 resp.headers['Content-Security-Policy']="default-src 'self'; script-src 'self' 'unsafe-inline' https://t1.daumcdn.net https://postcode.map.daum.net; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self' https://postcode.map.daum.net; frame-src https://postcode.map.daum.net https://postcode.map.kakao.com; object-src 'none'; base-uri 'self'; form-action 'self'"
 return resp
@app.route('/login',methods=['GET','POST'])
def login():
 if request.method=='POST':
  with sqlite3.connect(DB) as c: verifier=c.execute("SELECT v FROM config WHERE k='password_hash'").fetchone()[0]
  if check_password_hash(verifier,request.form.get('password','')):
   session.clear();session['authenticated']=True;session['csrf']=secrets.token_urlsafe(32);session.permanent=True;return redirect('/')
  time.sleep(0.5)
  return render_template('login.html',error='비밀번호를 확인하세요'),401
 return render_template('login.html',error=None)
@app.route('/logout',methods=['POST'])
def logout():
 if not auth() or not (csrf() or hmac.compare_digest(request.form.get('csrf',''),session.get('csrf',''))):abort(403)
 session.clear();return redirect('/login')
@app.route('/')
def home():
 if not auth():return redirect('/login')
 return render_template('app.html',csrf=session['csrf'])
# v0.4.14: 수만 명 규모 데이터 저장을 위해 한도 상향(데이터는 압축·암호화되어 전송됨)
PAYLOAD_MAX=250_000_000
@app.route('/api/data',methods=['GET','PUT'])
def data():
 if not auth():abort(401)
 if request.method=='GET':
  with sqlite3.connect(DB) as c: row=c.execute('SELECT payload,updated FROM data WHERE id=1').fetchone()
  return jsonify({'payload':row[0] if row else None,'updated':row[1] if row else None})
 if not csrf():abort(403)
 j=request.get_json(silent=True)
 if not isinstance(j,dict) or not isinstance(j.get('payload'),str) or len(j['payload'])>PAYLOAD_MAX:abort(400)
 with sqlite3.connect(DB) as c:
  c.execute('INSERT INTO data (id,payload,updated) VALUES (1,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,updated=excluded.updated',(j['payload'],int(time.time())))
 return jsonify({'ok':True})
try:APP_VERSION=json.loads((ROOT/'version.json').read_text(encoding='utf-8'))['version']
except Exception:APP_VERSION=''
@app.route('/health')
def health():return jsonify({'ok':True,'version':APP_VERSION})
def shutdown_token():return hmac.new(app.secret_key.encode(),b'local-shutdown',hashlib.sha256).hexdigest()
@app.route('/api/local-shutdown',methods=['POST'])
def local_shutdown():
 # 업데이트 후 새 버전 실행 시 이전 엔진을 끄기 위한 로컬 전용 요청(설정 파일의 비밀값으로 서명)
 if request.remote_addr not in ('127.0.0.1','::1'):abort(403)
 if not hmac.compare_digest(request.headers.get('X-Shutdown-Token',''),shutdown_token()):abort(403)
 threading.Timer(0.5,lambda:os._exit(0)).start()
 return jsonify({'ok':True})

BACKUP_KEEP=30
@app.route('/api/backups',methods=['GET','POST'])
def backups():
 if not auth():abort(401)
 if request.method=='GET':
  with sqlite3.connect(DB) as c: rows=c.execute('SELECT id,created,reason,length(payload) FROM backups ORDER BY id DESC').fetchall()
  return jsonify({'backups':[{'id':r[0],'created':r[1],'reason':r[2],'size':r[3]} for r in rows]})
 if not csrf():abort(403)
 j=request.get_json(silent=True)
 if not isinstance(j,dict) or not isinstance(j.get('payload'),str) or len(j['payload'])>PAYLOAD_MAX:abort(400)
 try:
  obj=json.loads(j['payload'])
  if obj.get('format') not in ('district-addressbook-encrypted-v10','district-addressbook-encrypted-v11'):abort(400)
 except (ValueError,AttributeError):abort(400)
 reason=str(j.get('reason',''))[:200] or '수동 백업'
 with sqlite3.connect(DB) as c:
  cur=c.execute('INSERT INTO backups (created,reason,payload) VALUES (?,?,?)',(int(time.time()),reason,j['payload']))
  bid=cur.lastrowid
  c.execute('DELETE FROM backups WHERE id NOT IN (SELECT id FROM backups ORDER BY id DESC LIMIT ?)',(BACKUP_KEEP,))
 return jsonify({'ok':True,'id':bid})
@app.route('/api/backups/<int:bid>')
def backup_get(bid):
 if not auth():abort(401)
 with sqlite3.connect(DB) as c: row=c.execute('SELECT payload,created,reason FROM backups WHERE id=?',(bid,)).fetchone()
 if not row:abort(404)
 return jsonify({'payload':row[0],'created':row[1],'reason':row[2]})

@app.route('/api/postcode-lookup',methods=['POST'])
def postcode_lookup():
 if not auth():abort(401)
 if not csrf():abort(403)
 j=request.get_json(silent=True) or {}
 key=str(j.get('api_key','')).strip(); address=str(j.get('address','')).strip()
 if not re.fullmatch(r'[A-Za-z0-9]{10,80}',key) or not (4<=len(address)<=180):return jsonify({'status':'invalid','message':'승인키 또는 주소를 확인하세요.'}),400
 params=urllib.parse.urlencode({'confmKey':key,'currentPage':'1','countPerPage':'5','keyword':address,'resultType':'json'})
 try:
  req=urllib.request.Request('https://business.juso.go.kr/addrlink/addrLinkApi.do?'+params,headers={'User-Agent':'LocalAddressbook/0.4.3'})
  with urllib.request.urlopen(req,timeout=10) as response: data=json.load(response)
  result=data.get('results',{}); common=result.get('common',{}); matches=result.get('juso',[]) or []
  if str(common.get('errorCode'))!='0':return jsonify({'status':'error','message':str(common.get('errorMessage','주소 검색 오류'))[:150]})
  def norm(t):return re.sub(r'\s+','',str(t or '').replace('경기도','경기').replace('서울특별시','서울').replace('인천광역시','인천'))
  # Only fill when exactly one uniquely matching official address; no guessed ZIP codes.
  matched=[x for x in matches if norm(address) in (norm(x.get('roadAddrPart1')),norm(x.get('jibunAddr')),norm(x.get('roadAddr')))]
  codes={str(x.get('zipNo','')) for x in matched if re.fullmatch(r'\d{5}',str(x.get('zipNo','')))}
  if len(matched)==1 and len(codes)==1:return jsonify({'status':'matched','postcode':next(iter(codes)),'official_address':matched[0].get('roadAddrPart1','')})
  return jsonify({'status':'review','message':'정확한 주소 1건으로 확인되지 않아 자동 입력하지 않았습니다.','count':len(matches)})
 except Exception:
  return jsonify({'status':'error','message':'주소 검색 서비스에 연결하지 못했습니다.'})

if __name__=='__main__':app.run(host='127.0.0.1',port=8000)
