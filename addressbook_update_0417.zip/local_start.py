import os, json, secrets, getpass, webbrowser, threading, subprocess, sys, time, urllib.request, hmac, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SETTINGS=ROOT/'local_settings.json'
PORT=8000
URL=f'http://127.0.0.1:{PORT}'
APP_NAME='지역위원회 주소록'

def server_info():
    try:
        with urllib.request.urlopen(URL+'/health',timeout=1) as r:
            return json.loads(r.read().decode('utf-8')) if r.status==200 else None
    except Exception:return None
def server_running():return server_info() is not None
def local_version():
    try:return json.loads((ROOT/'version.json').read_text(encoding='utf-8'))['version']
    except Exception:return ''
def stop_old_server():
    """업데이트 전에 켜져 있던 이전 엔진을 끕니다. 성공하면 True."""
    try:
        key=json.loads(SETTINGS.read_text(encoding='utf-8'))['secret_key']
        tok=hmac.new(key.encode(),b'local-shutdown',hashlib.sha256).hexdigest()
        req=urllib.request.Request(URL+'/api/local-shutdown',method='POST',headers={'X-Shutdown-Token':tok})
        urllib.request.urlopen(req,timeout=3).read()
    except Exception:return False
    for _ in range(20):
        time.sleep(0.5)
        if not server_running():return True
    return False

def find_app_browser():
    """Edge(윈도우 10 기본 포함) 또는 Chrome을 찾아 '앱 창' 모드로 엽니다. 주소창·탭이 없는 별도 프로그램 창입니다."""
    if os.name!='nt':return None
    bases=[os.environ.get(k,'') for k in ('ProgramFiles(x86)','ProgramFiles','LOCALAPPDATA')]
    rels=[r'Microsoft\Edge\Application\msedge.exe',r'Google\Chrome\Application\chrome.exe']
    for rel in rels:
        for base in bases:
            if base and Path(base,rel).exists():return str(Path(base,rel))
    return None

def open_window():
    exe=find_app_browser()
    if exe:
        try:
            subprocess.Popen([exe,f'--app={URL}','--window-size=1400,900','--no-first-run'])
            return
        except Exception:pass
    webbrowser.open(URL)

def make_desktop_shortcut():
    """처음 한 번만 바탕화면에 '지역위원회 주소록' 아이콘을 만듭니다."""
    if os.name!='nt':return
    marker=ROOT/'.shortcut_created'
    if marker.exists():return
    bat=ROOT/'주소록 시작.bat'
    exe=find_app_browser() or ''
    q=lambda v:str(v).replace("'","''")
    ps=("$s=(New-Object -ComObject WScript.Shell);"
        "$d=[Environment]::GetFolderPath('Desktop');"
        f"$l=$s.CreateShortcut((Join-Path $d '{APP_NAME}.lnk'));"
        f"$l.TargetPath='{q(bat)}';$l.WorkingDirectory='{q(ROOT)}';"
        + (f"$l.IconLocation='{q(exe)},0';" if exe else "")
        + "$l.Save()")
    try:
        subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-Command',ps],check=True,timeout=20,capture_output=True)
        marker.write_text('ok',encoding='utf-8')
        print('바탕화면에 "'+APP_NAME+'" 아이콘을 만들었습니다. 다음부터 그 아이콘을 더블클릭하세요.')
    except Exception:
        print('바탕화면 아이콘을 만들지 못했습니다. 계속 "주소록 시작.bat"으로 실행하면 됩니다.')

info=server_info()
if info is not None:
    if info.get('version')==local_version():
        # 같은 버전이 이미 실행 중이면 서버를 다시 켜지 않고 창만 엽니다.
        print('주소록이 이미 실행 중입니다. 프로그램 창을 엽니다.')
        open_window()
        time.sleep(1)
        sys.exit(0)
    print('이전 버전 주소록 엔진이 켜져 있어 종료하고 새 버전으로 다시 시작합니다...')
    if not stop_old_server():
        print('')
        print('[안내] 이전 버전 주소록 엔진을 자동으로 끄지 못했습니다.')
        print('작업표시줄에서 다른 검은 창(주소록 엔진)을 모두 닫은 뒤 다시 실행해 주세요.')
        input('Enter 키를 누르면 이 창이 닫힙니다.')
        sys.exit(1)

if not SETTINGS.exists():
    print("주소록 최초 설정")
    while True:
        p=getpass.getpass("관리자 로그인 비밀번호 (12자 이상): ")
        if len(p)<12:
            print("12자 이상 입력해 주세요.")
            continue
        p2=getpass.getpass("비밀번호 다시 입력: ")
        if p!=p2:
            print("비밀번호가 일치하지 않습니다.")
            continue
        break
    settings={'secret_key':secrets.token_hex(32),'initial_password':p}
    SETTINGS.write_text(json.dumps(settings,ensure_ascii=False),encoding='utf-8')
    print("설정이 생성됐습니다. local_settings.json 파일을 공유하지 마세요.")
else:
    settings=json.loads(SETTINGS.read_text(encoding='utf-8'))
os.environ['SECRET_KEY']=settings['secret_key']
os.environ['ADMIN_PASSWORD']=settings['initial_password']
os.environ['LOCAL_HTTP']='1'
from server import app
make_desktop_shortcut()
print("주소록 실행 중:",URL)
print("이 검은 창은 주소록 엔진입니다. 주소록을 쓰는 동안 닫지 말고 최소화해 두세요.")
print("다 쓰고 나면 이 창을 닫으면 종료됩니다.")
threading.Timer(1.2,open_window).start()
app.run(host='127.0.0.1',port=PORT,debug=False,use_reloader=False)
